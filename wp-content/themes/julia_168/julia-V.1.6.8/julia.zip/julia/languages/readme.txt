Official info about translation: http://codex.wordpress.org/Translating_WordPress

Open es_ES.po (spanish as a example) using po editor file and then use translating program( google translator ) to translate it to Spanish language.

Open wp-config.php file which is located in main root folder of wordpress installation and add code like below for spanish language.

define('WPLANG', 'es_ES');