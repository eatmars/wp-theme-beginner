<?php
class Julia_Social_Media_Icons_Widget extends WP_Widget {
    public function __construct(){
      global $julia_plugin_name;
      parent::__construct(
        $julia_plugin_name.'-social-icons',
        __('Julia -  Social Media Icons ',$julia_plugin_name),   
        array( 'description' => __('Displays Social Media Icons',$julia_plugin_name),'class' => '',
      ));
    }
    public function widget( $args , $instance){
      global $julia_plugin_name;
      $instance = wp_parse_args($instance, array(          
        'social_media_icon_1' => 'fa-facebook',
        'social_media_icon_link_1' => '#',
        'social_media_icon_2' => 'fa-twitter',
        'social_media_icon_link_2' => '#',
        'social_media_icon_3' => 'fa-google-plus',
        'social_media_icon_link_3' => '#',
        'social_media_icon_4' => 'fa-skype',
        'social_media_icon_link_4' => '#',
        'social_media_icon_5' => 'fa-tumblr',
        'social_media_icon_link_5' => '#',
        'social_media_icon_6' => '',
        'social_media_icon_link_6' => '',
        'social_media_icon_7' => '',
        'social_media_icon_link_7' => '',
        'social_media_icon_8' => '',
        'social_media_icon_link_8' => '',
        'social_media_icon_9' => '',
        'social_media_icon_link_9' => '',
        'social_media_icon_10' => '',
        'social_media_icon_link_10' => '',
        'social_media_icons_bg_color' => '',
        'social_media_icons_color' => '',
        'social_media_icons_hover_bg_color' => '',
        'social_media_icons_hover_color' => '',
        'social_media_icons_font_size' => '',
        'social_media_icons_padding' => '',
        'link_target_window' => '_blank',
        'icons_position' => 'left',
      ));
      echo $args['before_widget']; 
         $css = '.social_media_icon_wrapper a:hover{ background:'.$instance['social_media_icons_hover_bg_color'].'!important; color:'.$instance['social_media_icons_hover_color'].'!important; }'; 
       $css = preg_replace( '/\s+/', ' ', $css ); 
      echo "<style type=\"text/css\">\n" .trim( $css ). "\n</style>";     
        echo '<div class="social_media_icon_wrapper align'.$instance['icons_position'].'">';
          $bg_color = !empty($instance['social_media_icons_bg_color']) ? 'background:'.$instance['social_media_icons_bg_color'].';' : '';
          for ($i=1; $i < 11 ; $i++) { 
            if( !empty($instance['social_media_icon_'.$i]) ){
              echo '<a target="'.$instance['link_target_window'].'" style="'.$bg_color.' color:'.$instance['social_media_icons_color'].'; font-size:'.$instance['social_media_icons_font_size'].'px; height:'.$instance['social_media_icons_font_size'].'px; width:'.$instance['social_media_icons_font_size'].'px; line-height:'.$instance['social_media_icons_font_size'].'px; padding:'.$instance['social_media_icons_padding'].'px; " href="'.$instance['social_media_icon_link_'.$i].'"><i class="fa '.$instance['social_media_icon_'.$i].'"> </i></a>';
            }
          }
        echo '</div>';
      echo $args['after_widget'];
    }
    public function form($instance){
      global $julia_plugin_name;
      $instance = wp_parse_args($instance, array(          
       'social_media_icon_1' => 'fa-facebook',
        'social_media_icon_link_1' => '#',
        'social_media_icon_2' => 'fa-twitter',
        'social_media_icon_link_2' => '#',
        'social_media_icon_3' => 'fa-google-plus',
        'social_media_icon_link_3' => '#',
        'social_media_icon_4' => 'fa-skype',
        'social_media_icon_link_4' => '#',
        'social_media_icon_5' => 'fa-tumblr',
        'social_media_icon_link_5' => '#',
        'social_media_icon_6' => '',
        'social_media_icon_link_6' => '',
        'social_media_icon_7' => '',
        'social_media_icon_link_7' => '',
        'social_media_icon_8' => '',
        'social_media_icon_link_8' => '',
        'social_media_icon_9' => '',
        'social_media_icon_link_9' => '',
        'social_media_icon_10' => '',
        'social_media_icon_link_10' => '',
        'social_media_icons_bg_color' => '',
        'social_media_icons_color' => '',
        'social_media_icons_hover_color' => '',
        'social_media_icons_hover_bg_color' => '',
        'social_media_icons_font_size' => '',
        'social_media_icons_padding' => '',
        'link_target_window' => '_blank',
        'icons_position' => 'left',
      )); ?>
      <script type='text/javascript'>
        jQuery(document).ready(function($) {
        jQuery('.social_icons_color_pickr').each(function(){
          jQuery(this).wpColorPicker();
        }); 
      });
      </script> 
      <?php 
      for ($i=1; $i < 11 ; $i++) { ?>
        <div class="input-elements-wrapper"> 
          <p class="one_half">
            <label for="<?php echo $this->get_field_id('social_media_icon_'.$i); ?>"><?php  _e('Social Media Icon'.$i.' Name',$julia_plugin_name); ?></label>
            <input id="<?php echo $this->get_field_id('social_media_icon_'.$i); ?>" name="<?php echo $this->get_field_name('social_media_icon_'.$i); ?>" type="text" class="widefat" value="<?php echo esc_attr($instance['social_media_icon_'.$i]) ?>" />
            <small><?php esc_html_e('Ex:',$julia_plugin_name); ?><?php echo 'fa-facebook'; ?>,&nbsp;<?php esc_html_e(' Note: For more icons click ',$julia_plugin_name); ?> <?php echo '<a href="http://fontawesome.io/icons/?utm_source=www.qipaotu.com">here</a>';  ?></small>
          </p>
          <p class="one_half_last">
            <label for="<?php echo $this->get_field_id('social_media_icon_link_'.$i); ?>"><?php  _e('Social Media Icon'.$i.' Link',$julia_plugin_name); ?></label>
            <input id="<?php echo $this->get_field_id('social_media_icon_link_'.$i); ?>" name="<?php echo $this->get_field_name('social_media_icon_link_'.$i); ?>" type="text" class="widefat" value="<?php echo esc_attr($instance['social_media_icon_link_'.$i]) ?>" />
             <small><?php esc_html_e('Ex:',$julia_plugin_name); ?><?php echo 'http://www.facebook.com/userid'; ?></small>
          </p>
        </div> 
       <?php }  ?> 
      <div class="input-elements-wrapper">
         <p class="one_fourth">
          <label for="<?php echo $this->get_field_id('social_media_icons_bg_color'); ?>"><?php  _e('Icons Background Color',$julia_plugin_name); ?></label>
          <input id="<?php echo $this->get_field_id('social_media_icons_bg_color'); ?>" name="<?php echo $this->get_field_name('social_media_icons_bg_color'); ?>" type="text" class="social_icons_color_pickr" value="<?php echo esc_attr($instance['social_media_icons_bg_color']) ?>" />
        </p>
        <p class="one_fourth">
          <label for="<?php echo $this->get_field_id('social_media_icons_color'); ?>"><?php  _e('Icons Color',$julia_plugin_name); ?></label>
          <input id="<?php echo $this->get_field_id('social_media_icons_color'); ?>" name="<?php echo $this->get_field_name('social_media_icons_color'); ?>" type="text" class="social_icons_color_pickr" value="<?php echo esc_attr($instance['social_media_icons_color']) ?>" />
        </p>
        <p class="one_fourth">
          <label for="<?php echo $this->get_field_id('social_media_icons_hover_bg_color'); ?>"><?php  _e('Icons Hover Background Color',$julia_plugin_name); ?></label>
          <input id="<?php echo $this->get_field_id('social_media_icons_hover_bg_color'); ?>" name="<?php echo $this->get_field_name('social_media_icons_hover_bg_color'); ?>" type="text" class="social_icons_color_pickr" value="<?php echo esc_attr($instance['social_media_icons_hover_bg_color']) ?>" />
        </p>
        <p class="one_fourth_last">
          <label for="<?php echo $this->get_field_id('social_media_icons_hover_color'); ?>"><?php  _e('Icons Hover Color',$julia_plugin_name); ?></label>
          <input id="<?php echo $this->get_field_id('social_media_icons_hover_color'); ?>" name="<?php echo $this->get_field_name('social_media_icons_hover_color'); ?>" type="text" class="social_icons_color_pickr" value="<?php echo esc_attr($instance['social_media_icons_hover_color']) ?>" />
        </p>

        <p class="one_fourth" style="clear:both;">
          <label for="<?php echo $this->get_field_id('social_media_icons_font_size'); ?>"><?php  _e('Icons Font Size',$julia_plugin_name); ?></label>
          <input id="<?php echo $this->get_field_id('social_media_icons_font_size'); ?>" name="<?php echo $this->get_field_name('social_media_icons_font_size'); ?>" type="text" class="small-text" value="<?php echo esc_attr($instance['social_media_icons_font_size']) ?>" />
          <small><?php _e('px',$julia_plugin_name);?></small>
        </p>
        <p class="one_fourth">
          <label for="<?php echo $this->get_field_id('icons_position') ?>"> <?php _e('Icons Position',$julia_plugin_name) ?></label>
          <select id="<?php echo $this->get_field_id('icons_position') ?>" name="<?php echo $this->get_field_name('icons_position') ?>">
            <option value="left" <?php selected('left', $instance['icons_position']) ?>> <?php esc_html_e('Left', $julia_plugin_name) ?>   </option>
            <option value="center" <?php selected('center', $instance['icons_position']) ?>>  <?php esc_html_e('Center',$julia_plugin_name) ?></option>
            <option value="right" <?php selected('right', $instance['icons_position']) ?>>  <?php esc_html_e('Right',$julia_plugin_name) ?></option>
          </select>
        </p>
        <p class="one_fourth">
          <label for="<?php echo $this->get_field_id('link_target_window') ?>"> <?php _e('Open Link ',$julia_plugin_name) ?></label>
          <select id="<?php echo $this->get_field_id('link_target_window') ?>" name="<?php echo $this->get_field_name('link_target_window') ?>">
            <option value="_blank" <?php selected('_blank', $instance['link_target_window']) ?>> <?php esc_html_e('New Window', $julia_plugin_name) ?>   </option>
            <option value="_self" <?php selected('_self', $instance['link_target_window']) ?>>  <?php esc_html_e('Self',$julia_plugin_name) ?></option>
          </select>
        </p>
      </div>
     

      
<?php }
} 
julia_kaya_register_widgets('social-media-icons', __FILE__);
?>