<?php
/**
 * Registering meta boxes
 *
 * All the definitions of meta boxes are listed below with comments.
 * Please read them CAREFULLY.
 *
 * You also should read the changelog to know what has been changed before updating.
 *
 * For more information, please visit:
 * @link http://www.deluxeblogtips.com/meta-box/docs/define-meta-boxes
 */

/********************* META BOX DEFINITIONS ***********************/

/**
 * Prefix of meta keys (optional)
 * Use underscore (_) at the beginning to make keys hidden
 * Alt.: You also can make prefix empty to disable it
 */
// Better has an underscore as last sign
global $pf_slug_name, $meta_boxes;
if(!function_exists('wp_get_current_user')) {
    include(ABSPATH . "wp-includes/pluggable.php"); 
}
$prefix = '';
$meta_boxes = array();
$kayaslider_array =get_terms('slider_category','hide_empty=1');
$kaya_slider = array();
$portfolio_terms=  get_terms('portfolio_category','');
	$kaya_portfolio_cat = array();
if( taxonomy_exists('slider_category') ){
	if(!empty($kayaslider_array)){
		foreach ($kayaslider_array as $sliders) {
		$kaya_slider[$sliders->slug] = $sliders->name;
		$sliders_ids[] = $sliders->slug;
		}
	}else{	}
}else{
 $kaya_slider = '';
}
$pf_slug_name = get_theme_mod('pf_slug_name') ? get_theme_mod('pf_slug_name') :'Model';
global $kaya_uniqid, $text_type;
if ( !current_user_can( 'user' ) ) {
	$text_type='text';
}else{
	$text_type='hidden';
}
$model_disable_options = julia_kaya_admin_model_tabs();
//$uniqid = unique_id();
/* ----------------------------------------------------- */
// Page Settings
/* ----------------------------------------------------- */
$meta_boxes[] = array(
	'id' => 'page_title_settings',
	'title' => __('Page Title Options','julia'),
	'pages' => array( 'page','post' ),
	'context' => 'normal',
	'priority' => 'high',
	// List of meta fields
	'fields' => array(
		array(
			'name'		=> __('Disable Page Title','julia'),
			'id'		=> $prefix . "kaya_page_title_disable",
			'type'		=> 'checkbox',
			'std'		=> '',
			'class' 	=> 'kaya_page_title_disable',
		),
		array(
			'name'		=> __('Page Title','julia'),
			'id'		=> $prefix . "select_page_title_option",
			'type'		=> 'select',
			'options'	=> array(
				'default_page_title'		=> __('Default Page Title','julia'),
				"custom_page_title"	=> __("Custom Page Title",'julia'),
			),
			'multiple'	=> false,
			'std'		=> array( 'title' ),
			'desc'		=> '',
			'class' 	=> 'select_page_title_option',
		),
		array(
				'name'		=> __('Custom Page Title','julia'),
				'id'		=> $prefix . "kaya_custom_title",
				'type'		=> 'text',
				'std'		=> '',
				'class' 	=> 'kaya_custom_title',
		),

		)
);

$meta_boxes[] = array(
	'id' => 'pagesettings',
	'title' => __('Page Background Options','julia'),
	'pages' => array( 'page' ),
	'context' => 'normal',
	'priority' => 'high',
	// List of meta fields
	'fields' => array(
		array(
			'name'		=> __('Choose Subheader Style','julia'),
			'id'		=> $prefix . "select_page_options",
			'type'		=> 'select',
			'options'	=> array(
				'none' => __('None','julia'),
				"page_slider_setion"	=> __("Header Slider",'julia'),
				'video_bg' => __('Video Background','julia'),			
			),
			'multiple'	=> false,
			'class' 	=> 'select_page_options',
			'std'		=> array( 'title' ),
			'desc'		=> ''
		),
		// Slider Section
		array(
			'name'		=> __('Select Slider Type','julia'),
			'id'		=> $prefix . "kaya_slider_type",
			'class' 	=> 'kaya_slider_type',
			'type'		=> 'select',
			'options'	=> array(
				'columns_post_slider' => __('Columns Slider','julia'),
				"customslider"	=> __("Slider Plugin Shortcode",'julia'),
				'kaya_post_slider' => __('Kaya Post Slider','julia'),
			),
			'multiple'	=> false,
			'std'		=> array( 'title' ),
			'desc'		=> ''
		),
		/* Kaya Post Slider */
		array(
			'name'		=> __('Select Kaya Post Slider Category','julia'),
			'id'		=> $prefix . "kaya_post_category",
			'class' 	=> 'kaya_post_category',
			'type'		=> 'checkbox_list',
			'options'	=> $kaya_slider,
			'multiple'	=> false,
			'std'		=> array( 'title' ),
			'desc'		=> ''
		),
		// Slider Style 2
		array(
			'name'	=> __('Upload Slider Images','julia'),
			'desc'	=> '',
			'id'	=> $prefix . 'kaya_columns_slider_images',
			'type'	=> 'image_advanced',
			'max_file_uploads' => 500,
			'class' => 'kaya_columns_slider_images',
 		),
 		array(
			'name'	=> __('Upload Slider Images','julia'),
			'desc'	=> '',
			'id'	=> $prefix . 'kaya_columns_images',
			'type'	=> 'image_advanced',
			'max_file_uploads' => 500,
			'class' => 'kaya_columns_images',
 		),
		array( 
			'name'		=> __('Columns','talents'),
			'id'		=> $prefix . "Kaya_post_slider_columns",
			'class' 	=> 'Kaya_post_slider_columns',
			'type'		=> 'select',
			'options'	=> array(
				'5'  => 'Column5',
				'4'  => 'Column4',
				'3'  => 'Column3',
				'2'  => 'Column2',
				'1'  => 'Column1',
			),
			'std'		=> '5'
		),
		array(
			'name'		=> __('Auto Play','julia'),
			'id'		=> $prefix . "Kaya_post_slider_auto_play",
			'class' 	=> 'Kaya_post_slider_auto_play',
			'type'		=> 'select',
			'options'	=> array(
				'true'  => 'True',
				"false" 	=> "False",	
			),
			'multiple'	=> false,
			'std'		=> array( 'title' ),
			'desc'		=> ''
		),
		array(
			'name'		=> __('Slide Animation Type','julia'),
			'id'		=> $prefix . "Kaya_post_slide_animation_type",
			'class' 	=> 'Kaya_post_slide_animation_type',
			'type'		=> 'select',
			'options'	=> array(
				'1' => __('Fade', 'julia'),
				'2' => __('Slide Top', 'julia'),
				'3' => __('Slide Right', 'julia'),
				'4' => __('Slide Bottom', 'julia'),
				'5' => __('Slide Left', 'julia'),
				'6' => __('Carousel Right', 'julia'),
				'7' => __('Carousel Left', 'julia'),
			),
			'multiple'	=> false,
			'std'		=> array( 'title' ),
			'desc'		=> ''
		),
		array(
			'name'		=> __('Slide Interval','julia'),
			'id'		=> $prefix . "kaya_post_slider_interval",
			'class' 	=> 'kaya_post_slider_interval',
			'type'		=> 'text',
			'multiple'	=> false,
			'std'		=> '3000',
			'desc'		=> __('Length between transitions Ex:3000','julia')
		),
		array(
			'name' => __('Slider Images Order by','julia'),
			'desc' => '',
			'id' => $prefix . 'post_slide_images_order_by',
			'class' 	=> 'post_slide_images_order_by',
			'type' => 'select',
			'options' => array(
					'ID' => __('ID','julia'),
					'menu_order' => __('Menu Order','julia'),
					'title' => __('Title','julia'),
				)
		),
		array(
			'name' => __('Slide Images Order','julia'),
			'desc' => '',
			'id' => $prefix . 'post_slide_images_order',
			'class' 	=> 'post_slide_images_order',
			'type' => 'select',
			'options' => array(
					'DESC' => __('Descending Order','julia'),
					'ASC' => __('Ascending Order','julia'),
				)
		),
		// Slider Style 2
		array(
			'name' => __('Enable Slider Auto Width','talents'),
			'desc' => '',
			'id' => $prefix . 'post_slider_enable_auto_width',
			'class' 	=> 'post_slider_enable_auto_width',
			'type' => 'checkbox',
			'std' => ''
		),
		array(
			'name' => __('Disable Slider Screen Height','talents'),
			'desc' => '',
			'id' => $prefix . 'post_slider_disable_screen_height',
			'class' 	=> 'post_slider_disable_screen_height',
			'type' => 'checkbox',
			'std' => ''
		),
		array(
			'name'		=> __('Slide Image Height','talents'),
			'id'		=> $prefix . "post_slider_height",
			'type' 		=> 'slider',
			'class' 	=> 'post_slider_height',
			'js_options' => array(
				'min' 		=> 500,
				'max' 		=> 1000,
				'step'		=> 1,
			),
			'std' => '500',
		),
		//
		array(
			'name' => __('Slider Content Background Color','talents'),
			'desc' => '',
			'id' => $prefix . 'slide_content_bg_color',
			'class' 	=> 'slide_content_bg_color',
			'type' => 'color',
			'std' => '#ed3c74'
		),
		array(
			'name' => __('Slider Title Color','talents'),
			'desc' => '',
			'id' => $prefix . 'post_slide_title_color',
			'class' 	=> 'post_slide_title_color',
			'type' => 'color',
			'std' => '#ffffff'
		),
		array(
			'name' => __('Slider Description Color','talents'),
			'desc' => '',
			'id' => $prefix . 'post_slide_desc_color',
			'class' 	=> 'post_slide_desc_color',
			'type' => 'color',
			'std' => '#ffffff'
		),
		array(
			'name' => __('Title Disable On Hover','talents'),
			'desc' => '',
			'id' => $prefix . 'disable_title_on_hover',
			'class' 	=> 'disable_title_on_hover',
			'type' => 'checkbox',
			'std' => ''
		),
		array(
			'name' => __('Slider Gray Scale Mode','talents'),
			'desc' => '',
			'id' => $prefix . 'post_slide_gray_scale',
			'class' 	=> 'post_slide_gray_scale',
			'type' => 'checkbox',
			'std' => ''
		),
		//
		// End
		array(
			'name' => __('Slider Nav Buttons Color','julia'),
			'desc' => '',
			'id' => $prefix . 'post_slide_buttons_color',
			'class' 	=> 'post_slide_buttons_color',
			'type' => 'color',
			'std' => '#ffffff'
		),
		array(
			'name' => __('Slider Nav Buttons Active Color','julia'),
			'desc' => '',
			'id' => $prefix . 'post_slide_buttons_active_color',
			'class' 	=> 'post_slide_buttons_active_color',
			'type' => 'color',
			'std' => '#ff3333'
		),
		array(
			'name' => __('Disable Slider Pattern','julia'),
			'desc' => '',
			'id' => $prefix . 'post_slide_pattern_disable',
			'class' 	=> 'post_slide_pattern_disable',
			'type' => 'checkbox',
		),
		array(
			'name' => __('Disable Middle Content','talents'),
			'desc' => '',
			'id' => $prefix . 'page_middle_content',
			'class' 	=> 'page_middle_content',
			'type' => 'checkbox',
			'std' => ''
		),
	/* Custom Slider */
		array(
			'name'		=> __('Slider Shortcode','julia'),
			'id'		=> $prefix . 'customslider_type',
			'class' 	=> 'customslider_type',
			'type'		=> 'text',
			'desc' => 'Ex: [customslider shortcode_name]'
			),
	/* Video Background */
		array(
			'name'		=> __('Video Background ID','julia'),
			'id'		=> $prefix . 'video_bg_id',
			'type'		=> 'text',
			'class' 	=> 'video_bg_id',
			'desc' => __('Ex: ','julia').'kuceVNBTJio'
			),
		array(
			'name'		=> __('Video WEBM URL','julia'),
			'id'		=> $prefix . 'video_bg_webm',
			'class' 	=> 'video_bg_webm',
			'type'		=> 'text',
			'desc' => ''
			),
		array(
			'name'	=> __('Video MP4 URL','julia'),
			'id'	=> $prefix . 'video_bg_mp4',
			'class' 	=> 'video_bg_mp4',
			'type'	=> 'text',
			'desc'  => ''
			),
		array(
			'name'	=> __('Video OGG URL','julia'),
			'id'	=> $prefix . 'video_bg_ogg',
			'class' 	=> 'video_bg_ogg',
			'type'	=> 'text',
			'desc' 	=> ''
			),
		array(
				'name'		=> __('Video Background Opacity','julia'),
				'id'		=> $prefix . "bg_video_opcaity",
				'type' 		=> 'slider',
				'class' 	=> 'bg_video_opcaity',
				'js_options' => array(
					'min' 		=> 0,
					'max' 		=> 1,
					'step'		=> 0.1,
			),
			'std' => '1',
		),
		array(
			'name' => __('Video Background Color','julia'),
			'desc' => '',
			'id' => $prefix . 'video_bg_color',
			'class' 	=> 'video_bg_color',
			'type' => 'color',
			'std' => '#333333'
		),
	)
);

/* ----------------------------------------------------- */
// Team Layout Options
/* ----------------------------------------------------- */
$meta_boxes[] = array(
	'id' => 'my-team-settings',
	'title' => 'Team Page Section',
	'pages' => array( 'team' ),
	'context' => 'normal',
		'fields' => array(
		array(
			'name' => __('Team Designation','julia'),
			'desc' => '',
			'id' => $prefix . 'team_designation',
			'type' => 'text',
			'std'	=> 'Managing Director',
			),
		array(
			'name' => __('Description','julia'),
			'desc' => '',
			'id' => $prefix . 'team_description',
			'type' => 'textarea',
			'std'	=> '',
			),
			
	)

);
/* ----------------------------------------------------- */
// Team page Layout Options
/* ----------------------------------------------------- */
$meta_boxes[] = array(
	'id' => 'my-team--social-icons-settings',
	'title' => 'Social Media Icons Section',
	'pages' => array( 'team' ),
	'context' => 'normal',
		'fields' => array(
		// Awesome Icons
		// Icon Images
		array(
			'name' => __('Awesome Icon - 1','julia'), // Awesome Icon
			'desc' => __('Ex:fa-facebook','julia'),
			'id' => $prefix . 'social_awesome_icon_1',
			'type' => 'text',
			'std'	=> '',
		),
		array(
			'name' => 'Icon Link - 1',
			'desc' => __('Ex:http://www.facebook.com/yourfacebookid','julia'),
			'id' => $prefix . 'social_media_link_1',
			'type' => 'text',
			'std'	=> '',
		),
		array(
			'type' => 'divider',
			'id' => 'icon_divider', 
		),
		array(
			'name' => __('Awesome Icon - 2','julia'),   // Awesom Icon 
			'desc' => __('Ex:fa-twitter','julia'),
			'id' => $prefix . 'social_awesome_icon_2',
			'type' => 'text',
			'std'	=> '',
		),
		
		array(
			'name' => 'Icon Link - 2',
			'desc' => __('Ex:http://www.twitter.com/yourtwitterid','julia'),
			'id' => $prefix . 'social_media_link_2',
			'type' => 'text',
			'std'	=> '',
		),
		array(
			'type' => 'divider',
			'id' => 'icon_divider', 
		),
		array(
			'name' => __('Awesome Icon - 3','julia'),   // Awesom Icon 
			'desc' => __('Ex:fa-google-plus','julia'),
			'id' => $prefix . 'social_awesome_icon_3',
			'type' => 'text',
			'std'	=> '',
		),
		
		array(
			'name' => 'Icon Link - 3',
			'desc' => __('Ex:https://plus.google.com/Yourid','julia'),
			'id' => $prefix . 'social_media_link_3',
			'type' => 'text',
			'std'	=> '',
		),
		array(
			'type' => 'divider',
			'id' => 'icon_divider', 
		),
		array(
			'name' => __('Awesome Icon - 4','julia'),   // Awesom Icon 
			'desc' => __('Ex:fa-linkedin','julia'),
			'id' => $prefix . 'social_awesome_icon_4',
			'type' => 'text',
			'std'	=> '',
		),
		
		array(
			'name' => 'Icon Link - 4',
			'desc' => __('Ex:http://www.linkedin.com/profile/qa?id=yourid','julia'),
			'id' => $prefix . 'social_media_link_4',
			'type' => 'text',
			'std'	=> '',
		),
		array(
			'type' => 'divider',
			'id' => 'icon_divider', 
		),
		array(
			'name' => __('Awesome Icon - 5','julia'),   // Awesom Icon 
			'desc' => __('Ex:fa-pinterest','julia'),
			'id' => $prefix . 'social_awesome_icon_5',
			'type' => 'text',
			'std'	=> '',
		),
		
		array(
			'name' => 'Icon Link - 5',
			'desc' => __('Ex:http://www.pinterest.com/yourid','julia'),
			'id' => $prefix . 'social_media_link_5',
			'type' => 'text',
			'std'	=> '',
		),

	)

);
/* ----------------------------------------------------- */
// Video Format
/* ----------------------------------------------------- */
$meta_boxes[] = array(
	'id' => 'kaya_post_format_video',
	'title' => __('Video','julia'),
	'pages' => array( 'post' ),
	'context' => 'normal',
	'fields'	=> array(

		array(
			'name' 	=> 	__('Add Iframe Video','julia'),
			'id' 	=> 	$prefix . 'post_video',
			'type'	=> 	'textarea',
			'desc' 	=> 	'&lt;iframe width=&quot;100%&quot; height=&quot;315&quot; src=&quot;//www.youtube.com/embed/keDneypw3HY&quot; frameborder=&quot;0&quot; allowfullscreen&gt;&lt;/iframe&gt;',
			'std' 	=> 	''	
		),	
		
	)
);
/* ----------------------------------------------------- */
// Gallery
/* ----------------------------------------------------- */
$meta_boxes[] = array(
	'id'		=> 'kaya_post_format_gallery',
	'title'		=> __('Gallery Format','julia'),
	'pages'		=> array( 'post' ),
	'context' => 'normal',

	'fields'	=> array(
		array(
			'name'	=> __('Post Format Gallery','julia'),
			'desc'	=> '',
			'id'	=> $prefix . 'post_gallery',
			'type'	=> 'image_advanced',
			'max_file_uploads' => 500,
		),
		)
);
/* ----------------------------------------------------- */
// Quote Format
/* ----------------------------------------------------- */
$meta_boxes[] = array(
	'id' => 'kaya_quote_format_quote',
	'title' => 'Quote Format',
	'pages' => array( 'post' ),
	'context' => 'normal',
	'fields'	=> array(
		
		array(
			'name' 	=> 	__('Quote','julia'),
			'id' 	=> 	$prefix . 'kaya_quote_desc',
			'type'	=> 	'textarea',
			'desc' 	=> 	'',
			'std' 	=> 	''	
		),
	)
);
/* ----------------------------------------------------- */
// Audio Format
/* ----------------------------------------------------- */
$meta_boxes[] = array(
	'id' => 'kaya_audio_format',
	'title' => 'Audio Format',
	'pages' => array( 'post' ),
	'context' => 'normal',
	'fields'	=> array(
		
		array(
			'name' 	=> 	'Audio URL(mp3)',
			'id' 	=> 	$prefix . 'kaya_audio',
			'type'	=> 	'textarea',
			'std' 	=> 	''	
		),	
		
	)
);
/* ----------------------------------------------------- */
// Link Format
/* ----------------------------------------------------- */
$meta_boxes[] = array(
	'id' => 'kaya_link_format',
	'title' => 'Link Format',
	'pages' => array( 'post' ),
	'context' => 'normal',
	'fields'	=> array(
		
		array(
			'name' 	=> 	'Link',
			'id' 	=> 	$prefix . 'kaya_link',
			'type'	=> 	'text',
			'desc' 	=> 	__('http://www.google.com','julia'),
			'std' 	=> 	''	
		),	
		
	)
);

/* ----------------------------------------------------- */
// Slider
/* ----------------------------------------------------- */
$meta_boxes[] = array(
	'id'		=> 'slider-settings',
	'title'		=> 'SLIDER LINK',
	'pages'		=> array( 'slider' ),
	'context' => 'normal',
	'fields'	=> array(
		array(
			'name' => __('External URL','talents'),
			'desc' => '',
			'id' => $prefix . 'slider_external_url',
			'type' => 'text',
			'std' => ''
			),

		)
	);

$meta_boxes[] = array(
	'id'		=> 'slider-section',
	'title'		=> 'SLIDER SETTINGS',
	'pages'		=> array( 'slider' ),
	'context' => 'normal',
	'fields'	=> array(
		array(
			'name' => __('Slide Title Color','julia'),
			'desc' => '',
			'id' => $prefix . 'slide_title_color',
			'type' => 'color',
			'std' => '#b9b9b9'
			),
		array(
			'name' => __('Slide Title Font Size','julia'),
			'id' => "slide_title_font_size",
			'type' => 'slider',
			'std' => '70',
			'suffix' => __( 'px', 'julia' ),
			'js_options' => array(
			'min' => 20,
			'max' => 250,
			'step' => 1,
			),
		),		
		array(
			'name' => __('Slide Title Font Letter Spacing','julia'),
			'id' => "slide_title_letter_spacing",
			'type' => 'slider',
			'std' => '0',
			//'prefix' => __( '$', 'julia' ),
			'suffix' => __( ' px', 'julia' ),
			'js_options' => array(
				'min' => 0,
				'max' => 50,
				'step' => 1,
			),
		),
		array(
			'name'		=> __('Select Slide Title Font Weight','julia'),
			'id'		=> $prefix . "slide_title_font_weight",
			'type'		=> 'select',
			'options'	=> array(
				'normal' => 'Normal',
				"bold"	=> "Bold",
												
			),
			'multiple'	=> false,
			'std'		=> 'bold',
			'desc'		=> ''
		),
		array(
			'name'		=> __('Select Slide Title Font Style','julia'),
			'id'		=> $prefix . "slide_title_font_style",
			'type'		=> 'select',
			'options'	=> array(
				'normal' => 'Normal',
				"italic"	=> "Italic",
												
			),
			'multiple'	=> false,
			'std'		=> 'normal',
			'desc'		=> ''
		),
		array(
			'id' => 'title_divider',
			'type' => 'divider',
		),
		array(
			'name' => __('Slide Description Color','julia'),
			'desc' => '',
			'id' => $prefix . 'slide_description_color',
			'type' => 'color',
			'std' => '#b9b9b9'
		),		
		array(
			'name' => __('Slide Description Font Size','julia'),
			'id' => "slide_description_font_size",
			'type' => 'slider',
			'suffix' => __( ' px', 'julia' ),
			'std' => '25',
			'js_options' => array(
			'min' => 10,
			'max' => 150,
			'step' => 1,
			),
		),
		array(
			'name' => __('Slide Description Font Letter Spacing','julia'),
			'id' => "slide_description_letter_spacing",
			'type' => 'slider',
			'std' => '0',
			//'prefix' => __( '$', 'julia' ),
			'suffix' => __( ' px', 'julia' ),
			'js_options' => array(
				'min' => 0,
				'max' => 50,
				'step' => 1,
			),
		),
		array(
			'name'		=> __('Select Slide Description Font Weight','julia'),
			'id'		=> $prefix . "slide_desc_font_weight",
			'type'		=> 'select',
			'options'	=> array(
				'normal' => 'Normal',
				"bold"	=> "Bold",
												
			),
			'multiple'	=> false,
			'std'		=> 'bold',
			'desc'		=> ''
		),
		array(
			'name'		=> __('Select Slide Description Font Style','julia'),
			'id'		=> $prefix . "slide_desc_font_style",
			'type'		=> 'select',
			'options'	=> array(
				'normal' => 'Normal',
				"italic"	=> "Italic",
												
			),
			'multiple'	=> false,
			'std'		=> 'italic',
			'desc'		=> ''
		),
		array(
			'id' => 'title_divider',
			'type' => 'divider',
		),
		// Readmore Button1
		array(
				'name' => __( 'Button Background Color', 'julia' ),
				'std' => '#ff3333',
				'id' => $prefix . 'slide_readmore_button_bg',
				'type' => 'color',
			),
		array(
				'name' => __( 'Button Text', 'julia' ),
				'std' => '',
				'id' => $prefix . 'slide_readmore_button_text',
				'type' => 'text',
				'std' => ''
			), 
		array(
				'name' => __( 'Button Text Color', 'julia' ),
				'std' => '#ffffff',
				'id' => $prefix . 'slide_readmore_button_text_color',
				'type' => 'color',
			),
		array(
				'name' => __( 'Button Border Color', 'julia' ),
				'std' => '#ff6d6d',
				'id' => $prefix . 'slide_readmore_button_border_color',
				'type' => 'color',
			),
		array(
				'name' => __( 'Button Hover Background Color', 'julia' ),
				'id' => $prefix . 'slide_readmore_button_hover_bg_color',
				'type' => 'color',
				'std' => '#1a1a1a',
			),
		array(
				'name' => __( 'Button Hover Text Color', 'julia' ),
				'std' => '#ffffff',
				'id' => $prefix . 'slide_readmore_hover_text',
				'type' => 'color',
			),
		array(
				'name' => __( 'Button Hover Border Color', 'julia' ),
				'std' => '#333',
				'id' => $prefix . 'slide_readmore_button_hover_border_color',
				'type' => 'color',
			),
		array(
				'name' => __( 'Button Font Size', 'julia' ),
				'id' => "slide_readmore_button_font_size",
				'type' => 'slider',
				'std' => '13',
				'suffix' => __( 'px', 'julia' ),
				'js_options' => array(
				'min' => 10,
				'max' => 30,
				'step' => 1,
				),
		),
		array(
				'name' => __( 'Button Letter Spacing', 'julia' ),
				'id' => "slide_readmore_button_letter_space",
				'type' => 'slider',
				'std' => '2',
				'suffix' => __( 'px', 'julia' ),
				'js_options' => array(
				'min' => 0,
				'max' => 50,
				'step' => 1,
				),
		),
		array(
			'name'		=> __('Button Font Weight','julia'),
			'id'		=> $prefix . "slide_readmore_button_font_weight",
			'type'		=> 'select',
			'options'	=> array(
				'normal' => 'Normal',
				"bold"	=> "Bold",												
			),
			'multiple'	=> false,
			'std'		=> 'bold',
			'desc'		=> ''
		),
		array(
			'name'		=> __('Button Font Style','julia'),
			'id'		=> $prefix . "slide_readmore_button_font_style",
			'type'		=> 'select',
			'options'	=> array(
				'normal' => 'Normal',
				"italic"	=> "Italic",												
			),
			'multiple'	=> false,
			'std'		=> 'normal',
			'desc'		=> ''
		),
		array(
				'name' => __( 'Button Link', 'julia' ),
				'desc' => 'Ex: http://www.google.com',
				'id' => $prefix . 'slide_readmore_button_link',
				'type' => 'text',
				'std' => ''
			),
		/* Button 2 */
		array(
				'id' => 'button1_divider',
				'type' => 'divider',
			),
		array(
				'name' => __( 'Button2 Background Color', 'julia' ),
				'std' => '#1a1a1a',
				'id' => $prefix . 'slide_readmore_button2_bg',
				'type' => 'color',
			),
		array(
				'name' => __( 'Button2 Text', 'julia' ),
				'std' => '',
				'id' => $prefix . 'slide_readmore_button2_text',
				'type' => 'text',
				'std' => ''
			), 
		array(
				'name' => __( 'Button2 Text Color', 'julia' ),
				'std' => '#ffffff',
				'id' => $prefix . 'slide_readmore_button2_text_color',
				'type' => 'color',
			),
		array(
				'name' => __( 'Button2 Border Color', 'julia' ),
				'std' => '#333',
				'id' => $prefix . 'slide_readmore_button2_border_color',
				'type' => 'color',
			),
		array(
				'name' => __( 'Button2 Hover Background Color', 'julia' ),
				'id' => $prefix . 'slide_readmore_button2_hover_bg_color',
				'type' => 'color',
				'std' => '#ff3333',
			),
		array(
				'name' => __( 'Button2 Hover Text Color', 'julia' ),
				'std' => '#ffffff',
				'id' => $prefix . 'slide_readmore2_hover_text',
				'type' => 'color',
			),
		array(
				'name' => __( 'Button2 Hover Border Color', 'julia' ),
				'std' => '#ff6d6d',
				'id' => $prefix . 'slide_readmore_button2_hover_border_color',
				'type' => 'color',
			),
		array(
				'name' => __( 'Button2 Font Size', 'julia' ),
				'id' => "slide_readmore_button2_font_size",
				'type' => 'slider',
				'std' => '13',
				'suffix' => __( 'px', 'julia' ),
				'js_options' => array(
				'min' => 10,
				'max' => 30,
				'step' => 1,
				),
		),
		array(
				'name' => __( 'Button2 Letter Spacing', 'julia' ),
				'id' => "slide_readmore_button2_letter_space",
				'type' => 'slider',
				'std' => '2',
				'suffix' => __( 'px', 'julia' ),
				'js_options' => array(
				'min' => 0,
				'max' => 50,
				'step' => 1,
				),
		),
		array(
			'name'		=> __('Button Font Weight','julia'),
			'id'		=> $prefix . "slide_readmore_button2_font_weight",
			'type'		=> 'select',
			'options'	=> array(
				'normal' => 'Normal',
				"bold"	=> "Bold",												
			),
			'multiple'	=> false,
			'std'		=> 'bold',
			'desc'		=> ''
		),
		array(
			'name'		=> __('Button Font Style','julia'),
			'id'		=> $prefix . "slide_readmore_button2_font_style",
			'type'		=> 'select',
			'options'	=> array(
				'normal' => 'Normal',
				"italic"	=> "Italic",												
			),
			'multiple'	=> false,
			'std'		=> 'normal',
			'desc'		=> ''
		),
		array(
				'name' => __( 'Button2 Link', 'julia' ),
				'desc' => 'Ex: http://www.google.com',
				'id' => $prefix . 'slide_readmore_button2_link',
				'type' => 'text',
				'std' => ''
			),
		/* Button 2 */
		array(
				'id' => 'button2_divider',
				'type' => 'divider',
			),
		array(
				'name' => __( 'Slide Content Position', 'julia'),
				'id'   => "slide_content_position",
				'type'	=> 'radio',
				'options' => array(
						'center' => __('Center', 'julia'),
						'left' => __('Left', 'julia'),
						'right' => __('Right', 'julia'),
						),
				'std' => 'right'
			),


		)
	);

/* ----------------------------------------------------- */
// Slider
/* ----------------------------------------------------- */
$meta_boxes[] = array(
	'id'		=> 'testimonial-settngs',
	'title'		=> __('Testimonial Settings','julia'),
	'pages'		=> array( 'testimonial' ),
	'context' => 'normal',
	'fields'	=> array(
	array(
			'name' => __('Description','julia'),
			'desc' => '',
			'id' => $prefix . 'testimonial_description',
			'type' => 'textarea',
			'std' => ''
		),
	    array(
			'name' => __('Designation','julia'),
			'desc' => 'Ex:Creative Director',
			'id' => $prefix . 't_client_designation',
			'type' => 'text',
			'std' => ''
		),
		)
	);
/* ----------------------------------------------------- */
// Client Slider
/* ----------------------------------------------------- */
$meta_boxes[] = array(
	'id'		=> 'client-settngs',
	'title'		=> __('Client Settings','julia'),
	'pages'		=> array( 'client' ),
	'context' => 'normal',
	'fields'	=> array(
		array(
			'name' => __('Description','julia'),
			'desc' => '',
			'id' => $prefix . 'client_description',
			'type' => 'textarea',
			'std' => ''
		),
		array(
			'name' => __('Custom Link','julia'),
			'desc' => 'Ex: http://www.google.com',
			'id' => $prefix . 'client_link',
			'type' => 'text',
			'std' => ''
		),
		array(
			'name' => __('Open New Window','julia'),
			'id' => $prefix . 'client_target_link',
			'type'		=> 'checkbox',
			'desc'		=> ''
		),
		)
	);
/********************* META BOX REGISTERING ***********************/

/**
 * Register meta boxes
 *
 * @return void
 */
function kaya_julia_register_meta_boxes()
{
	global $meta_boxes;
	// Make sure there's no errors when the plugin is deactivated or during upgrade
	if ( class_exists( 'RW_Meta_Box' ) )
	{
		foreach ( $meta_boxes as $meta_box )
		{
			new RW_Meta_Box( $meta_box );
		}
	}
}
add_action( 'admin_init', 'kaya_julia_register_meta_boxes' );