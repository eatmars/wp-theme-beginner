<?php
    class Julia_DasHoaerd_Custom_Options{
        function __construct(){
            add_action( 'admin_init' , array( $this, 'admin_options_register_init' ) );
            add_action( 'admin_menu' , array( $this, 'pf_options_page' ) );
        }
        function admin_options_register_init(){
            register_setting( 'admin_custom_options', 'admin_options_data',  array( $this,'admin_custom_options_validate') );
        }
        function pf_options_page() {
            global $julia_plugin_name;
           // add_submenu_page('kaya_theme_options',  __('Settings', 'julia'), __('Settings', 'julia'), 'manage_options', 'admin_options_page',  array( $this,'admin_custom_options_sttings'));
        }
        function admin_custom_options_sttings(){   ?>
            <!-- Options Create -->
            <?php global $julia_plugin_name;
            $pf_slug_text = get_theme_mod('pf_slug_name') ? trim(get_theme_mod('pf_slug_name')) :'Model'; ?>
            <div class="wrap theme_admin_settings_panel">
                  <div class="settings-banner">
					<h1><span class="dashicons dashicons-admin-generic"></span><?php _e('Settings','julia'); ?></h1>
				</div>
            	<?php   $tabs = array( 'login_users' => __('Login Users Dashboard', 'julia'), 'admin_models_tabs' => ucfirst($pf_slug_text).__(' CPT Tabs','julia') );     				
    				echo '<div class="nav-tab-wrapper">';
	                    echo '<ul class="settings-nav">';
						    foreach( $tabs as $tab => $name ){
						        echo "<li><a class='nav-tab' href='#$tab'>$name</a></li>";
						        
						    }
					    echo '</ul>';
					echo '</div>';     ?>
                <form method="post" action="options.php">
                    <?php settings_fields('admin_custom_options');
                    $options = get_option('admin_options_data'); 
             ?>
             	<div class="admin_tabs_content_section">
	                <div class="admin_menu_tabs_section" id="login_users"> 
		                <table class="form-table">              		
		           			 <tr>
								<th><label for="disable_widget_column_1"><?php _e('Disable Widget Area1 ', 'julia'); ?></label></th>
								<td><input id="disable_widget_column_1" name="admin_options_data[disable_widget_column_1]" type="checkbox" <?php checked(1, $options['disable_widget_column_1'], true); ?> value="1" /></td>
							</tr>
							<tr>
								<th><label for="widget_column_title_1"><?php _e('Widget Area1 Title','julia'); ?></label></th>
								<td><input id="widget_column_title_1" name="admin_options_data[widget_column_title_1]" type="text"  value="<?php echo trim($options['widget_column_title_1']) ?>" /></td>
							</tr>
							<tr>
								<th><label for="widget_column_desc_1"><?php _e('Widget Area1 Description','julia'); ?></label></th>
								<td><textarea id="widget_column_desc_1" name="admin_options_data[widget_column_desc_1]" cols="60" rows="5" ><?php echo esc_html( stripslashes( $options["widget_column_desc_1"] ) ); ?></textarea></td>
							</tr>
							<tr>
								<th><label for="disable_widget_column_2"><?php _e('Disable Widget Area2','julia'); ?></label></th>
								<td><input id="disable_widget_column_2" name="admin_options_data[disable_widget_column_2]" type="checkbox" <?php checked(1, $options['disable_widget_column_2'], true); ?> value="1" /></td>
							</tr>
							<tr>
								<th><label for="widget_column_title_2"><?php _e('Widget Area2 Title','julia'); ?></label></th>
								<td><input id="widget_column_title_2" name="admin_options_data[widget_column_title_2]" type="text"  value="<?php echo $options['widget_column_title_2'] ?>" /></td>
							</tr>
							<tr>
								<th><label for="widget_column_desc_2"><?php _e('Widget Area2 Description','julia'); ?></label></th>
								<td><textarea id="widget_column_desc_2" name="admin_options_data[widget_column_desc_2]" cols="60" rows="5" ><?php echo esc_html( stripslashes( $options["widget_column_desc_2"] ) ); ?></textarea></td>
							</tr>
							<tr>
								<th><label for="disable_widget_column_3"><?php _e('Disable Widget Area3','julia'); ?></label></th>
								<td><input id="disable_widget_column_3" name="admin_options_data[disable_widget_column_3]" type="checkbox" <?php checked(1, $options['disable_widget_column_3'], true); ?> value="1" /></td>
							</tr>  
					</table> 
				</div>  
				<div class="admin_menu_tabs_section" id="admin_models_tabs"> 
		                <table class="form-table">              		
		           			 <tr>
								<th><label for="disable_tab1"><?php _e('Disable Tab1 ','julia'); ?></label></th>
								<td><input id="disable_tab1" name="admin_options_data[disable_tab1]" type="checkbox" <?php checked(1, $options['disable_tab1'], true); ?> value="1" /></td>
							</tr>
							<tr>
								<th><label for="tab1_text_change"><?php _e('Tab1 Text Change', 'julia'); ?></label></th>
								<td><input id="tab1_text_change" name="admin_options_data[tab1_text_change]" type="text"  value="<?php echo trim($options['tab1_text_change']) ?>" /></td>
							</tr>

							<tr>
								<th><label for="disable_tab2"><?php _e('Disable Tab2', 'julia'); ?></label></th>
								<td><input id="disable_tab2" name="admin_options_data[disable_tab2]" type="checkbox" <?php checked(1, $options['disable_tab2'], true); ?> value="1" /></td>
							</tr>
							<tr>
								<th><label for="tab2_text_change"><?php _e('Tab1 Text Change','julia'); ?></label></th>
								<td><input id="tab2_text_change" name="admin_options_data[tab2_text_change]" type="text"  value="<?php echo trim($options['tab2_text_change']) ?>" /></td>
							</tr>

							<tr>
								<th><label for="disable_tab3"><?php _e('Disable Tab3', 'julia'); ?></label></th>
								<td><input id="disable_tab3" name="admin_options_data[disable_tab3]" type="checkbox" <?php checked(1, $options['disable_tab3'], true); ?> value="1" /></td>
							</tr>
							<tr>
								<th><label for="tab3_text_change"><?php _e('Tab3 Text Change', 'julia'); ?></label></th>
								<td><input id="tab3_text_change" name="admin_options_data[tab3_text_change]" type="text"  value="<?php echo trim($options['tab3_text_change']) ?>" /></td>
							</tr>

							<tr>
								<th><label for="disable_tab4"><?php _e('Disable Tab4', 'julia'); ?></label></th>
								<td><input id="disable_tab4" name="admin_options_data[disable_tab4]" type="checkbox" <?php checked(1, $options['disable_tab4'], true); ?> value="1" /></td>
							</tr>
							<tr>
								<th><label for="tab4_text_change"><?php _e('Tab4 Text Change','julia'); ?></label></th>
								<td><input id="tab4_text_change" name="admin_options_data[tab4_text_change]" type="text"  value="<?php echo trim($options['tab4_text_change']) ?>" /></td>
							</tr>

							<tr>
								<th><label for="disable_tab5"><?php _e('Disable Tab5', 'julia'); ?></label></th>
								<td><input id="disable_tab5" name="admin_options_data[disable_tab5]" type="checkbox" <?php checked(1, $options['disable_tab5'], true); ?> value="1" /></td>
							</tr>
							<tr>
								<th><label for="tab5_text_change"><?php _e('Tab5 Text Change', 'julia'); ?></label></th>
								<td><input id="tab5_text_change" name="admin_options_data[tab5_text_change]" type="text"  value="<?php echo trim($options['tab5_text_change']) ?>" /></td>
							</tr>


							<tr>
								<th><label for="disable_videos_tab"><?php _e('Disable Video Tab', 'julia'); ?></label></th>
								<td><input id="disable_videos_tab" name="admin_options_data[disable_videos_tab]" type="checkbox" <?php checked(1, $options['disable_videos_tab'], true); ?> value="1" /></td>
							</tr>
							<tr>
								<th><label for="video_tab_text_change"><?php _e('Video Tab Text Change', 'julia'); ?></label></th>
								<td><input id="video_tab_text_change" name="admin_options_data[video_tab_text_change]" type="text"  value="<?php echo trim($options['video_tab_text_change']) ?>" /></td>
							</tr>


							<tr>
								<th><label for="disable_compcard_tab"><?php _e('Disable Compcard Tab','julia'); ?></label></th>
								<td><input id="disable_compcard_tab" name="admin_options_data[disable_compcard_tab]" type="checkbox" <?php checked(1, $options['disable_compcard_tab'], true); ?> value="1" /></td>
							</tr>
							<tr>
								<th><label for="compard_tab_text_change"><?php _e('Compcard Text Change', 'julia'); ?></label></th>
								<td><input id="compard_tab_text_change" name="admin_options_data[compard_tab_text_change]" type="text"  value="<?php echo trim($options['compard_tab_text_change']) ?>" /></td>
							</tr>							

							<tr>
								<th><label for="disable_biography_tab"><?php _e('Disable Biography Tab',  'julia'); ?></label></th>
								<td><input id="disable_biography_tab" name="admin_options_data[disable_biography_tab]" type="checkbox" <?php checked(1, $options['disable_biography_tab'], true); ?> value="1" /></td>
							</tr>
							<tr>
								<th><label for="biography_tab_text_change"><?php _e('Biography Tab Text Change','julia'); ?></label></th>
								<td><input id="biography_tab_text_change" name="admin_options_data[biography_tab_text_change]" type="text"  value="<?php echo trim($options['biography_tab_text_change']) ?>" /></td>
							</tr>
					</table> 
				</div> 
			</div>     
            <p class="submit">
                <input type="submit" class="button-primary" value="<?php _e('Save', 'julia'); ?>" />
                </p>
                
            </form>
        </div>
        <?php   
    }
    function admin_custom_options_validate($input) {
		   	$settings['disable_widget_column_1'] = $input['disable_widget_column_1'];
			$settings['widget_column_title_1'] = $input['widget_column_title_1'];
			$settings['widget_column_desc_1'] = $input['widget_column_desc_1'];
			$settings['disable_widget_column_2'] = $input['disable_widget_column_2'];
			$settings['widget_column_title_2'] = $input['widget_column_title_2'];
			$settings['widget_column_desc_2'] = $input['widget_column_desc_2'];
			$settings['disable_widget_column_3'] = $input['disable_widget_column_3'];
			$settings['tab1_text_change'] = $input['tab1_text_change'];
			$settings['disable_tab1'] = $input['disable_tab1'];
			$settings['tab2_text_change'] = $input['tab2_text_change'];
			$settings['disable_tab2'] = $input['disable_tab2'];
			$settings['tab3_text_change'] = $input['tab3_text_change'];
			$settings['disable_tab3'] = $input['disable_tab3'];
			$settings['tab4_text_change'] = $input['tab4_text_change'];
			$settings['disable_tab4'] = $input['disable_tab4'];
			$settings['tab5_text_change'] = $input['tab5_text_change'];
			$settings['disable_tab5'] = $input['disable_tab5'];
			$settings['video_tab_text_change'] = $input['video_tab_text_change'];
			$settings['disable_videos_tab'] = $input['disable_videos_tab'];
			$settings['compard_tab_text_change'] = $input['compard_tab_text_change'];
			$settings['disable_compcard_tab'] = $input['disable_compcard_tab'];
			$settings['disable_biography_tab'] = $input['disable_biography_tab'];
			$settings['biography_tab_text_change'] = $input['biography_tab_text_change'];



        return $settings;
    }
}
    $pf_meta_options = new Julia_DasHoaerd_Custom_Options;

?>