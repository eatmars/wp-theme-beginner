<?php
function julia_kaya_button($atts, $content=NULL) {      
    extract(shortcode_atts(array(
        'link' => '#',
        'bg_color' => '#ff3333',
        'text_color' => '#fff',
        'hover_bg_color' => '#ff0000',
        'hover_text_color' => '#fff',
        'border_width' => '2',
        'border_color' => '#ff0000',
        'hover_border_color' => '#fff',
        'padding_top_bottom' => '7',
        'padding_left_right' => '20',
        'font_size' => '13',
        'font_weight' => 'normal',
        'font_style' => 'normal',
        'letter_spacing' => '2',
        'border_radius' => '0',
        'alignment' => 'left',
        'target' => '_balnk',       
    ), $atts));
      $button_hover =rand(1,100); ?>
    <div class="button_wrapper_section button_wrapper_<?php echo $alignment; ?>">
        <?php
        $css = '.button_wrapper_section a.widget_readmore-'.$button_hover.':hover{ background:'.$hover_bg_color.'!important; border-color:'.$hover_border_color.'!important; color:'.$hover_text_color.'!important; }'; 
        $css = preg_replace( '/\s+/', ' ', $css ); 
        echo "<style type=\"text/css\">\n" .trim( $css ). "\n</style>";  ?>
        <a class=" widget_button widget_readmore-<?php echo $button_hover; ?> align<?php echo $alignment;  ?> widget_button widget_readmore-<?php echo $button_hover; ?>" href="<?php echo esc_url($link); ?>" target="<?php echo $target; ?>" style="background-color:<?php echo $bg_color; ?>; color:<?php echo $text_color; ?>; border-radius:<?php echo $border_radius; ?>px; border:<?php echo $border_width ?>px solid <?php echo $border_color; ?>; padding:<?php echo $padding_top_bottom; ?>px <?php echo $padding_left_right;  ?>px; font-size:<?php echo $font_size ?>px; font-weight:<?php echo $font_weight; ?>; font-style:<?php echo $font_style; ?>; letter-spacing:<?php echo $letter_spacing; ?>px;">
            <?php echo $content; ?>
        </a>
      </div>
<?php }
add_shortcode('button','julia_kaya_button'); 
?>