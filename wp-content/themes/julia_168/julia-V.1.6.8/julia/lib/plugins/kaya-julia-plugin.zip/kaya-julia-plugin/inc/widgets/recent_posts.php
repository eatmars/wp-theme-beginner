<?php
class Julia_Recent_Posts_Widget extends WP_Widget{
	public function __construct(){
		global $julia_plugin_name;
		parent:: __construct('kaya-recentposts', __('Julia Recentposts',$julia_plugin_name),
			array( 'description' => __('Use this widget to add recentposts',$julia_plugin_name),'class' =>'recentposts')
		);
	}
	public function widget($args, $instance){
		echo $args['before_widget'];
		global $post;
		global $julia_plugin_name;
		$instance = wp_parse_args( $instance,array(
			'recent_blog_post' => '',
			'limit' => '45',
			'content_limit' => '8',
			'order_by' => 'id',
            'order' => 'desc',
            'title_font_color' => '#fff',
            'title_font_size' => '13',
            'date_color' => '#AAAEAF',
            'animation_names' => '',
            'post_img_border_color' => '#BAC2C4',
            'post_description_color' => '',
    	));
		$post_rand = rand(1,20); ?>
		<?php $posts_animation = ( trim($instance['animation_names']) ) ?  "wow ".$instance['animation_names']."":'';
		$line_height  = round((1.5 * $instance['title_font_size'])); 
		$content_limit = $instance['content_limit'] ? $instance['content_limit'] : '';  ?>
		<div class="recent_posts <?php echo $posts_animation; ?>">
			<ul>
				<?php	 
				$loop = new WP_Query(array('post_type' => 'post', 'orderby' => $instance['order_by'], 'order' => $instance['order'], 'posts_per_page' => $instance['limit'], 'cat' =>  $instance['recent_blog_post']));
				if( $loop->have_posts() ) : while( $loop->have_posts() ) : $loop->the_post();?>
				<li>
					<?php
					$img_url = wp_get_attachment_url( get_post_thumbnail_id() );
					if( $img_url ){
						echo '<div class="recent_post_image">'; ?>
							<a href="<?php echo the_permalink(); ?>">
								<?php 	
	
									echo '<img src="'.kaya_image_resize( $img_url, 100,120,'t' ).'" class="" alt="'.get_the_title().'" width="100" height="120" />';
								
						echo '</a>';
						echo '</div>';
					} ?>
					<div class="recent_post_content">
						<h4 style="font-size:<?php echo $instance['title_font_size']?>px; line-height:<?php echo $line_height; ?>px; color:<?php echo $instance['title_font_color']?>;">
							<?php  echo get_the_title(); ?>
						</h4>
						<span class="recent_posts_date" style="color:<?php echo $instance['date_color']?>"><?php echo get_the_date('D, m, Y'); ?>
						<p style="color:<?php echo $instance['post_description_color'] ?>; font-size:<?php echo $instance['description_font_size'] ?>px;"><?php echo kaya_content_dsiplay_words($content_limit); ?></p>
						</span>
					</div>
				</li>
				<?php endwhile; endif; ?>
			</ul>
			<?php wp_reset_postdata(); ?>
		</div>
	    <?php echo $args['after_widget'];
	}
    public function form($instance){
    	global $julia_plugin_name;
    	$blog_categories = get_categories('hide_empty=0');
		if( $blog_categories ){
			foreach ($blog_categories as $category) {
			$blog_cat_name[] = $category->name.'-'.$category->cat_ID;
			$blog_cat_id[] = $category->cat_ID;  
		} } 
		else{   
			$blog_cat_id[] = '';
			$blog_cat_name[] ='';
		}
    	$instance = wp_parse_args($instance,array(
    		'recent_blog_post' => implode(',', $blog_cat_id),
    		'limit' => '45',
    		'content_limit' => '8',
    		'order_by' => 'id',
            'order' => 'desc',
            'title_font_color' => '#fff',
            'title_font_size' => '13',
            'date_color' => '#AAAEAF',
            'animation_names' => '',
            'post_img_border_color' => '#BAC2C4',
            'post_description_color' => '',

    	));?>
    	<script type="text/javascript">
    	jQuery(document).ready(function($){
    		jQuery('.recentposts_color_picker').each(function(){
    			jQuery(this).wpColorPicker();
    		});
    	});
    	</script>
    	<div class="input-elements-wrapper"> 
			<p class="three_fourth">
				<label for="<?php echo $this->get_field_id('recent_blog_post') ?>"><?php _e('Select Blog Category IDs',$julia_plugin_name) ?>
				</label>
				<input type="text" name="<?php echo $this->get_field_name('recent_blog_post') ?>" id="<?php echo $this->get_field_id('recent_blog_post') ?>" class="widefat" value="<?php echo $instance['recent_blog_post'] ?>" />
				<em><strong style="color:green;"><?php _e('Available Categories and IDs : ',$julia_plugin_name); ?> </strong> <?php echo implode
				(',', $blog_cat_name); ?></em><br />
				<stong><?php _e('Note:',$julia_plugin_name); ?></strong>
			    <?php _e('Separate IDs with commas only',$julia_plugin_name); ?>
			<p class="one_fourth_last">
				<label for="<?php echo $this->get_field_id('limit') ?>">  <?php _e('Display Number of Posts',$julia_plugin_name)?>  </label>
				<input type="text" class="small-text" id="<?php echo $this->get_field_id('limit') ?>" value="<?php echo esc_attr($instance['limit']) ?>" name="<?php echo $this->get_field_name('limit') ?>" />
			</p>
		</div>
		<div class="input-elements-wrapper"> 
			<p class="one_fourth">
				<label for="<?php echo $this->get_field_id('title_font_color') ?>"><?php _e('Title Font Color',$julia_plugin_name)?></label>
				<input type="text" class="recentposts_color_picker" id="<?php echo $this->get_field_id('title_font_color') ?>" name="<?php echo $this->get_field_name('title_font_color') ?>" value="<?php echo $instance['title_font_color']; ?>" />
			</p>
			<p class="one_fourth">
				<label for="<?php echo $this->get_field_id('title_font_size') ?>">  <?php _e('Title Font Size',$julia_plugin_name) ?>  </label>
				<input type="text" id="<?php echo $this->get_field_id('title_font_size') ?>" class="small-text" name="<?php echo $this->get_field_name('title_font_size') ?>" value = "<?php echo $instance['title_font_size'] ?>" />
				<small><?php _e('px',$julia_plugin_name);?></small>
			</p>
			<p class="one_fourth">
				<label for="<?php echo $this->get_field_id('date_color') ?>"><?php _e('Date Color',$julia_plugin_name)?></label>
				<input type="text" class="recentposts_color_picker" id="<?php echo $this->get_field_id('date_color') ?>" name="<?php echo $this->get_field_name('date_color') ?>" value="<?php echo $instance['date_color']; ?>" />
			</p>
			
		</div>
		<div class="input-elements-wrapper">
			<p class="one_fourth">
				<label for="<?php echo $this->get_field_id('order_by') ?>"><?php _e('Orderby',$julia_plugin_name)?></label>
				<select id="<?php echo $this->get_field_id('order_by') ?>" name="<?php echo $this->get_field_name
				    ('order_by') ?>">
					<option value="date" <?php selected('date', $instance['order_by']) ?>> <?php esc_html_e('Date', $julia_plugin_name) ?> </option>
					<option value="menu_order" <?php selected('menu_order', $instance['order_by']) ?>>	<?php esc_html_e('Menu Order', $julia_plugin_name) ?></option>
					<option value="title" <?php selected('title', $instance['order_by']) ?>><?php esc_html_e('Title', $julia_plugin_name) ?></option>
					<option value="rand" <?php selected('rand', $instance['order_by']) ?>>	<?php esc_html_e('Random', $julia_plugin_name) ?></option>
					<option value="author" <?php selected('author', $instance['order_by']) ?>>	<?php esc_html_e('Author', $julia_plugin_name) ?></option>
				</select>
			</p>
			<p class="one_fourth">
				<label for="<?php echo $this->get_field_id('order') ?>"><?php _e('Order',$julia_plugin_name)?> </label>
				<select id="<?php echo $this->get_field_id('order') ?>" name="<?php echo $this->get_field_name('order') ?>">
					<option value="DESC" <?php selected('DESC', $instance['order']) ?>><?php esc_html_e('Descending', $julia_plugin_name) ?></option> 
					<option value="ASC" <?php selected('ASC', $instance['order']) ?>><?php esc_html_e('Ascending', $julia_plugin_name) ?></option>
				</select>
			</p>
			<p class="one_fourth">
				<label for="<?php echo $this->get_field_id('post_description_color') ?>"><?php _e('Description Font Color',$petshop_plugin_name)?></label>
				<input type="text" class="recentposts_color_picker" id="<?php echo $this->get_field_id('post_description_color') ?>" name="<?php echo $this->get_field_name('post_description_color') ?>" value="<?php echo $instance['post_description_color']; ?>" />
			</p>
	      <p class="one_fourth_last">
        <label for="<?php echo $this->get_field_id('content_limit') ?>"><?php _e('Post Content Limit',$julia_plugin_name)?></label>
        <input type="text" class="small-text" id="<?php echo $this->get_field_id('content_limit') ?>" name="<?php echo $this->get_field_name('content_limit') ?>" value="<?php echo esc_attr($instance['content_limit']); ?>" />
      </p>
		</div>
		<div class="input-elements-wrapper">
			<p>
				<label for="<?php echo $this->get_field_id('animation_names') ?>">  <?php _e('Select Animation Effect',$julia_plugin_name) ?>  </label>
				<?php animation_effects($this->get_field_name('animation_names'), $instance['animation_names'] ); ?>
			<p>
		</div>
     <?php
    }
}
julia_kaya_register_widgets('recent-posts', __FILE__);
?>