<?php
ob_start();
if( !class_exists('Julia_Pf_Custom_Options') ){
    class Julia_Pf_Custom_Options{
        var $pf_slug_name;
        function __construct(){
            add_action( 'admin_init' , array( $this, 'pf_options_register_init' ) );
            add_action( 'admin_menu' , array( $this, 'pf_add_options_page' ) );
            $this->pf_slug_name = get_theme_mod('pf_slug_name') ? get_theme_mod('pf_slug_name') :'Model';
            add_action('admin_enqueue_scripts', array(&$this,'pf_admin_scripts')); //style files
        }
        function pf_options_register_init(){
            register_setting( 'pf_meta_custom_options', 'pf_custom_options',  array( $this,'pf_custom_options_validate') );
        }
        function pf_add_options_page() {
            global $julia_plugin_name;
            add_menu_page('Options', ucfirst($julia_plugin_name).' Options', 'manage_options', 'kaya_theme_options', array(&$this, 'import_xml_content'), '', 62);
            add_submenu_page('kaya_theme_options', ucfirst($this->pf_slug_name).' '. __('Options', 'julia'), ucfirst($this->pf_slug_name).' '.__('Options', 'julia'), 'manage_options', 'pf_custom_options_page',  array( $this,'pf_custom_options_sttings'));
            add_submenu_page('kaya_theme_options', __('Import', 'julia'), __('Import', 'julia'), 'edit_theme_options', 'pf_import', array( &$this,'pf_import_option_page'));
            add_submenu_page('kaya_theme_options', __('Export', 'julia'), __('Export', 'julia'), 'edit_theme_options', 'pf-export', array( &$this,'pf_export_option_page'));
        }
        function pf_admin_scripts(){
            global $julia_plugin_name;
            wp_enqueue_script('admin_script', constant(strtoupper($julia_plugin_name).'_PLUGIN_URL').'js/admin_scripts.js',array( 'jquery' ),'', true);
            wp_enqueue_style('admin_style', constant(strtoupper($julia_plugin_name).'_PLUGIN_URL').'css/admin_styles.css');
        }
        function pf_export_option_page() {  
         // Export Options
            if (!isset($_POST['export'])) {  ?>
                <div class="wrap">
                    <div id="icon-tools" class="icon32"><br /></div>
                    <h2><?php echo ucfirst($this->pf_slug_name).' '; _e('Options Data Export','julia').'</h2>'; ?>
                    <p><?php _e('When you click <tt>Backup all options</tt> button, system will generate a JSON file for you to save on your computer.</p>
                    <p>This backup file contains all configution and setting options on our website. Note that it do <b>NOT</b> contain posts, pages, or any relevant data, just your all options.','julia'); ?></p>
                    <p> <?php _e('After exporting, you can either use the backup file to restore your settings on this site again or another WordPress site.','julia'); ?> </p>
                    <form method='post'>
                        <p class="submit">
                            <?php wp_nonce_field('pf-export'); ?>
                            <input type='submit' name='export' value='<?php _e("Dowload Options Settings", 'julia'); ?>' class="button button-primary"/>
                        </p>
                    </form>
                </div>
                <?php
            }
            elseif (check_admin_referer('pf-export')) {
                 $blogname = str_replace(" ", "", get_option('blogname'));
                $date = date("m-d-Y");
                $json_name = $blogname."-".$date; // Namming the filename will be generated.
                 //$options = get_option('pf_custom_options'); // Get all options data, return array 
                  $options = array('pf_custom_options' => get_option('pf_custom_options'));     
                 foreach ($options as $key => $value) {
                    $value = maybe_unserialize($value);
                    $need_options[$key] = $value;
                }
                $json_file = json_encode($need_options); // Encode data into json data
                ob_clean();
                echo $json_file;
                header("Content-Type: text/json; charset=" . get_option( 'blog_charset'));
                header("Content-Disposition: attachment; filename=$json_name.json");
                exit();
            }
        }
        function pf_custom_options_sttings(){   ?>
            <!-- Options Create -->
            <?php global $julia_plugin_name; ?>
            <div class="wrap custom_meta_options_group">
                <h2><?php echo ucfirst($this->pf_slug_name).' '; _e(' Custom Meta Field Options','julia'); ?><?php echo '<a target="_blank" href="https://www.youtube.com/watch?v=520ZzE8A8Cc&feature=youtu.be"> '.esc_html__(' Watch This Video','julia').'</a>'; ?> </h2>
                <?php $model_options_data = ''; 
                if ( isset( $_GET['settings-updated'] ) ) {
                    echo "<div class='updated notice is-dismissible'><p>".esc_html__('All Options are successfully saved','julia')."</p></div>";
                } ?>
                <form method="post" action="options.php">
                    <?php settings_fields('pf_meta_custom_options');
                    $options = get_option('pf_custom_options'); 
                    $some_text = isset( $options['search_name'] ) ? $options['search_name'] : 'Search';
                $count=count($options['pf_meta_label_name']);    ?>
                <div class="add_options_fields">
                <table class="table">
                    <thead>
                        <tr>
                            <th><?php esc_html_e('Input Type', $julia_plugin_name); ?></th>
                            <th><?php esc_html_e('Label Name', $julia_plugin_name); ?></th>
                            <th><?php esc_html_e('Display on Search', $julia_plugin_name); ?></th>
                            <th><?php esc_html_e('Visible To  Public', $julia_plugin_name); ?></th>
                            <th><?php esc_html_e('Search Range', $julia_plugin_name); ?></th>
                              <th><?php esc_html_e('Display Details On Comp Card', $julia_plugin_name); ?></th>
                            <th><?php esc_html_e('Display Details On Image', $julia_plugin_name); ?></th>
                            <th><?php esc_html_e('Actions', $julia_plugin_name); ?></th>
                        </tr>
                    </thead>
                    <tbody id="pf_options_sortable"> 
                        <?php $i=0; ?>
                        <tr class="options_fields_group ui-state-default">
                                    <td>
                                        <select class="form-control input-type-select" name="pf_custom_options[pf_meta_field_name][]" id="input-type-1">
                                            <option value="text" <?php selected( trim($options['pf_meta_field_name'][$i]), 'text' ); ?>><?php _e('Text', 'julia'); ?></option>
                                            <option value="select" <?php selected( trim($options['pf_meta_field_name'][$i]), 'select' ); ?>><?php _e('Select', 'julia'); ?></option>
                                            <option value="checkbox" <?php selected( trim($options['pf_meta_field_name'][$i]), 'checkbox' ); ?>><?php _e('Checkbox', 'julia'); ?></option>
                                            <option value="date" <?php selected( trim($options['pf_meta_field_name'][$i]), 'date' ); ?>><?php _e('Date Of Birth', 'julia'); ?></option>
                                            <option value="emailid" <?php selected( trim($options['pf_meta_field_name'][$i]), 'emailid' ); ?>><?php _e('Email ID', 'julia'); ?></option>
                                            <option value="phone_number" <?php selected( trim($options['pf_meta_field_name'][$i]), 'phone_number' ); ?>><?php _e('Phone Number', 'julia'); ?></option>
                                        </select> 
                                    </td>
                                    <td>
                                        <input class="form-control input_field_label_name" placeholder="<?php _e('Label Name( required )','julia'); ?>" required type="text" name="pf_custom_options[pf_meta_label_name][]" value="Name" />
                                        <input class="form-control input_field_uid_name" type="hidden" name="pf_custom_options[pf_meta_label_uid][]" value="<?php echo trim($options['pf_meta_label_uid'][$i]) ?>" />
                                        <textarea cols="50" rows="3" placeholder="<?php _e('Each option on a new line','julia'); ?>" class="select_field_select_options" name="pf_custom_options[pf_meta_field_options][]" ><?php echo trim($options['pf_meta_field_options'][$i]) ?></textarea>
                                        <select class="form-control input-type-select-date-format" name="pf_custom_options[pf_meta_field_date_format][]" id="input-type-1">
                                            <option value="d_m_y" <?php selected( trim($options['pf_meta_field_date_format'][$i]), 'd_m_y' ); ?>><?php _e('DD-MM-YYYY', 'julia'); ?></option>
                                            <option value="y_m_d" <?php selected( trim($options['pf_meta_field_date_format'][$i]), 'y_d_m' ); ?>><?php _e('YYYY-MM-DD', 'julia'); ?></option>
                                            <option value="m_d_y" <?php selected( trim($options['pf_meta_field_date_format'][$i]), 'm_d_y' ); ?>><?php _e('MM-DD-YYYY', 'julia'); ?></option>
                                        </select> 
                                    </td>
                                    <td>
                                        <select class="form-control input-type-select" name="pf_custom_options[pf_option_display_search][]" id="input-type-1">
                                            <option value="true" <?php selected( trim($options['pf_option_display_search'][$i]), 'true' ); ?>>True</option>
                                            <option value="false" <?php selected( trim($options['pf_option_display_search'][$i]), 'false' ); ?>>False</option>
                                        </select> 
                                    </td>
                                    <td>
                                        <select class="form-control input-type-select" name="pf_custom_options[pf_option_visibility][]" id="input-type-1">
                                            <option value="true" <?php selected( trim($options['pf_option_visibility'][$i]), 'true' ); ?>>True</option>
                                            <option value="false" <?php selected( trim($options['pf_option_visibility'][$i]), 'false' ); ?>>False</option>
                                        </select> 
                                    </td>
                                    <td>
                                        <select class="form-control input-type-select" name="pf_custom_options[pf_option_search_range][]" id="input-type-1">
                                            <option value="false" <?php selected( trim($options['pf_option_search_range'][$i]), 'false' ); ?>>False</option>
                                            <option value="true" <?php selected( trim($options['pf_option_search_range'][$i]), 'true' ); ?>>True</option>
                                        </select> 
                                    </td>
                                    <td>
                                        <select class="form-control input-type-select" name="pf_custom_options[pf_option_dsiplay_hover_img][]" id="input-type-1">
                                            <option value="false" <?php selected( trim($options['pf_option_dsiplay_hover_img'][$i]), 'false' ); ?>>False</option>
                                            <option value="true" <?php selected( trim($options['pf_option_dsiplay_hover_img'][$i]), 'true' ); ?>>True</option>
                                        </select> 
                                    </td>
                                    <td>
                                        <select class="form-control input-type-select" name="pf_custom_options[pf_option_dsiplay_set_card][]" id="input-type-1">
                                            <option value="false" <?php selected( trim($options['pf_option_dsiplay_set_card'][$i]), 'false' ); ?>>False</option>
                                            <option value="true" <?php selected( trim($options['pf_option_dsiplay_set_card'][$i]), 'true' ); ?>>True</option>
                                        </select> 
                                    </td>
                                    <td class="fields_options_delete">
                                        <a href="#" class="delete">X</a>
                                    </td>
                                </tr>
                        <?php for ($i=1; $i < ($count-1); $i++) { 
                            if( ( !empty($options['pf_meta_label_name'][$i]) ) &&  ( $options['pf_meta_label_name'][$i] != 'Array') &&  ( $options['pf_meta_label_name'][$i] != '') &&  ( !is_array($options['pf_meta_label_name'][$i]) )){ ?>
                                <tr class="options_fields_group ui-state-default">
                                    <td>
                                        <select class="form-control input-type-select" name="pf_custom_options[pf_meta_field_name][]" id="input-type-1">
                                            <option value="text" <?php selected( trim($options['pf_meta_field_name'][$i]), 'text' ); ?>><?php _e('Text', 'julia'); ?></option>
                                            <option value="select" <?php selected( trim($options['pf_meta_field_name'][$i]), 'select' ); ?>><?php _e('Select', 'julia'); ?></option>
                                            <option value="checkbox" <?php selected( trim($options['pf_meta_field_name'][$i]), 'checkbox' ); ?>><?php _e('Checkbox', 'julia'); ?></option>
                                            <option value="date" <?php selected( trim($options['pf_meta_field_name'][$i]), 'date' ); ?>><?php _e('Date Of Birth', 'julia'); ?></option>
                                            <option value="emailid" <?php selected( trim($options['pf_meta_field_name'][$i]), 'emailid' ); ?>><?php _e('Email ID', 'julia'); ?></option>
                                             <option value="phone_number" <?php selected( trim($options['pf_meta_field_name'][$i]), 'phone_number' ); ?>><?php _e('Phone Number', 'julia'); ?></option>
                                        </select> 
                                    </td>
                                    <td>
                                        <input class="form-control input_field_label_name" placeholder="<?php _e('Label Name( required )','julia'); ?>" required type="text" name="pf_custom_options[pf_meta_label_name][]" value="<?php echo trim($options['pf_meta_label_name'][$i]) ?>" />
                                        <input class="form-control input_field_uid_name" type="hidden" name="pf_custom_options[pf_meta_label_uid][]" value="<?php echo trim($options['pf_meta_label_uid'][$i]) ?>" />
                                        <textarea cols="50" rows="3" placeholder="<?php _e('Each option on a new line','julia'); ?>" class="select_field_select_options" name="pf_custom_options[pf_meta_field_options][]" ><?php echo trim($options['pf_meta_field_options'][$i]) ?></textarea>
                                        <select class="form-control input-type-select-date-format" name="pf_custom_options[pf_meta_field_date_format][]" id="input-type-1">
                                            <option value="d_m_y" <?php selected( trim($options['pf_meta_field_date_format'][$i]), 'd_m_y' ); ?>><?php _e('DD-MM-YYYY', 'julia'); ?></option>
                                            <option value="y_m_d" <?php selected( trim($options['pf_meta_field_date_format'][$i]), 'y_m_d' ); ?>><?php _e('YYYY-MM-DD', 'julia'); ?></option>
                                            <option value="m_d_y" <?php selected( trim($options['pf_meta_field_date_format'][$i]), 'm_d_y' ); ?>><?php _e('MM-DD-YYYY', 'julia'); ?></option>
                                        </select> 
                                    </td>
                                    <td>
                                        <select class="form-control input-type-select" name="pf_custom_options[pf_option_display_search][]" id="input-type-1">
                                            <option value="true" <?php selected( trim($options['pf_option_display_search'][$i]), 'true' ); ?>>True</option>
                                            <option value="false" <?php selected( trim($options['pf_option_display_search'][$i]), 'false' ); ?>>False</option>
                                        </select> 
                                    </td>
                                     <td>
                                        <select class="form-control" name="pf_custom_options[pf_option_visibility][]" id="input-type-1">
                                            <option value="true" <?php selected( trim($options['pf_option_visibility'][$i]), 'true' ); ?>>True</option>
                                            <option value="false" <?php selected( trim($options['pf_option_visibility'][$i]), 'false' ); ?>>False</option>
                                        </select> 
                                    </td>
                                    <td>
                                        <select class="form-control input-type-select" name="pf_custom_options[pf_option_search_range][]" id="input-type-1">
                                            <option value="false" <?php selected( trim($options['pf_option_search_range'][$i]), 'false' ); ?>>False</option>
                                            <option value="true" <?php selected( trim($options['pf_option_search_range'][$i]), 'true' ); ?>>True</option>
                                        </select> 
                                    </td>
                                    <td>
                                        <select class="form-control input-type-select" name="pf_custom_options[pf_option_dsiplay_set_card][]" id="input-type-1">
                                            <option value="false" <?php selected( trim($options['pf_option_dsiplay_set_card'][$i]), 'false' ); ?>>False</option>
                                            <option value="true" <?php selected( trim($options['pf_option_dsiplay_set_card'][$i]), 'true' ); ?>>True</option>
                                        </select> 
                                    </td>
                                    <td>
                                        <select class="form-control input-type-select" name="pf_custom_options[pf_option_dsiplay_hover_img][]" id="input-type-1">
                                            <option value="false" <?php selected( trim($options['pf_option_dsiplay_hover_img'][$i]), 'false' ); ?>>False</option>
                                            <option value="true" <?php selected( trim($options['pf_option_dsiplay_hover_img'][$i]), 'true' ); ?>>True</option>
                                        </select> 
                                    </td>
                                    <td class="fields_options_delete">
                                        <a href="#" class="delete">X</a>
                                    </td>
                                </tr>
                         <?php }
                        } ?>
                    </tbody>                
                </table>
           <?php //$model_options_data .= '</ul>';
            $model_options_data .= '<div class="pf_add_options_button"><a href="#" class="add_icon button button-primary" id="create_option">+</a>';
            $model_options_data .= '<p class="submit">
                <input type="submit" class="button-primary" value="'.__('Save Changes','julia').'" />
                </p></div>'; 
            $model_options_data .= '</div>';
            echo $model_options_data;   ?>            
                
            </form>
        </div>
        <?php   
    }
    function pf_custom_options_validate($input) {
        $input['pf_meta_field_name'][] = $input['pf_meta_field_name'];
        $input['pf_meta_label_name'][] = $input['pf_meta_label_name'];
        $input['pf_meta_field_options'][] = $input['pf_meta_field_options'];
        $input['pf_option_search_range'][] = $input['pf_option_search_range'];
        $input['pf_option_dsiplay_hover_img'][] = $input['pf_option_dsiplay_hover_img'];
        $input['pf_meta_label_uid'][] = $input['pf_meta_label_uid'];
        $input['pf_option_display_search'][] = $input['pf_option_display_search'];
        $input['pf_option_visibility'][] = $input['pf_option_visibility'];
        $input['pf_option_dsiplay_set_card'][] = $input['pf_option_dsiplay_set_card'];
        return $input;
    }
        function pf_import_option_page() {
        ?>
        <div class="wrap">
            <div id="icon-tools" class="icon32"><br /></div>
           <h2><?php echo ucfirst($this->pf_slug_name).' '; _e('Options Data Import','julia'); ?> </h2>
            <?php
                if (isset($_FILES['pf_import']) && check_admin_referer('pf-import')) {
                    if ($_FILES['pf_import']['error'] > 0) {
                        wp_die("Please Choose Upload json format file");
                    }
                    else {
                        WP_Filesystem();
                        global $wp_filesystem;
                        $encode_options = $wp_filesystem->get_contents( $_FILES['pf_import']['tmp_name'] );
                        $options = json_decode($encode_options, true);
                        $file_name = $_FILES['pf_import']['name']; // Get the name of file
                        $file_path = explode('.', $file_name);
                        $file_ext = end($file_path);  // Get extension of file
                        $file_size = $_FILES['pf_import']['size']; // Get size of file
                        if (($file_ext == "json") && ($file_size < 500000)) {
                            foreach ($options as $key => $value) {
                                update_option($key, $value);
                            }                        
                            echo "<div class='updated'><p>".__('All options are restored successfully','julia')."</p></div>";
                        }
                        else {
                            echo "<div class='error'><p>".__('Invalid file or file size too big.','julia')."</p></div>";
                        }
                    }
                }
            ?>
            <p><?php _e('Click Browse button and choose a json file that you backup before.','julia'); ?> </p>
            <p><?php _e('Press Upload File and Import, WordPress do the rest for you.','julia'); ?></p>
            <form method='post' enctype='multipart/form-data'>
                <p class="submit">
                    <?php wp_nonce_field('pf-import'); ?>
                    <input type='file' name='pf_import' class="button primary-button"  />
                    <input type='submit' name='submit' value='<?php _e("Upload File and Import", 'julia') ?>' class="button button-primary"/>
                </p>
            </form>
        </div>
        <?php
    }
    }
    $pf_meta_options = new Julia_Pf_Custom_Options;
}
?>