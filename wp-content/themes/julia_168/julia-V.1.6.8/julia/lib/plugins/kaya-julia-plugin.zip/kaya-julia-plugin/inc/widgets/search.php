<?php
/**
* Search Widget
*/
class Julia_Search_Widget extends WP_Widget
{	
	var $plugin_name;
	function __construct()
	{
		global $julia_plugin_name;
		$this->plugin_name = $julia_plugin_name;
		parent::__construct(
			'julia_model_search',
			__('Julia Advanced Search ( Deprecated )',$this->plugin_name),
			array( 'description' => __('Displays the search result',$this->plugin_name),'class' => 'kaya_readmore_widget')
		);
		
	}
	function widget($arg,$instance){
		$instance = wp_parse_args($instance, array(
			'title' => __('Advanced Search', $this->plugin_name),
			'search_form_input_fields_border_color' => '#cccccc',
			'search_form_input_fields_color' => '#969696',
			'search_form_button_bg_color' => '#FF3333',
			'search_form_button_color' => '#ffffff',
			'search_form_button_hover_bg_color' => '##ff0000',
			'search_form_button_hover_color' => '#ffffff',
			'search_form_button_text' => __('SEARCH', $this->plugin_name),
		));
		echo $arg['before_widget'];
			$css ='';
			$css .='.widget_julia_model_search .kta-search-content-wrapper .kta-search-form input:not(#search_submit):not(#reset_search_submit), .widget_julia_model_search .kta-search-content-wrapper .toggle_search_field select, .widget_julia_model_search .kta-search-content-wrapper ::-webkit-input-placeholder{border-color:'.$instance['search_form_input_fields_border_color'].'!important; color:'.$instance['search_form_input_fields_color'].'!important;} .widget_julia_model_search .kta-search-content-wrapper .kta-search-form label, .widget_julia_model_search .search_box_style h5{color:'.$instance['search_form_input_fields_color'].'!important;}';
			$css .='.widget_julia_model_search .kta-search-content-wrapper .kta-search-form .search_button input{background:'.$instance['search_form_button_bg_color'].'!important; color:'.$instance['search_form_button_color'].'!important;}';
			$css .='.widget_julia_model_search .kta-search-content-wrapper .kta-search-form .search_button input:hover{background:'.$instance['search_form_button_hover_bg_color'].'!important; color:'.$instance['search_form_button_hover_color'].'!important;}';
			echo '<style type="text/css">'.$css.'</style>';
			echo '<div class="kta-search-content-wrapper">';
				if( !empty($instance['title']) ){
					echo $arg['before_title'] . $instance['title'] . $arg['after_title'];
				} 
				if( function_exists('kta_talents_advanced_search_form') ){
					kta_talents_advanced_search_form($instance['search_form_button_text']);
				}
			echo '</div>';
			echo $arg['after_widget'];
	}
	function form($instance){ 
		global $julia_plugin_name;
		$instance = wp_parse_args($instance, array(
			'title' => __('Advanced Search', $this->plugin_name),
			'search_form_input_fields_border_color' => '#cccccc',
			'search_form_input_fields_color' => '#969696',
			'search_form_button_bg_color' => '#FF3333',
			'search_form_button_color' => '#ffffff',
			'search_form_button_hover_bg_color' => '##ff0000',
			'search_form_button_hover_color' => '#ffffff',
			'search_form_button_text' => __('SEARCHsss', $this->plugin_name),
		));
		?>
		<script type='text/javascript'>
        jQuery(document).ready(function($) {
	        jQuery('.search_form_color_pickr').each(function(){
	          jQuery(this).wpColorPicker();
	        }); 
     	});
      	</script> 
      <div class="input-elements-wrapper"> 
      	  <p class="one_fourth">
          <label for="<?php echo $this->get_field_id('title'); ?>"><?php  _e('Title',$julia_plugin_name); ?></label>
          <input id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" class="widefat" value="<?php echo esc_attr($instance['title']) ?>" />
        </p>
        <p class="one_fourth">
          <label for="<?php echo $this->get_field_id('search_form_input_fields_border_color'); ?>"><?php  _e('Search Form Input Fields Border Color',$julia_plugin_name); ?></label>
          <input id="<?php echo $this->get_field_id('search_form_input_fields_border_color'); ?>" name="<?php echo $this->get_field_name('search_form_input_fields_border_color'); ?>" type="text" class="search_form_color_pickr" value="<?php echo esc_attr($instance['search_form_input_fields_border_color']) ?>" />
        </p>
        <p class="one_fourth">
          <label for="<?php echo $this->get_field_id('search_form_input_fields_color'); ?>"><?php  _e('Search Form Input Fields Color',$julia_plugin_name); ?></label>
          <input id="<?php echo $this->get_field_id('search_form_input_fields_color'); ?>" name="<?php echo $this->get_field_name('search_form_input_fields_color'); ?>" type="text" class="search_form_color_pickr" value="<?php echo esc_attr($instance['search_form_input_fields_color']) ?>" />
        </p>
        <p class="one_fourth_last">
          <label for="<?php echo $this->get_field_id('search_form_button_text'); ?>"><?php  _e('Search Form Button Text',$julia_plugin_name); ?></label>
          <input id="<?php echo $this->get_field_id('search_form_button_text'); ?>" name="<?php echo $this->get_field_name('search_form_button_text'); ?>" type="text" class="widefat" value="<?php echo esc_attr($instance['search_form_button_text']) ?>" />
        </p>
        <p class="one_fourth" style="clear:both;">
          <label for="<?php echo $this->get_field_id('search_form_button_bg_color'); ?>"><?php  _e('Search Form Button BG Color',$julia_plugin_name); ?></label>
          <input id="<?php echo $this->get_field_id('search_form_button_bg_color'); ?>" name="<?php echo $this->get_field_name('search_form_button_bg_color'); ?>" type="text" class="search_form_color_pickr" value="<?php echo esc_attr($instance['search_form_button_bg_color']) ?>" />
        </p>
        <p class="one_fourth" >
          <label for="<?php echo $this->get_field_id('search_form_button_color'); ?>"><?php  _e('Search Form Button Color',$julia_plugin_name); ?></label>
          <input id="<?php echo $this->get_field_id('search_form_button_color'); ?>" name="<?php echo $this->get_field_name('search_form_button_color'); ?>" type="text" class="search_form_color_pickr" value="<?php echo esc_attr($instance['search_form_button_color']) ?>" />
        </p>
        <p class="one_fourth">
          <label for="<?php echo $this->get_field_id('search_form_button_hover_bg_color'); ?>"><?php  _e('Search Form Button Hover BG Color',$julia_plugin_name); ?></label>
          <input id="<?php echo $this->get_field_id('search_form_button_hover_bg_color'); ?>" name="<?php echo $this->get_field_name('search_form_button_hover_bg_color'); ?>" type="text" class="search_form_color_pickr" value="<?php echo esc_attr($instance['search_form_button_hover_bg_color']) ?>" />
        </p>
        <p class="one_fourth_last">
          <label for="<?php echo $this->get_field_id('search_form_button_hover_color'); ?>"><?php  _e('Search Form Button Hover Color',$julia_plugin_name); ?></label>
          <input id="<?php echo $this->get_field_id('search_form_button_hover_color'); ?>" name="<?php echo $this->get_field_name('search_form_button_hover_color'); ?>" type="text" class="search_form_color_pickr" value="<?php echo esc_attr($instance['search_form_button_hover_color']) ?>" />
        </p>
        
      </div>	
	<?php }
}
julia_kaya_register_widgets('search', __FILE__);
?>