<?php
function julia_kaya_admin_css(){
	$model_disable_options = julia_kaya_admin_model_tabs();
	$css = '';
	if( $model_disable_options[8] == '1' ){
		$css .= '#portfolio_model_images{ display:none; }';
	}else{
		$css .= '#portfolio_model_images{ display:block; }';
	}
	if( $model_disable_options[9]== '1' ){
		$css .= '#portfolio_tab2_images{ display:none; }';
	}else{
		$css .= '#portfolio_tab2_images{ display:block; }';
	}
	if( $model_disable_options[10] == '1' ){
		$css .= '#portfolio_tab3_images{ display:none; }';
	}else{
		$css .= '#portfolio_tab3_images{ display:block; }';
	}
	if( $model_disable_options[11]== '1' ){
		$css .= '#portfolio_tab4_images{ display:none; }';
	}else{
		$css .= '#portfolio_tab3_images{ display:block; }';
	}
	if($model_disable_options[12] == '1' ){
		$css .= '#portfolio_tab5_images{ display:none; }';
	}
	if( $model_disable_options[13] == '1' ){
		$css .= '#portfolio_model_videos{ display:none; }';
	}else{
		$css .= '#portfolio_model_videos{ display:block; }';
	}
	if( $model_disable_options[14] == '1' ){
		$css .= '#portfolio_setcard_images{ display:none; }';
	}else{
		$css .= '#portfolio_setcard_images{ display:block; }';	
	}
	if( $model_disable_options[15] == '1' ){
		$css .= '#portfolio_model_biography{ display:none; }';
	}else{
		$css .= '#portfolio_model_biography{ display:block; }';
	}
	echo '<style>'.$css.'</style>';
}
add_action('admin_head', 'julia_kaya_admin_css')
?>