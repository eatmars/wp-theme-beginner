<?php
class Julia_Register_Login_Widget extends WP_Widget{
	public function __construct(){
		global $julia_plugin_name, $login_page;
	    parent::__construct('kaya-user-register-login',
	    __('Julia - Register / Login ( Depricated )',$julia_plugin_name),
	    array('description' => __('It will be removed, insted  use "KTA - Registration", "KTA - Login", "KTA - Forgot Password"', $julia_plugin_name))
	    );
	    add_filter('send_password_change_email', '__return_false');
	}
	private function julia_kaya_user_registration($disable_last_name, $disable_phone_number, $disable_website, $user_error_register_msg, $user_confirmation_mail_msg){
		global $julia_plugin_name, $success, $err;
		$first_name = esc_sql(trim($_POST['first_name']));
	    $last_name = ($disable_last_name !='on') ? esc_sql(trim($_POST['last_name'])) : '';
	    $email = esc_sql(trim($_POST['email']));
	    $url = ( $disable_website !='on' ) ? esc_sql(trim($_POST['url'])) : '';
	    $username = esc_sql(trim($_POST['username']));
	    $phone_numer = ( $disable_phone_number !='on' ) ? esc_sql(trim($_POST['phone_numer'])) : ''; 
	    $password = wp_generate_password(12, false);       
	    if( $email == "" || $username == "" || $first_name == "" || ( ($disable_last_name !='on') ? esc_sql(trim($_POST['last_name'])) : '1' ) == "" || ( ( $disable_phone_number !='on' ) ? esc_sql(trim($_POST['phone_numer'])) : '1' ) == "") {
	        $err = __('Please don\'t leave the required fields.', $julia_plugin_name);
	    }else if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
	        $err = __('Invalid email address.', $julia_plugin_name);
	    }else if(email_exists($email) ) {
	        $err = __('Email already exist.', $julia_plugin_name);
	    }else {     
	        $user_id = wp_insert_user( array ('first_name' => apply_filters('pre_user_first_name', $first_name), 'last_name' => apply_filters('pre_user_last_name', $last_name), 'user_pass' => apply_filters('pre_user_user_pass', $password), 'user_login' => apply_filters('pre_user_user_login', $username), 'user_email' => apply_filters('pre_user_user_email', $email), 'user_url' => apply_filters('pre_user_user_url', $url), 'kaya_phone_num' => apply_filters('pre_user_kaya_phone_num', $phone_numer), 'role' => 'user') );
	        if( is_wp_error($user_id) ) {
	            $err = $user_error_register_msg;
	        } else {
	            do_action('user_register', $user_id);
	            $admin_email = get_option('admin_email');
				$confirmation_subject = __('Confirmation - Registration to',$julia_plugin_name).get_bloginfo('name');
				$headers = "MIME-Version: 1.0\r\n";
				$headers .= "From:".$admin_email."\r\n";
				$headers .= "Reply-To: ".$admin_email."" . "\r\n";
				$headers .= 'Content-type: text/html; charset=iso-8859-1'."\r\n";
				$confirmation_message = '<html><body>';
				$confirmation_message .= __('Hi ',$julia_plugin_name).$first_name.' '.$last_name.',<br /></br />Thank you for registering with '.get_bloginfo('name').' '.$user_confirmation_mail_msg.' <br /><br />'
				.'<strong>'.__('Username: ',$julia_plugin_name).'</strong> '.trim($username)
				.'<br /><strong>Password:</strong> '.trim($password)
				.'<br /><br />';
				$confirmation_message .=  '</body></html>';// Sending email
				mail($email, $confirmation_subject, $confirmation_message, $headers);
				$success = __('You\'re successfully register', $julia_plugin_name);
	       	}            
	    }
	}
	public function widget($args, $instance){		
		echo $args['before_widget'];
		global $julia_plugin_name, $login_page, $success, $err, $kta_options;
		$instance = wp_parse_args( $instance, array(
			'user_login_tab_name' => __('User Login Form', $julia_plugin_name),
			'user_register_tab_name' => __('User Register Form', $julia_plugin_name),
			'user_fogot_password_tab_name' => __('Forgot Password', $julia_plugin_name),
			'tabs_bg_color' => '#ffffff',
			'tabs_title_color' => '#333333',
			'tabs_active_title_color' => '#ffffff',
			'tabs_active_bg_color' => '#ff3333',
			'tabs_font_size' => '18',
			'tabs_letter_spacing' => '0',
			'tabs_font_weight' => 'normal',
			'button_bg_color' =>'#ff3333',
		    'button_text_color' =>'#ffffff',
		    'button_bg_hover_color' => '#ff3333',
		    'button_text_hover_color' => '#ffffff',
		    'button_text_font_size' =>'15',
		    'tabs_form_bg_color' => '#ffffff',
		    'input_fields_border_color' => '#cccccc',
		    'input_fields_text_color' => '#757575',
		    'button_text_letter_spacing' =>'0',
		    'tabs_content_color' => '#757575',
		    'error_message_text_color' => '#dd3333',
		    'success_message_text_color' => '#dd3333',
		    'user_success_register_msg' => __('You\'re Successfully Register. Please Check your Email.'),
		    'user_forgot_password_msg' => __('Please enter your email address. You will receive a new password via email.', $julia_plugin_name),
		    'user_login_page_redirect_to' => '',
		    'user_confirmation_mail_msg' => __("Your account has been set up and you can log in using the following details. Once you have logged in, please ensure that you visit the Site Admin and change you password so that you don't forget it in the future. ",$julia_plugin_name),
		    'user_forgot_password_success_msg' => esc_html__('Check your email address for you new password.', $julia_plugin_name),
		    'user_login_error_msg' => esc_html__('Incorrect User Name or Password', $julia_plugin_name),
		    'user_forgot_password_error_msg' => __('Invalid Email', $julia_plugin_name),
		    'user_error_register_msg' => __('Error on user creation.', $julia_plugin_name),
		    'enable_captcha' => '',
		    'captcha_site_key' => '',
		    'captcha_secret_key' => '',
		     'captcha_verify_fail_message' => 'Robot verification failed, please try again.',
		    'captcha_check_error_message' => 'Please click on the reCAPTCHA box.',
		    'disable_last_name' => '',
		    'disable_phone_number' => '',
		    'disable_website' => '',
		    'login_field_user_name_text' => __('User Name',$julia_plugin_name),
		    'login_field_password_text' => __('Password',$julia_plugin_name),
		    'register_form_first_name_text' => __('First Name',$julia_plugin_name),
		    'register_form_last_name_text'  => 'Last Name',
		    'register_form_email_text'      => 'Email(abc@gmail.com)',
		    'register_form_phone_number'    => 'Phone Number',
		    'register_form_website_text'    => 'Website(optional)',
		    'register_form_user_name'       => 'User Name',
		    'register_form_conform_text'    => 'Registration confirmation will be e-mailed to you.',
		    'register_button_text'          => 'REGISTER',
		    'User_login_text'              => 'User E-mail:',
		));
		$login_page = $instance['user_login_page_redirect_to']; ?>
		<?php 
		 wp_enqueue_script('jquery-ui-accordion');
		if( $instance['enable_captcha'] == 'on' ){ 
			wp_enqueue_script('recaptcha', 'https://www.google.com/recaptcha/api.js'); 
		} ?>
		<script type="text/javascript">
			jQuery(document).ready(function($) {
				"use strict";
			$( ".user_register_form_wrapper" ).accordion({
				autoHeight: true,
				collapsible: false,
				heightStyle: "content",
				navigation: false,
				header: "h3"
			});
			$('.user_register_form_wrapper').each(function(){
				$(this).find('h3').click(function(){
					 window.location.hash = $(this).find('a').attr('href');
				});
			});
			var hash = window.location.hash;
				var accorion_url = hash.substring(hash.lastIndexOf('#'), hash.length);
				if( accorion_url !='' ){
					$('.user_register_form_wrapper').find('a[href*="'+ accorion_url + '"]').closest('h3').trigger('click');
				}
			});    
		</script>
		<?php
		$user_login_page_redirect_to = get_theme_mod('login_redirect_page_id') ? get_theme_mod('login_redirect_page_id') : '';
		$css  ='.user_register_form_wrapper input, .user_register_form_wrapper input[type="text"]{ border-color:'.$instance['input_fields_border_color'].'; color:'.$instance['input_fields_text_color'].'; }';
		$css .='.user_register_form_wrapper p, .user_register_form_wrapper, .user_register_form_wrapper .user_logout.ui-accordion-header-active.ui-state-active,  .user_register_form_wrapper .user_logout.ui-accordion-header-active.ui-state-active a{ color:'.$instance['tabs_content_color'].'!important; }';
		$css .='.user_register_form_wrapper button, #wp-submit.readmore_button{ background:'.$instance['button_bg_color'].'!important; color:'.$instance['button_text_color'].'!important; }';
		$css .='.user_register_form_wrapper button:hover, #wp-submit.readmore_button:hover{ background:'.$instance['button_bg_hover_color'].'!important; color:'.$instance['button_text_hover_color'].'!important; }';
		$css .='.user_register_form_wrapper ::-moz-placeholder{ color:'.$instance['input_fields_text_color'].'; }';
		$css .='.user_register_form_wrapper ::-webkit-input-placeholder{ color:'.$instance['input_fields_text_color'].'; }';
		$css .='.user_register_form_wrapper .ui-accordion-header-active.ui-state-active, .user_register_form_wrapper .accordion_text_wrapper:hover,	.user_register_form_wrapper .ui-accordion-header-active.ui-state-active a, .user_register_form_wrapper .accordion_text_wrapper:hover a{ background:'.$instance['tabs_active_bg_color'].'!important;  color:'.$instance['tabs_active_title_color'].'!important; }';
		if( empty($instance['tabs_form_bg_color']) ){
			$css .='.user_register_form_wrapper .ui-accordion-content{ padding:0px; }';
		}
		echo '<style>'.$css.'</style>'; 
		/* Captcha Settings */
		$captcha_site_key = !empty($kta_options->captcha_sitekey) ? $kta_options->captcha_sitekey : '';
	    $captcha_secret_key = !empty($kta_options->captcha_security_key) ? $kta_options->captcha_security_key : '';
	    $captcha_enable = !empty($kta_options->captcha_enable) ? $kta_options->captcha_enable : '0';
	    $captcha_error_message = !empty($kta_options->captcha_error_msg) ? $kta_options->captcha_error_msg  : __('pleace check recaptcha','julia');
    /* End */
		echo '<div class="user_register_form_wrapper">';
	    $err = '';
	    $success = '';
	    $tab_content_bg = $instance['tabs_form_bg_color'] ? 'background-color'.$instance['tabs_form_bg_color'].';' :'';
	    $content_padding = $instance['tabs_form_bg_color'] ? '' : 'padding:0px;';
	    global $wpdb, $PasswordHash, $current_user, $user_ID, $user_login, $current_user_posts;
	    if (is_user_logged_in()) {
	                echo '<div class="user_logout"> '.esc_html__('Hello', $julia_plugin_name).', '. $user_login. '. '.esc_html__('You are already logged in. ',$julia_plugin_name).'&nbsp;<a href="'.wp_logout_url( home_url() ).'">Logout</a></div>';
	            } else {  
	    echo '<h3 class="accordion_text_wrapper" style="background-color:'.$instance['tabs_bg_color'].'; color:'.$instance['tabs_title_color'].'; font-size:'.$instance['tabs_font_size'].'px; letter-spacing:'.$instance['tabs_letter_spacing'].'px; font-weight:'.$instance['tabs_font_weight'].';"><a href="#login" style="color:'.$instance['tabs_title_color'].';">'.$instance['user_login_tab_name'].'</a></h3>';
		echo '<div style="background-color:'.$instance['tabs_form_bg_color'].';">';
		echo '<div class="user_login_form" data-password="'.( $instance['login_field_password_text'] ? $instance['login_field_password_text'] : 'Password' ).'" data-username="'.( $instance['login_field_user_name_text'] ? $instance['login_field_user_name_text'] : 'User Name' ).'">';  
	  	 	// User Login Form
	       	$user_id = get_current_user_id();
	        if(isset($_GET['login']) && $_GET['login'] == 'failed')
	        { ?>
	            <span class="error" style="color:<?php echo $instance['error_message_text_color']; ?>!important"><?php echo trim($instance['user_login_error_msg']); ?></span>
	        <?php  }
	         	if (is_user_logged_in()) {
	            } else {   
	            	$args = array(
	                    'echo'           => true,
	                    'form_id'        => 'loginform',
	                    'label_username' => '',
	                    'redirect'		 => admin_url('index.php'),
	                    'label_password' =>'',
	                    'label_remember' => __( 'Remember Me', $julia_plugin_name ),
	                    'label_log_in'   => __( 'Log In', $julia_plugin_name ),
	                    'id_username'    => 'user_login',
	                    'id_password'    => 'user_pass',
	                    'id_remember'    => 'rememberme',
	                    'id_submit'      => 'wp-submit',
	                    'remember'       => true,
	                    'value_username' => NULL,
	                    'value_remember' => true
	                ); 
	                wp_login_form($args);
	            }
	     ?>
	 </div>
	</div> 
	   <?php  
	   echo '<h3 class="accordion_text_wrapper" style="background-color:'.$instance['tabs_bg_color'].'; color:'.$instance['tabs_title_color'].'; font-size:'.$instance['tabs_font_size'].'px; letter-spacing:'.$instance['tabs_letter_spacing'].'px; font-weight:'.$instance['tabs_font_weight'].';"><a href="#register" style="color:'.$instance['tabs_title_color'].';">'.$instance['user_register_tab_name'].'</a></h3>';
	    echo '<div style="background-color:'.$instance['tabs_form_bg_color'].';">';
	    echo '<div class="user_register_form">'; 
			    if(isset($_POST['user_register_data']) && $_POST['user_register_data'] == 'register' ) { 
			    	if( ($instance['enable_captcha'] == 'on') && trim($captcha_site_key !='') ){
				    	 if(isset($_POST['g-recaptcha-response']) && !empty($_POST['g-recaptcha-response'])){  // Captcha Start
				    	 	//your site secret key
					        $secret = $captcha_secret_key;
					        //get verify response data
					        $verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$secret.'&response='.$_POST['g-recaptcha-response']);
					        $responseData = json_decode($verifyResponse);
					        if($responseData->success){
						        $this->julia_kaya_user_registration($instance['disable_last_name'], $instance['disable_phone_number'], $instance['disable_website'], $instance['user_error_register_msg'], $instance['user_confirmation_mail_msg']); // Registraion Data
						    }else{
						    	$err =  $captcha_error_message;
						    } //Captcha
				        }else{
				        		$err =  $captcha_error_message;
				        } // Captcha End 
			        }else{
			    		$this->julia_kaya_user_registration($instance['disable_last_name'], $instance['disable_phone_number'], $instance['disable_website'], $instance['user_error_register_msg'], $instance['user_confirmation_mail_msg']); // Registraion Data
			    }  	
			    }
			?>
		    <div id="message">
		        <?php 
		            if(! empty($err) ) :
		                echo '<p class="error" style="color:'.$instance['error_message_text_color'].';!important">'.$err.'</p>';
		            endif;
		        if(! empty($success) ) :
		                echo '<p class="success" style="color:'.$instance['success_message_text_color'].';!important">'.$instance['user_success_register_msg'].'</p>';
		         endif;
		        ?>
		    </div> 
		    <form method="post">
		    	<p><input type="text" value="" name="first_name" id="first_name" placeholder="<?php echo $instance['register_form_first_name_text']; ?>" required/></p>
		    	<?php if( $instance['disable_last_name'] != 'on' ){ ?>
		        	<p><input type="text" value="" name="last_name" id="last_name" placeholder="<?php echo $instance['register_form_last_name_text']; ?>"  /></p>
		        <?php } ?>
		        <p><input type="text" value="" name="email" id="email" pattern="[^ @]*@[^ @]*"  placeholder="<?php echo $instance['register_form_email_text']; ?>" required /></p>
		        <?php if( $instance['disable_phone_number'] != 'on' ){ ?>
		        	<p><input type="number" value="" name="phone_numer" id="phone_numer" placeholder="<?php echo $instance['register_form_phone_number'];  ?>" required /></p>
		        <?php }
		        if( $instance['disable_website'] != 'on' ){ ?>
		        	<p><input type="text" value="" name="url" id="url" placeholder="<?php echo $instance['register_form_website_text']; ?>"  /></p>
		        <?php }	?>
		        <p><input type="text" value="" name="username" id="username" placeholder="<?php echo $instance['register_form_user_name']; ?>" required /></p>
		        <?php if( ($instance['enable_captcha'] == 'on') && trim($captcha_site_key !='') ){  ?>
		        	<div class="g-recaptcha" data-sitekey="<?php echo $captcha_site_key; ?>"></div>
		        <?php } ?>
		        <p><?php echo $instance['register_form_conform_text']; ?></p>
		        <button type="submit" name="user_register" class="button readmore_button" ><?php echo $instance['register_button_text'];?></button>
		        <input type="hidden" name="user_register_data" value="register" />
		    </form>
		</div> 
	</div>
		<?php
	 	 echo '<h3 class="accordion_text_wrapper" style="background-color:'.$instance['tabs_bg_color'].'; color:'.$instance['tabs_title_color'].'; font-size:'.$instance['tabs_font_size'].'px; letter-spacing:'.$instance['tabs_letter_spacing'].'px; font-weight:'.$instance['tabs_font_weight'].';"><a href="#forgot_pass" style="color:'.$instance['tabs_title_color'].';">'.$instance['user_fogot_password_tab_name'].'</a></h3>';
	 	echo '<div style="background-color:'.$instance['tabs_form_bg_color'].';">';
	 	 echo '<div class="user_forget_password_form">'; 
	 	if( isset( $_POST['user_get_new_password'] ) && 'reset' == $_POST['user_get_new_password'] ) 
	        {
	            $email = trim($_POST['user_login']);            
	            if( empty( $email ) ) {
	                $error = __('Enter e-mail address..',$julia_plugin_name);
	            } else if( ! is_email( $email )) {
	                 $error = __('Invalid e-mail address.',$julia_plugin_name);
	            } else if( ! email_exists( $email ) ) {
	                 $error = __('There is no user registered with that email address.',$julia_plugin_name);
	            } else {                
	                $random_password = wp_generate_password( 12, false );
	                $user = get_user_by( 'email', $email );                
	                $update_user = wp_update_user( array (
	                        'ID' => $user->ID, 
	                        'user_pass' => $random_password
	                    )
	                );                
	                // if  update user return true then lets send user an email containing the new password
	                if( $update_user ) {
	                	 $message = '';
	                    $to = $email;
		                $subject 	= __('Your new password',$julia_plugin_name);
		                $sender 	= get_option('name');
		                $message   .= __('User Name is',$julia_plugin_name).': '.$user->user_login."<br />";
		                $message   .= __('Your New Password is',$julia_plugin_name).': '.$random_password;		                
		                $headers[] 	= 'MIME-Version: 1.0' . "\r\n";
		                $headers[]  = 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
		                $headers[]  = "X-Mailer: PHP \r\n";
		                $headers[] 	= 'From: '.$sender.' < '.$email.'>' . "\r\n";
               			$mail = wp_mail( $to, $subject, $message, $headers );
	                    if( $mail )
	                        $success = $instance['user_forgot_password_success_msg'];                        
		                } else {
		                    $error = $instance['user_forgot_password_error_msg'];
		                }                
	            	}            
	            if( ! empty( $error ) )
	                echo '<div class="message"><p class="error_login" style="color:'.$instance['error_message_text_color'].'!important;">'. $error .'</p></div>';            
	            if( ! empty( $success ) )
	                echo '<div class="error_login"><p class="success" style="color:'.$instance['success_message_text_color'].'!important;">'. $success .'</p></div>';
	        	}
	   		 ?> 
	    <form method="post">
	            <?php if( !empty($instance['user_forgot_password_msg']) ){ echo '<p>'.$instance['user_forgot_password_msg'].'</p>'; } ?>
	            
	                <?php $user_login = isset( $_POST['user_login'] ) ? $_POST['user_login'] : ''; ?>

	                <p><input type="text" value="" name="user_login" id="user_login" placeholder="<?php echo $instance['User_login_text']; ?>" required/></p>

	                <input type="hidden" name="user_get_new_password" value="reset" />
	                <input type="submit" value="<?php _e('Get New Password', $julia_plugin_name); ?>" class="readmore_button" id="wp-submit" />
	        </fieldset> 
	    </form> 
	 </div>
	</div>
	 <?php } ?>
			<?php    echo '</div></div>';
		}
	public function form($instance){
		global $julia_plugin_name;
		$instance = wp_parse_args($instance,array(
			'user_login_tab_name' => __('User Login Form', $julia_plugin_name),
			'user_register_tab_name' => __('User Register Form', $julia_plugin_name),
			'user_fogot_password_tab_name' => __('Forgot Password', $julia_plugin_name),
			'tabs_bg_color' => '#ffffff',
			'tabs_title_color' => '#333333',
			'tabs_active_title_color' => '#ffffff',
			'tabs_active_bg_color' => '#ff3333',
			'tabs_font_size' => '18',
			'tabs_letter_spacing' => '0',
			'tabs_font_weight' => 'normal',
			'button_bg_color' =>'#ff3333',
		    'button_text_color' =>'#ffffff',
		    'button_bg_hover_color' => '#ff3333',
		    'button_text_hover_color' => '#ffffff',
		    'button_text_font_size' =>'15',
		    'tabs_form_bg_color' => '#ffffff',
		    'input_fields_border_color' => '#cccccc',
		    'input_fields_text_color' => '#757575',
		    'button_text_letter_spacing' =>'0',
		    'tabs_content_color' => '#757575',
		    'error_message_text_color' => '#dd3333',
		    'success_message_text_color' => '#dd3333',
		    'user_success_register_msg' => __('You\'re Successfully Register. Please Check your Email.'),
		    'user_forgot_password_msg' => __('Please enter your email address. You will receive a new password via email.', $julia_plugin_name),
		    'user_login_page_redirect_to' => '',
		    'user_confirmation_mail_msg' => __("Your account has been set up and you can log in using the following details. Once you have logged in, please ensure that you visit the Site Admin and change you password so that you don't forget it in the future. ",$julia_plugin_name),
		    'user_forgot_password_success_msg' => esc_html__('Check your email address for you new password.', $julia_plugin_name),
		    'user_login_error_msg' => esc_html__('Incorrect User Name or Password', $julia_plugin_name),
		    'user_forgot_password_error_msg' => __('Invalid Email', $julia_plugin_name),
		    'user_error_register_msg' => __('Error on user creation.', $julia_plugin_name),
		    'enable_captcha' => '',
		    'captcha_site_key' => '',
		    'captcha_secret_key' => '',
		    'captcha_verify_fail_message' => 'Robot verification failed, please try again.',
		    'captcha_check_error_message' => 'Please click on the reCAPTCHA box.',
		    'disable_last_name' => '',
		    'disable_phone_number' => '',
		    'disable_website' => '',
		    'login_field_user_name_text' => 'User Name',
		    'login_field_password_text' => 'Password',
		    'register_form_first_name_text' => 'First Name',
		    'register_form_last_name_text'  => 'Last Name',
		    'register_form_email_text'      => 'Email(abc@gmail.com)',
		    'register_form_phone_number'    => 'Phone Number',
		    'register_form_website_text'    => 'Website(optional)',
		    'register_form_user_name'       => 'User Name',
		    'register_form_conform_text'    => 'Registration confirmation will be e-mailed to you.',
		    'register_button_text'          => 'REGISTER',
		    'User_login_text'              => 'User E-mail:',
		)); ?>
		<script type='text/javascript'>
		  jQuery(document).ready(function($) {
		    jQuery('.user_regiser_login_color_pickr').each(function(){
		      jQuery(this).wpColorPicker();
		    }); 
		  });
		  </script>
		<div class="input-elements-wrapper">
			<p class="one_fourth">
		        <label for="<?php echo $this->get_field_id('user_login_tab_name') ?>"><?php _e('User Login Tab Name',$julia_plugin_name); ?>  </label>
		        <input type="text" name="<?php echo $this->get_field_name('user_login_tab_name') ?>" id="<?php echo $this->get_field_id('user_login_tab_name') ?>" class="" value="<?php echo esc_attr($instance['user_login_tab_name']) ?>" />
	      	</p>
	      	<p class="one_fourth">
		        <label for="<?php echo $this->get_field_id('user_register_tab_name') ?>"><?php _e('User Register Tab Name',$julia_plugin_name); ?>  </label>
		        <input type="text" name="<?php echo $this->get_field_name('user_register_tab_name') ?>" id="<?php echo $this->get_field_id('user_register_tab_name') ?>" class="" value="<?php echo esc_attr($instance['user_register_tab_name']) ?>" />
	      	</p>
	      	<p class="one_fourth">
		        <label for="<?php echo $this->get_field_id('user_fogot_password_tab_name') ?>"><?php _e('Forgot Password Tab Name',$julia_plugin_name); ?>  </label>
		        <input type="text" name="<?php echo $this->get_field_name('user_fogot_password_tab_name') ?>" id="<?php echo $this->get_field_id('user_fogot_password_tab_name') ?>" class="" value="<?php echo esc_attr($instance['user_fogot_password_tab_name']) ?>" />
	      	</p>
	      	 <p class="one_fourth_last">
		        <label for="<?php echo $this->get_field_id('tabs_bg_color') ?>"><?php _e('Tabs Bg Color',$julia_plugin_name); ?></label>
		        <input type="text" name="<?php echo $this->get_field_name('tabs_bg_color') ?>" id="<?php echo $this->get_field_id('tabs_bg_color') ?>" class="user_regiser_login_color_pickr" value="<?php echo esc_attr($instance['tabs_bg_color']) ?>" />
		      </p>
		      <p class="one_fourth" style="clear:both;">
		        <label for="<?php echo $this->get_field_id('tabs_title_color') ?>"><?php _e('Tabs Title Color',$julia_plugin_name); ?></label>
		        <input type="text" name="<?php echo $this->get_field_name('tabs_title_color') ?>" id="<?php echo $this->get_field_id('tabs_title_color') ?>"  class="user_regiser_login_color_pickr" value="<?php echo esc_attr($instance['tabs_title_color']) ?>" />
		      </p>
		      <p class="one_fourth">
		        <label for="<?php echo $this->get_field_id('tabs_active_bg_color') ?>"><?php _e('Tabs Active Bg Color',$julia_plugin_name); ?></label>
		        <input type="text" name="<?php echo $this->get_field_name('tabs_active_bg_color') ?>" id="<?php echo $this->get_field_id('tabs_active_bg_color') ?>" class="user_regiser_login_color_pickr" value="<?php echo esc_attr($instance['tabs_active_bg_color']) ?>" />
		      </p>
		      <p class="one_fourth">
		        <label for="<?php echo $this->get_field_id('tabs_active_title_color') ?>"><?php _e('Tabs Active Title Color',$julia_plugin_name); ?></label>
		        <input type="text" name="<?php echo $this->get_field_name('tabs_active_title_color') ?>" id="<?php echo $this->get_field_id('tabs_active_title_color') ?>"  class="user_regiser_login_color_pickr" value="<?php echo esc_attr($instance['tabs_active_title_color']) ?>" />
		      </p>
		      <p class="one_fourth_last">
		        <label for="<?php echo $this->get_field_id('tabs_font_size') ?>"><?php _e('Tabs Font Size',$julia_plugin_name); ?></label>
		        <input type="text" name="<?php echo $this->get_field_name('tabs_font_size') ?>" id="<?php echo $this->get_field_id('tabs_font_size') ?>"  value="<?php echo esc_attr($instance['tabs_font_size']) ?>" class="small-text" /><small><?php _e('px', $julia_plugin_name); ?></small>
		      </p>
		       <p class="one_fourth" style="clear:both;">
		        <label for="<?php echo $this->get_field_id('tabs_letter_spacing') ?>">  <?php _e('Tabs Letter Spacing',$julia_plugin_name) ?>  </label>
		        <input type="text" id="<?php echo $this->get_field_id('tabs_letter_spacing') ?>" class="small-text" name="<?php echo $this->get_field_name('tabs_letter_spacing') ?>" value = "<?php echo esc_attr($instance['tabs_letter_spacing']) ?>" />
		        <small><?php _e('px',$julia_plugin_name);?></small>
		      </p>
		      <p class="one_fourth">
		        <label for="<?php echo $this->get_field_id('tabs_font_weight') ?>"> <?php _e('Tabs Font Weight',$julia_plugin_name) ?></label>
		        <select id="<?php echo $this->get_field_id('tabs_font_weight') ?>" name="<?php echo $this->get_field_name('tabs_font_weight') ?>">
		          <option value="normal" <?php selected('normal', $instance['tabs_font_weight']) ?>> <?php esc_html_e('Normal', $julia_plugin_name) ?>   </option>
		          <option value="bold" <?php selected('bold', $instance['tabs_font_weight']) ?>>  <?php esc_html_e('Bold',$julia_plugin_name) ?></option>
		        </select>
		      </p> 
		      <!-- inpt fields color -->
		      <p class="one_fourth">
		        <label for="<?php echo $this->get_field_id('tabs_form_bg_color') ?>"><?php _e('Forms background Color',$julia_plugin_name); ?></label>
		        <input type="text" name="<?php echo $this->get_field_name('tabs_form_bg_color') ?>" id="<?php echo $this->get_field_id('tabs_form_bg_color') ?>" class="user_regiser_login_color_pickr" value="<?php echo esc_attr($instance['tabs_form_bg_color']) ?>" />
		      </p>
		      <p class="one_fourth_last">
		        <label for="<?php echo $this->get_field_id('input_fields_border_color') ?>"><?php _e('Forms Input Fields Border Color',$julia_plugin_name); ?></label>
		        <input type="text" name="<?php echo $this->get_field_name('input_fields_border_color') ?>" id="<?php echo $this->get_field_id('input_fields_border_color') ?>" class="user_regiser_login_color_pickr" value="<?php echo esc_attr($instance['input_fields_border_color']) ?>" />
		      </p>
		      <p class="one_fourth" style="clear:both;">
		        <label for="<?php echo $this->get_field_id('input_fields_text_color') ?>"><?php _e('Forms Input Fields Text Color',$julia_plugin_name); ?></label>
		        <input type="text" name="<?php echo $this->get_field_name('input_fields_text_color') ?>" id="<?php echo $this->get_field_id('input_fields_text_color') ?>"  class="user_regiser_login_color_pickr" value="<?php echo esc_attr($instance['input_fields_text_color']) ?>" />
		      </p>    
		      <p class="one_fourth">
		        <label for="<?php echo $this->get_field_id('tabs_content_color') ?>"><?php _e('Tabs Content Color',$julia_plugin_name); ?></label>
		        <input type="text" name="<?php echo $this->get_field_name('tabs_content_color') ?>" id="<?php echo $this->get_field_id('tabs_content_color') ?>"  class="user_regiser_login_color_pickr" value="<?php echo esc_attr($instance['tabs_content_color']) ?>" />
		      </p>
		      <p class="one_fourth">
		        <label for="<?php echo $this->get_field_id('error_message_text_color') ?>"><?php _e('Error Message Text Color',$julia_plugin_name); ?></label>
		        <input type="text" name="<?php echo $this->get_field_name('error_message_text_color') ?>" id="<?php echo $this->get_field_id('error_message_text_color') ?>"  class="user_regiser_login_color_pickr" value="<?php echo esc_attr($instance['error_message_text_color']) ?>" />
		      </p>    
		      <p class="one_fourth_last">
		        <label for="<?php echo $this->get_field_id('success_message_text_color') ?>"><?php _e('Success Message Color',$julia_plugin_name); ?></label>
		        <input type="text" name="<?php echo $this->get_field_name('success_message_text_color') ?>" id="<?php echo $this->get_field_id('success_message_text_color') ?>"  class="user_regiser_login_color_pickr" value="<?php echo esc_attr($instance['success_message_text_color']) ?>" />
		      </p>
     	 </div>
     	<div class="input-elements-wrapper"> 
		    <p class="one_fourth">
		      <label for="<?php echo $this->get_field_id('button_text_color') ?>"><?php _e('Button Text Color',$julia_plugin_name); ?></label>
		      <input type="text" name="<?php echo $this->get_field_name('button_text_color') ?>" id="<?php echo $this->get_field_id('button_text_color') ?>" class="user_regiser_login_color_pickr" value="<?php echo $instance['button_text_color'] ?>" />
		    </p>
		    <p class="one_fourth">
		      <label for="<?php echo $this->get_field_id('button_bg_color') ?>"><?php _e('Button Bg  Color',$julia_plugin_name); ?></label>
		      <input type="text" name="<?php echo $this->get_field_name('button_bg_color') ?>" id="<?php echo $this->get_field_id('button_bg_color') ?>" class="user_regiser_login_color_pickr" value="<?php echo $instance['button_bg_color'] ?>" />
		    </p>
		    <p class="one_fourth">
		      <label for="<?php echo $this->get_field_id('button_text_hover_color') ?>"><?php _e('Button Text Hover Color',$julia_plugin_name); ?></label>
		      <input type="text" name="<?php echo $this->get_field_name('button_text_hover_color') ?>" id="<?php echo $this->get_field_id('button_text_hover_color') ?>" class="user_regiser_login_color_pickr" value="<?php echo esc_attr($instance['button_text_hover_color']) ?>" />
		    </p>
		    <p class="one_fourth_last">
		      <label for="<?php echo $this->get_field_id('button_bg_hover_color') ?>"><?php _e('Button Bg Hover Color',$julia_plugin_name); ?></label>
		      <input type="text" name="<?php echo $this->get_field_name('button_bg_hover_color') ?>" id="<?php echo $this->get_field_id('button_bg_hover_color') ?>" class="user_regiser_login_color_pickr" value="<?php echo esc_attr($instance['button_bg_hover_color']) ?>" />
		    </p>
		    <p class="one_fourth">
		      <label for="<?php echo $this->get_field_id('button_text_font_size') ?>">  <?php _e('Button Font Size',$julia_plugin_name) ?>  </label>
		      <input type="text" class="small-text" id="<?php echo $this->get_field_id('button_text_font_size') ?>" name="<?php echo $this->get_field_name('button_text_font_size') ?>" value="<?php echo esc_attr($instance['button_text_font_size']) ?>" />
		      <small>  <?php _e('px',$julia_plugin_name) ?> </small> 
		    </p>
		    <p class="one_fourth">
		      <label for="<?php echo $this->get_field_id('button_text_letter_spacing') ?>">  <?php _e('Button Text Letter Spacing',$julia_plugin_name) ?>  </label>
		      <input type="text" class="small-text" id="<?php echo $this->get_field_id('button_text_letter_spacing') ?>" name="<?php echo $this->get_field_name('button_text_letter_spacing') ?>" value="<?php echo esc_attr($instance['button_text_letter_spacing']) ?>" />
		      <small>  <?php _e('px',$julia_plugin_name) ?>  </small> 
		    </p>
		  </div>
		  <div class="input-elements-wrapper">
		  	<p class="one_fourth">
			  <label for="<?php echo $this->get_field_id('disable_last_name') ?>">  <?php _e('Disable Last Name Field',$julia_plugin_name)?>  </label>
			  <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("disable_last_name"); ?>" name="<?php echo $this->get_field_name("disable_last_name"); ?>"<?php checked( (bool) $instance["disable_last_name"], true ); ?> />
			</p>
			<p class="one_fourth">
			  <label for="<?php echo $this->get_field_id('disable_phone_number') ?>">  <?php _e('Disable Phone Number Field',$julia_plugin_name)?>  </label>
			  <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("disable_phone_number"); ?>" name="<?php echo $this->get_field_name("disable_phone_number"); ?>"<?php checked( (bool) $instance["disable_phone_number"], true ); ?> />
			</p>
			<p class="one_fourth">
			  <label for="<?php echo $this->get_field_id('disable_website') ?>">  <?php _e('Disable Website Field',$julia_plugin_name)?>  </label>
			  <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("disable_website"); ?>" name="<?php echo $this->get_field_name("disable_website"); ?>"<?php checked( (bool) $instance["disable_website"], true ); ?> />
			</p>
		  </div>
		  <div class="input-elements-wrapper"> 
		    <p class="one_half">
				<label for="<?php echo $this->get_field_id('login_field_user_name_text') ?>"><?php _e('Login Field User Name Text',$julia_plugin_name) ?></lable>
				<textarea type="text" id="<?php echo $this->get_field_id('login_field_user_name_text') ?>" class="widefat" name="<?php echo $this->get_field_name('login_field_user_name_text') ?>" value = "<?php echo esc_attr($instance['login_field_user_name_text']) ?>" > <?php echo $instance['login_field_user_name_text'] ?>	</textarea>
			</p>
			<p class="one_half_last">
				<label for="<?php echo $this->get_field_id('login_field_password_text') ?>"><?php _e('Login Field Password Text',$julia_plugin_name) ?></lable>
				<textarea type="text" id="<?php echo $this->get_field_id('login_field_password_text') ?>" class="widefat" name="<?php echo $this->get_field_name('login_field_password_text') ?>" value = "<?php echo esc_attr($instance['login_field_password_text']) ?>" > <?php echo $instance['login_field_password_text'] ?>	</textarea>
			</p>
		</div>
		<div class="input-elements-wrapper"> 
			<p class="one_half">
				<label for="<?php echo $this->get_field_id('register_form_first_name_text') ?>"><?php _e('Register Form First Name Text',$julia_plugin_name) ?></lable>
				<textarea type="text" id="<?php echo $this->get_field_id('register_form_first_name_text') ?>" class="widefat" name="<?php echo $this->get_field_name('register_form_first_name_text') ?>" value = "<?php echo esc_attr($instance['register_form_first_name_text']) ?>" > <?php echo $instance['register_form_first_name_text'] ?>	</textarea>
			</p>
			<p class="one_half_last">
				<label for="<?php echo $this->get_field_id('register_form_last_name_text') ?>"><?php _e('Register Form Last Name Text',$julia_plugin_name) ?></lable>
				<textarea type="text" id="<?php echo $this->get_field_id('register_form_last_name_text') ?>" class="widefat" name="<?php echo $this->get_field_name('register_form_last_name_text') ?>" value = "<?php echo esc_attr($instance['register_form_last_name_text']) ?>" > <?php echo $instance['register_form_last_name_text'] ?>	</textarea>
			</p>
		</div>
		<div class="input-elements-wrapper"> 
			<p class="one_half">
				<label for="<?php echo $this->get_field_id('register_form_email_text') ?>"><?php _e('Register Form Email Text',$julia_plugin_name) ?></lable>
				<textarea type="text" id="<?php echo $this->get_field_id('register_form_email_text') ?>" class="widefat" name="<?php echo $this->get_field_name('register_form_email_text') ?>" value = "<?php echo esc_attr($instance['register_form_email_text']) ?>" > <?php echo $instance['register_form_email_text'] ?>	</textarea>
			</p>
			<p class="one_half_last">
				<label for="<?php echo $this->get_field_id('register_form_phone_number') ?>"><?php _e('Register Form Phone Number',$julia_plugin_name) ?></lable>
				<textarea type="text" id="<?php echo $this->get_field_id('register_form_phone_number') ?>" class="widefat" name="<?php echo $this->get_field_name('register_form_phone_number') ?>" value = "<?php echo esc_attr($instance['register_form_phone_number']) ?>" > <?php echo $instance['register_form_phone_number'] ?>	</textarea>
			</p>
		</div>
		<div class="input-elements-wrapper"> 
			<p class="one_half">
				<label for="<?php echo $this->get_field_id('register_form_website_text') ?>"><?php _e('Register Form Website Text',$julia_plugin_name) ?></lable>
				<textarea type="text" id="<?php echo $this->get_field_id('register_form_website_text') ?>" class="widefat" name="<?php echo $this->get_field_name('register_form_website_text') ?>" value = "<?php echo esc_attr($instance['register_form_website_text']) ?>" > <?php echo $instance['register_form_website_text'] ?>	</textarea>
			</p>
			<p class="one_half_last">
				<label for="<?php echo $this->get_field_id('register_form_user_name') ?>"><?php _e('Register Form User Name Text',$julia_plugin_name) ?></lable>
				<textarea type="text" id="<?php echo $this->get_field_id('register_form_user_name') ?>" class="widefat" name="<?php echo $this->get_field_name('register_form_user_name') ?>" value = "<?php echo esc_attr($instance['register_form_user_name']) ?>" > <?php echo $instance['register_form_user_name'] ?>	</textarea>
			</p>
		</div>
		<div class="input-elements-wrapper"> 
			<p class="two_third">
				<label for="<?php echo $this->get_field_id('register_form_conform_text') ?>"><?php _e('Register Form Conform Text',$julia_plugin_name) ?></lable>
				<textarea type="text" id="<?php echo $this->get_field_id('register_form_conform_text') ?>" class="widefat" name="<?php echo $this->get_field_name('register_form_conform_text') ?>" value = "<?php echo esc_attr($instance['register_form_conform_text']) ?>" > <?php echo $instance['register_form_conform_text'] ?>	</textarea>
			</p>
		<p class="one_third-last">
          <label for="<?php echo $this->get_field_id('register_button_text'); ?>"><?php  _e('Register Button Text',$julia_plugin_name); ?></label>
          <input id="<?php echo $this->get_field_id('register_button_text'); ?>" name="<?php echo $this->get_field_name('register_button_text'); ?>" type="text" class="" value="<?php echo esc_attr($instance['register_button_text']) ?>" />
        </p>
		</div>
		  <div class="input-elements-wrapper"> 
		    <p>
				<label for="<?php echo $this->get_field_id('user_success_register_msg') ?>"><?php _e('User Registration Success Message',$julia_plugin_name) ?></lable>
				<textarea type="text" id="<?php echo $this->get_field_id('user_success_register_msg') ?>" class="widefat" name="<?php echo $this->get_field_name('user_success_register_msg') ?>" value = "<?php echo esc_attr($instance['user_success_register_msg']) ?>" > <?php echo $instance['user_success_register_msg'] ?>	</textarea>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id('user_error_register_msg') ?>"><?php _e('User Registration Error Message',$julia_plugin_name) ?></lable>
				<textarea type="text" id="<?php echo $this->get_field_id('user_error_register_msg') ?>" class="widefat" name="<?php echo $this->get_field_name('user_error_register_msg') ?>" value = "<?php echo esc_attr($instance['user_error_register_msg']) ?>" > <?php echo $instance['user_error_register_msg'] ?>	</textarea>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id('user_login_error_msg') ?>"><?php _e('User Login Error Message',$julia_plugin_name) ?></lable>
				<textarea type="text" id="<?php echo $this->get_field_id('user_login_error_msg') ?>" class="widefat" name="<?php echo $this->get_field_name('user_login_error_msg') ?>" value = "<?php echo esc_attr($instance['user_login_error_msg']) ?>" > <?php echo $instance['user_login_error_msg'] ?>	</textarea>
			</p>
		    <p>
				<label for="<?php echo $this->get_field_id('user_forgot_password_msg') ?>"><?php _e('Forgot Password Message',$julia_plugin_name) ?></lable>
				<textarea type="text" id="<?php echo $this->get_field_id('user_forgot_password_msg') ?>" class="widefat" name="<?php echo $this->get_field_name('user_forgot_password_msg') ?>" value = "<?php echo esc_attr($instance['user_forgot_password_msg']) ?>" > <?php echo $instance['user_forgot_password_msg'] ?>	</textarea>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id('user_forgot_password_success_msg') ?>"><?php _e('Forgot Password Success Message',$julia_plugin_name) ?></lable>
				<textarea type="text" id="<?php echo $this->get_field_id('user_forgot_password_success_msg') ?>" class="widefat" name="<?php echo $this->get_field_name('user_forgot_password_success_msg') ?>" value = "<?php echo esc_attr($instance['user_forgot_password_success_msg']) ?>" > <?php echo $instance['user_forgot_password_success_msg'] ?>	</textarea>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id('user_forgot_password_error_msg') ?>"><?php _e('Forgot Password Error Message',$julia_plugin_name) ?></lable>
				<textarea type="text" id="<?php echo $this->get_field_id('user_forgot_password_error_msg') ?>" class="widefat" name="<?php echo $this->get_field_name('user_forgot_password_error_msg') ?>" value = "<?php echo esc_attr($instance['user_forgot_password_error_msg']) ?>" > <?php echo $instance['user_forgot_password_error_msg'] ?>	</textarea>
			</p>
		  </div>
		  <div class="input-elements-wrapper"> 
		    <p>
				<label for="<?php echo $this->get_field_id('user_confirmation_mail_msg') ?>"><?php _e('User Confirmation Mail Message',$julia_plugin_name) ?></lable>
				<textarea type="text" id="<?php echo $this->get_field_id('user_confirmation_mail_msg') ?>" class="widefat" name="<?php echo $this->get_field_name('user_confirmation_mail_msg') ?>" value = "<?php echo esc_attr($instance['user_confirmation_mail_msg']) ?>" > <?php echo $instance['user_confirmation_mail_msg'] ?>	</textarea>
			</p>
			</div>
			<div class="input-elements-wrapper">
			<p>
				<label for="<?php echo $this->get_field_id('User_login_text') ?>"><?php _e('Forgot Password User Email Text',$julia_plugin_name) ?></lable>
				<textarea type="text" id="<?php echo $this->get_field_id('User_login_text') ?>" class="widefat" name="<?php echo $this->get_field_name('User_login_text') ?>" value = "<?php echo esc_attr($instance['User_login_text']) ?>" > <?php echo $instance['User_login_text'] ?>	</textarea>
			</p>
			</div>
			<div class="input-elements-wrapper"> 
			<!-- Captcha Section -->
			<p class="one_fourth">
			  <label for="<?php echo $this->get_field_id('enable_captcha') ?>">  <?php _e('Enable Captcha',$julia_plugin_name)?>  </label>
			  <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("enable_captcha"); ?>" name="<?php echo $this->get_field_name("enable_captcha"); ?>"<?php checked( (bool) $instance["enable_captcha"], true ); ?> />
			</p>
		  </div>
	 <?php
	}
}
  julia_kaya_register_widgets('register-login', __FILE__); 
?>