<?php
class Julia_Iconbox_Widget extends WP_Widget {
  public function __construct() {
     global $julia_plugin_name;
   // widget actual processes
   parent::__construct(
      'icon-box', // Base ID
      __('Julia - Icon Box', $julia_plugin_name), // Name
   array( 'description' => __( 'Use this widget to create icon box with text or Font icons',  $julia_plugin_name)) // Args
 );
 }
public function widget( $args, $instance ) {
  global $julia_plugin_name;
  echo $args['before_widget'];
  $instance = wp_parse_args( $instance, array(
   'title' => __('Icon Box Title',$julia_plugin_name),
    'title_font_weight'=>__('normal',$julia_plugin_name),
    'iconbox_text' => '',
    'iconbox_bg_color' => '#ffffff',
    'description' => __('We strive to leave the tiniest footprint we can. Thats why our goods are designed and manufactured.',$julia_plugin_name),
    'readmore_text' => '',
    'readmore_link_color' => '#333',
    'reamore_link_hover_color' => '#ff3333', 
    'readmore_letter_space' => '2',
    'readmore_font_size' => '11',
    'link' => '#',
    'icon_color' => '#ff3333',
    'icon_bg_color' => '',
    'iconbox_icon_padding' => '',
    'iconbox_icon_border_radius' => '',
    'title_color' => '#333',
    'title_hover_color' => '#ff3333',
    'title_border_color' => '#cccccc',
    'description_color' => '#757575',
    'iconbox_align' => __('center',$julia_plugin_name),
    'awesome_icon_name' => __('fa-cog',$julia_plugin_name),
    'new_window'=>'',
    'iconbox_font_size' => '50',
    'iconbox_link_disable' => '',
    'animation_names' => '',
    'icon_url_id' => '',
    'font_icon_name' => 'cog',
    'select_font_icon_type' => __('awesome_fonts',$julia_plugin_name),
    'icon_url' => '',
    'select_display_icon_type' => __('font_icons',$julia_plugin_name),
    'title_letter_space' => '0',
    'description_letter_space' => '0',
    'title_font_style' => __('normal',$julia_plugin_name),
    'title_font_size' => '18',
    'description_font_weight' => __('normal',$julia_plugin_name),
    'description_font_style' => __('normal',$julia_plugin_name),
    'description_font_size' => '14',
    ) );
    if( $instance['select_font_icon_type'] == 'awesome_fonts' ){
      wp_enqueue_style('fontawesome', constant(strtoupper($julia_plugin_name).'_PLUGIN_URL').'/icons/fontawesome/style.css',true, '', 'all');
    }
    if( $instance['select_font_icon_type'] == 'generaic_icons' ){
      wp_enqueue_style('genericons', constant(strtoupper($julia_plugin_name).'_PLUGIN_URL').'/icons/genericons/style.css',true, '', 'all');
    }
    if( $instance['select_font_icon_type'] == 'elegentline_icons' ){
      wp_enqueue_style('elegantline', constant(strtoupper($julia_plugin_name).'_PLUGIN_URL').'/icons/elegantline/style.css',true, '', 'all');
    }
    if( $instance['select_font_icon_type'] == 'icomoon_icons' ){
      wp_enqueue_style('icomoon', constant(strtoupper($julia_plugin_name).'_PLUGIN_URL').'/icons/icomoon/style.css',true, '', 'all');
    }
  $iconbox_rand = rand(1,500);
  $upload_img_id = wp_get_attachment_image_src($instance['icon_url_id'], "full");
  $icon_left_align = ( $instance['iconbox_align'] == 'none' ) ? 'text-align:center;':'';
  $icon_left_align = ( $instance['iconbox_align'] == 'none' ) ? 'text-align:left;':'';
  $iconbox_data = array(
      'font-size' => $instance['iconbox_font_size'].'px',
      'height' => $instance['iconbox_font_size'].'px',
      'width' => $instance['iconbox_font_size'].'px',
      'color' => $instance['icon_color'].'',
  );
  $iconbox_styles =array();
  foreach ($iconbox_data as $key => $value) {
      $iconbox_styles[] = $key.':'.$value;
  }  
  $target_link = ( $instance['new_window'] == 'on' ) ? '_blank' : '_self';
  //$iconbox_icon_rotate_hover = ( $instance['iconbox_icon_rotate_hover'] == 'on') ? 'on' :'off';
  $iconbox_animation =   ( trim( $instance['animation_names'] ) )  ? 'wow '. $instance['animation_names'] : '';
  $icon_bg_color = ( !empty($instance['icon_bg_color']) ) ?  'background:'.$instance['icon_bg_color'].'; width:'.$instance['iconbox_font_size'].'px; height:'.$instance['iconbox_font_size'].'px; line-height:'.$instance['iconbox_font_size'].'px; text-align:center;' : '';
  $iconbox_icon_padding = ( !empty($instance['iconbox_icon_padding']) ) ?  'padding:'.$instance['iconbox_icon_padding'].'px;' : '';
  $iconbox_icon_border_radius = ( !empty($instance['iconbox_icon_border_radius']) ) ?  'border-radius:'.$instance['iconbox_icon_border_radius'].'px;' : '';
  if( $instance['iconbox_align'] == 'center' ){
    $border_position = 'left:0; right:0; margin:0px auto;';
  }elseif( $instance['iconbox_align'] == 'right' ){
    $border_position = 'right:0;';
  }else{
    $border_position = 'left:0;';
  } 
  $iconbox_bg_color = !empty($instance['iconbox_bg_color']) ? 'background:'.$instance['iconbox_bg_color'].'; padding:45px;' : 'padding:0px;';
  ?>
  <div class="icon_box_wrapper <?php echo $iconbox_animation; ?>" style="<?php echo $iconbox_bg_color; ?>" >
    <div class="iconbox iconbox_<?php echo $instance['iconbox_align']; ?> iconbox-<?php echo $iconbox_rand; ?>" >
      <?php if($instance['iconbox_link_disable'] != 'on' &&  $instance['link']): ?>
        <a href="<?php echo $instance['link'] ?>" target="<?php echo $target_link; ?>">
      <?php endif; ?>
      <?php if( $instance['select_display_icon_type'] == 'image_icons' ){
        echo '<div class="icon_image iconbox_bg align'.$instance['iconbox_align'].'" style="'.implode('; ',$iconbox_styles).'">';
          echo '<div class="iconbox_iconbg_conatiner " style="">';
            echo '<img src="'.$instance['icon_url'].'"  style="'. $icon_left_align .'"/>';
        echo '</div></div>';
      }else{ ?>
        <div class="iconbox_bg align<?php echo $instance['iconbox_align']; ?>" style="<?php echo $icon_bg_color. $icon_left_align; ?> <?php echo $iconbox_icon_padding. $iconbox_icon_border_radius; ?> <?php  echo  implode('; ',$iconbox_styles); ?> ">
          <?php
          echo '<div class="iconbox_iconbg_conatiner">';
            if( $instance['select_display_icon_type'] == 'font_icons' ){
              display_font_icons( $instance['font_icon_name'], $instance['select_font_icon_type'] );                
            }elseif( $instance['select_display_icon_type'] == 'letter_icons' ){
              echo '<div class="" style="">'. $instance['iconbox_text'].'</div>';
            }else{
              display_font_icons( $instance['font_icon_name'], $instance['select_font_icon_type'] );  
            }
          echo '</div>';
        echo '</div>';  
      } ?>      
      <?php if($instance['iconbox_link_disable'] != 'on' && $instance['link']): ?>
        </a>
      <?php endif; ?>
      <div class="description" style="">
        <?php if( trim(!empty( $instance['title']))){ ?>
        <?php if( $instance['link'] ){ ?>
          <a href="<?php echo esc_url($instance['link']); ?>" target="<?php echo $target_link; ?>" >
        <?php } ?>
        <h3 class="title_style2" data-hover-color="<?php echo $instance['title_hover_color']; ?>" style="color:<?php echo $instance['title_color']; ?>; font-weight:<?php echo $instance['title_font_weight']; ?>; line-height:<?php echo ceil(1.2*$instance['title_font_size']); ?>px; text-align:<?php echo $instance['iconbox_align']; ?>; letter-spacing:<?php echo $instance['title_letter_space'] ?>px; font-size:<?php echo $instance['title_font_size'] ?>px; font-style:<?php echo $instance['title_font_style'] ?>;"><?php echo $instance['title']; ?></h3>
        <?php if( $instance['link'] ){ ?> </a> <?php } } ?>
        <p style="color:<?php echo $instance['description_color']; ?>!important; text-align:<?php echo $instance['iconbox_align']; ?>; letter-spacing:<?php echo $instance['description_letter_space'] ?>px; font-size:<?php echo $instance['description_font_size'] ?>px; font-weight:<?php echo $instance['description_font_weight'] ?>; font-style:<?php echo $instance['description_font_style'] ?>"><?php echo $instance['description']; ?></p>
        <?php if( $instance['readmore_text'] ): echo '<a target="'.$target_link.'" data-hover-color = "'.$instance['reamore_link_hover_color'].'" style="color:'.$instance['readmore_link_color'].'; text-align:'.$instance['iconbox_align'].'; font-size:'.$instance['readmore_font_size'].'px; letter-spacing:'.$instance['readmore_letter_space'].'px;" href="'.esc_url($instance['link']).'" class="readmore_button">'.esc_attr($instance['readmore_text']).'</a>'; endif;  ?>
      </div>
    </div>
  </div>
  <?php 
  echo $args['after_widget'];
 }
  public function form( $instance ) {
    global $julia_plugin_name;
    $instance = wp_parse_args( $instance, array(
      'title' => __('Icon Box Title',$julia_plugin_name),
    'title_font_weight'=>__('normal',$julia_plugin_name),
    'iconbox_text' => '',
    'iconbox_bg_color' => '#ffffff',
    'description' => __('We strive to leave the tiniest footprint we can. Thats why our goods are designed and manufactured.',$julia_plugin_name),
    'readmore_text' => '',
    'readmore_link_color' => '#333',
    'reamore_link_hover_color' => '#ff3333', 
    'readmore_letter_space' => '2',
    'readmore_font_size' => '11',
    'link' => '#',
    'icon_color' => '#ff3333',
    'iconbox_icon_padding' => '',
    'iconbox_icon_border_radius' => '',
    'icon_bg_color' => '',
    'title_color' => '#333',
    'title_hover_color' => '#ff3333',
    'title_border_color' => '#cccccc',
    'description_color' => '#757575',
    'iconbox_align' => __('center',$julia_plugin_name),
    'awesome_icon_name' => __('fa-cog',$julia_plugin_name),
    'new_window'=>'',
    'iconbox_font_size' => '50',
    'iconbox_link_disable' => '',
    'animation_names' => '',
    'icon_url_id' => '',
    'font_icon_name' => 'cog',
    'select_font_icon_type' => __('awesome_fonts',$julia_plugin_name),
    'icon_url' => '',
    'select_display_icon_type' => __('font_icons',$julia_plugin_name),
    'title_letter_space' => '0',
    'description_letter_space' => '0',
    'title_font_style' => __('normal',$julia_plugin_name),
    'title_font_size' => '18',
    'description_font_weight' => __('normal',$julia_plugin_name),
    'description_font_style' => __('normal',$julia_plugin_name),
    'description_font_size' => '14',
    ) );
    $font_sizes = array(16,24,32,48,64,80,98,128);   ?> 
  <script type="text/javascript">
      (function($) {
      "use strict";
      $(function() {
      // Color Pickr 
      $('.iconbox_color_pickr').each(function(){
        $(this).wpColorPicker();
      });
  // Selecet icons type
   $("#<?php echo $this->get_field_id('select_display_icon_type') ?>").change(function () {
      $("#<?php echo $this->get_field_id('select_font_icon_type') ?>").parent().hide();
      $("#<?php echo $this->get_field_id('font_icon_name') ?>").hide();
      $("#<?php echo $this->get_field_id('icon_url'); ?>").parent().hide();
      $("#<?php echo $this->get_field_id('iconbox_text'); ?>").parent().hide();
      $(".<?php echo $this->get_field_id('iconbox_font_size'); ?>").find('p').eq(0).show();
      $(".<?php echo $this->get_field_id('iconbox_font_size'); ?>").find('p').eq(1).show();
      $(".<?php echo $this->get_field_id('iconbox_font_size'); ?>").find('p').eq(2).show();
      $(".<?php echo $this->get_field_id('iconbox_font_size'); ?>").find('p').eq(3).show();
      $(".<?php echo $this->get_field_id('iconbox_font_size'); ?>").show();
      var select_font_icons_type = $("#<?php echo $this->get_field_id('select_display_icon_type') ?> option:selected").val(); 
      switch(select_font_icons_type){
        case 'font_icons':
          $("#<?php echo $this->get_field_id('select_font_icon_type') ?>").parent().show();
          $("#<?php echo $this->get_field_id('font_icon_name') ?>").show();
          $(".<?php echo $this->get_field_id('iconbox_font_size'); ?>").find('p').eq(3).removeClass('one_fourth').addClass('one_fourth_last');
          break;
        case 'image_icons':
           $("#<?php echo $this->get_field_id('icon_url'); ?>").parent().show();
           $(".<?php echo $this->get_field_id('iconbox_font_size'); ?>").hide();
           $(".<?php echo $this->get_field_id('iconbox_font_size'); ?>").find('p').eq(0).hide();
           $(".<?php echo $this->get_field_id('iconbox_font_size'); ?>").find('p').eq(1).hide();
           $(".<?php echo $this->get_field_id('iconbox_font_size'); ?>").find('p').eq(2).hide();
           $(".<?php echo $this->get_field_id('iconbox_font_size'); ?>").find('p').eq(3).hide();
           $(".<?php echo $this->get_field_id('iconbox_font_size'); ?> .one_fifth_last").removeClass('one_fourth_last').addClass('one_fourth');
           break;
        case 'letter_icons':
          $("#<?php echo $this->get_field_id('iconbox_text'); ?>").parent().show();
          $(".<?php echo $this->get_field_id('iconbox_font_size'); ?>").find('p').eq(4).removeClass('one_fourth').addClass('one_fourth_last');
          break;    
      }
    }).change(); 
    });
  })(jQuery);
  </script>
  <div class="input-elements-wrapper"> 
    <p>
      <label for="<?php echo $this->get_field_id('select_display_icon_type') ?>">  <?php _e('Select Icon Type',$julia_plugin_name) ?> </label>
        <select id="<?php echo $this->get_field_id('select_display_icon_type') ?>" class="iconbox_widget_select" name="<?php echo $this->get_field_name
        ('select_display_icon_type') ?>">
        <option value="font_icons" <?php selected('font_icons', $instance['select_display_icon_type']) ?>> <?php esc_html_e('Font Type Icons', $julia_plugin_name) ?> </option>
        <option value="image_icons" <?php selected('image_icons', $instance['select_display_icon_type']) ?>> <?php esc_html_e('Image Icon', $julia_plugin_name) ?> </option>
        <option value="letter_icons" <?php selected('letter_icons', $instance['select_display_icon_type']) ?>> <?php esc_html_e('Letter Icons', $julia_plugin_name) ?> </option>
      </select>
    </p>
    <?php select_font_icons($this->get_field_id('select_font_icon_type'), $this->get_field_name('select_font_icon_type'), $instance['select_font_icon_type']); ?>
    <?php kaya_font_icons($this->get_field_id('font_icon_name'), $this->get_field_name('font_icon_name'), $instance['font_icon_name']); ?>
    <p>
      <?php $i = rand(1,100); ?>
      <img class="custom_media_image_<?php echo $i; ?>" src="<?php if(!empty($instance['icon_url'])){echo $instance['icon_url'];} ?>" style="margin:0;padding:0;max-width:100px;float:left;display:inline-block" />
      <input type="text" class="widefat custom_media_url_<?php echo $i; ?>" name="<?php echo $this->get_field_name('icon_url'); ?>" id="<?php echo $this->get_field_id('icon_url'); ?>" value="<?php echo $instance['icon_url']; ?>">
      <input type="hidden" class="small-text custom_media_url_id_<?php echo $i; ?>" name="<?php echo $this->get_field_name('icon_url_id'); ?>" id="<?php echo $this->get_field_id('icon_url_id'); ?>" value="<?php echo $instance['icon_url_id']; ?>">
      <input type="button" value="<?php _e( 'Upload Image', $julia_plugin_name); ?>" class="button custom_media_upload_<?php echo $i; ?>" id="custom_media_upload_<?php echo $i; ?>"/>
      <script type="text/javascript">
      jQuery(document).ready( function(){
        jQuery('.custom_media_upload_<?php echo $i; ?>').click(function(e) {
          e.preventDefault();
          var custom_uploader = wp.media({
            title: 'Upload Icon',
            button: {
            text: 'Upload Icon'
          },
           multiple: false  // Set this to true to allow multiple files to be selected
          })
          .on('select', function() {
            var attachment = custom_uploader.state().get('selection').first().toJSON();
            jQuery('.custom_media_image_<?php echo $i; ?>').attr('src', attachment.url);
            jQuery('.custom_media_url_id_<?php echo $i; ?>').val(attachment.id);
            jQuery('.custom_media_url_<?php echo $i; ?>').val(attachment.url);
          })
          .open();
          });
      });
      </script>
    </p>
    <p class="clearfix">
      <label for="<?php echo $this->get_field_id('iconbox_text') ?>"> <?php _e('Icon Text',$julia_plugin_name) ?> </label>
      <input type="text" class="small-text" id="<?php echo $this->get_field_id('iconbox_text') ?>" name="<?php echo $this->get_field_name('iconbox_text') ?>" value="<?php echo esc_attr($instance['iconbox_text']) ?>" />
      <small><?php _e('Ex: A',$julia_plugin_name); ?></small>
    </p>
  </div>
  <div class="input-elements-wrapper <?php echo $this->get_field_id('iconbox_font_size') ?>"> 
    <p class="one_fourth">
      <label for="<?php echo $this->get_field_id('iconbox_bg_color') ?>">  <?php _e('Iconbox Container BG Color',$julia_plugin_name) ?>  </label>
      <input type="text" class="widefat iconbox_color_pickr" id="<?php echo $this->get_field_id('iconbox_bg_color') ?>" name="<?php echo $this->get_field_name('iconbox_bg_color') ?>" value="<?php echo esc_attr($instance['iconbox_bg_color']) ?>" />
    </p>  
    <p class="one_fourth">
      <label for="<?php echo $this->get_field_id('iconbox_font_size') ?>">  <?php _e('Icon Size',$julia_plugin_name)?>  </label>
      <input type="text" class="small-text" id="<?php echo $this->get_field_id('iconbox_font_size') ?>" name="<?php echo $this->get_field_name('iconbox_font_size') ?>" value="<?php echo esc_attr($instance['iconbox_font_size']) ?>" />
      <small><?php _e('px',$julia_plugin_name); ?></small>
    </p>
    <p class="one_fourth">
      <label for="<?php echo $this->get_field_id('icon_bg_color') ?>">  <?php _e('Icon Background Color',$julia_plugin_name) ?>  </label>
      <input type="text" class="widefat iconbox_color_pickr" id="<?php echo $this->get_field_id('icon_bg_color') ?>" name="<?php echo $this->get_field_name('icon_bg_color') ?>" value="<?php echo esc_attr($instance['icon_bg_color']) ?>" />
    </p>
    <p class="one_fourth_last">
      <label for="<?php echo $this->get_field_id('icon_color') ?>">  <?php _e('Icon Color',$julia_plugin_name) ?>  </label>
      <input type="text" class="widefat iconbox_color_pickr" id="<?php echo $this->get_field_id('icon_color') ?>" name="<?php echo $this->get_field_name('icon_color') ?>" value="<?php echo esc_attr($instance['icon_color']) ?>" />
    </p>
    <p class="one_fourth">
      <label for="<?php echo $this->get_field_id('iconbox_icon_padding') ?>">  <?php _e('Icon Padding',$julia_plugin_name)?>  </label>
      <input type="text" class="small-text" id="<?php echo $this->get_field_id('iconbox_icon_padding') ?>" name="<?php echo $this->get_field_name('iconbox_icon_padding') ?>" value="<?php echo esc_attr($instance['iconbox_icon_padding']) ?>" />
      <small><?php _e('px',$julia_plugin_name); ?></small>
    </p>
     <p class="one_fourth">
      <label for="<?php echo $this->get_field_id('iconbox_icon_border_radius') ?>">  <?php _e('Icon Border Radius',$julia_plugin_name)?>  </label>
      <input type="text" class="small-text" id="<?php echo $this->get_field_id('iconbox_icon_border_radius') ?>" name="<?php echo $this->get_field_name('iconbox_icon_border_radius') ?>" value="<?php echo esc_attr($instance['iconbox_icon_border_radius']) ?>" />
      <small><?php _e('px',$julia_plugin_name); ?></small>
    </p>
  </div>
  <div class="input-elements-wrapper">  
    <p class="one_fourth img_radio_select icon_alignment">
      <label for="<?php echo $this->get_field_id('iconbox_align') ?>">  <?php _e('Icon Position',$julia_plugin_name)  ?>  </label>
      <label>
        <input type="radio" id="<?php echo $this->get_field_id( 'iconbox_align' ); ?>" name="<?php echo $this->get_field_name( 'iconbox_align' ); ?>" value="center" <?php checked( $instance['iconbox_align'], 'center' ); ?>> 
        <img alt="Align Center" title="Align Center" src="<?php echo constant(strtoupper($julia_plugin_name).'_PLUGIN_URL').'images/align_center.png' ?>">
      </label>
      <label>
        <input type="radio" id="<?php echo $this->get_field_id( 'iconbox_align' ); ?>" name="<?php echo $this->get_field_name( 'iconbox_align' ); ?>" value="left" <?php checked( $instance['iconbox_align'], 'left' ); ?>> <img alt="Align Left" title="Align Left" src="<?php echo constant(strtoupper($julia_plugin_name).'_PLUGIN_URL').'images/align_left.png' ?>">
      </label>
      <label> 
        <input type="radio" id="<?php echo $this->get_field_id( 'iconbox_align' ); ?>" name="<?php echo $this->get_field_name( 'iconbox_align' ); ?>" value="right" <?php checked( $instance['iconbox_align'], 'right' ); ?>>  <img alt="Align Right" title="Align Right"  src="<?php echo constant(strtoupper($julia_plugin_name).'_PLUGIN_URL').'images/align_right.png' ?>">
      </label>
      <label> 
        <input type="radio" id="<?php echo $this->get_field_id( 'iconbox_align' ); ?>" name="<?php echo $this->get_field_name( 'iconbox_align' ); ?>" value="none" <?php checked( $instance['iconbox_align'], 'none' ); ?>>  <img alt="Align Right" title="Align None"  src="<?php echo constant(strtoupper($julia_plugin_name).'_PLUGIN_URL').'images/align_none.png' ?>">
      </label>
    </p>
    <p class="one_fourth">
      <label for="<?php echo $this->get_field_id('iconbox_link_disable') ?>">  <?php _e('Icon Link Disable',$julia_plugin_name) ?>  </label>
      <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("iconbox_link_disable"); ?>" name="<?php echo $this->get_field_name("iconbox_link_disable"); ?>"<?php checked( (bool) $instance["iconbox_link_disable"], true ); ?> />
    </p>
  </div>
  <div class="input-elements-wrapper fields_bottom_border">
    <p class="one_fourth">
      <label for="<?php echo $this->get_field_id('title') ?>">  <?php _e('Title',$julia_plugin_name) ?>  </label>
      <input type="text" class="widefat" id="<?php echo $this->get_field_id('title') ?>" name="<?php echo $this->get_field_name('title') ?>" value="<?php echo esc_attr($instance['title']) ?>" />
    </p>
    <p class="one_fourth">
      <label for="<?php echo $this->get_field_id('title_font_size') ?>">  <?php _e('Title Font Size',$julia_plugin_name) ?>  </label>
      <input type="text" class="small-text" id="<?php echo $this->get_field_id('title_font_size') ?>" name="<?php echo $this->get_field_name('title_font_size') ?>" value="<?php echo esc_attr($instance['title_font_size']) ?>" />
      <small>  <?php _e('px',$julia_plugin_name) ?>  </small> 
    </p>
    <p class="one_fourth">
      <label for="<?php echo $this->get_field_id('title_letter_space') ?>">  <?php _e('Title Letter Space',$julia_plugin_name) ?>  </label>
      <input type="text" class="small-text" id="<?php echo $this->get_field_id('title_letter_space') ?>" name="<?php echo $this->get_field_name('title_letter_space') ?>" value="<?php echo esc_attr($instance['title_letter_space']) ?>" />
      <small>  <?php _e('px',$julia_plugin_name) ?>  </small> 
    </p>
    <p class="one_fourth_last">
      <label for="<?php echo $this->get_field_id('title_font_style') ?>"> <?php _e('Title Font Style',$julia_plugin_name) ?></label>
      <select id="<?php echo $this->get_field_id('title_font_style') ?>" name="<?php echo $this->get_field_name('title_font_style') ?>">
        <option value="normal" <?php selected('normal', $instance['title_font_style']) ?>> <?php esc_html_e('Normal', $julia_plugin_name) ?>   </option>
        <option value="italic" <?php selected('italic', $instance['title_font_style']) ?>>  <?php esc_html_e('Italic',$julia_plugin_name) ?></option>
      </select>
    </p>
  </div>
  <div class="input-elements-wrapper">
    <p class="one_fourth">
      <label for="<?php echo $this->get_field_id('title_font_weight') ?>"> <?php _e('Title Font Weight',$julia_plugin_name) ?></label>
      <select id="<?php echo $this->get_field_id('title_font_weight') ?>" name="<?php echo $this->get_field_name('title_font_weight') ?>">
        <option value="normal" <?php selected('normal', $instance['title_font_weight']) ?>> <?php esc_html_e('Normal', $julia_plugin_name) ?>   </option>
        <option value="bold" <?php selected('bold', $instance['title_font_weight']) ?>>  <?php esc_html_e('Bold',$julia_plugin_name) ?></option>
      </select>
    </p>
    <p class="one_fourth">
      <label for="<?php echo $this->get_field_id('title_color') ?>">  <?php _e('Title Color',$julia_plugin_name) ?>  </label>
      <input type="text" class="widefat iconbox_color_pickr" id="<?php echo $this->get_field_id('title_color') ?>" name="<?php echo $this->get_field_name('title_color') ?>" value="<?php echo esc_attr($instance['title_color']) ?>" />
    </p>
    <p class="one_fourth">
      <label for="<?php echo $this->get_field_id('title_hover_color') ?>">  <?php _e('Title Hover Color',$julia_plugin_name) ?>  </label>
      <input type="text" class="widefat iconbox_color_pickr" id="<?php echo $this->get_field_id('title_hover_color') ?>" name="<?php echo $this->get_field_name('title_hover_color') ?>" value="<?php echo esc_attr($instance['title_hover_color']) ?>" />
    </p>
    <p class="one_fourth">
      <label for="<?php echo $this->get_field_id('title_border_color') ?>">  <?php _e('Title Bottom Border Color',$julia_plugin_name) ?>  </label>
      <input type="text" class="widefat iconbox_color_pickr" id="<?php echo $this->get_field_id('title_border_color') ?>" name="<?php echo $this->get_field_name('title_border_color') ?>" value="<?php echo esc_attr($instance['title_border_color']) ?>" />
    </p>
  </div>
  <div class="input-elements-wrapper">  
    <p class="two_fourth">
      <label for="<?php echo $this->get_field_id('description') ?>">  <?php  _e('Description' ,$julia_plugin_name); ?>  </label>
      <textarea type="text" class="widefat" name="<?php echo $this->get_field_name('description') ?>" id="<?php echo $this->get_field_id('description') ?>" ><?php echo esc_attr($instance['description']) ?></textarea>
    </p>
    <p class="one_fourth">
      <label for="<?php echo $this->get_field_id('description_font_size') ?>">  <?php _e('Description Font Size',$julia_plugin_name) ?>  </label>
      <input type="text" class="small-text" id="<?php echo $this->get_field_id('description_font_size') ?>" name="<?php echo $this->get_field_name('description_font_size') ?>" value="<?php echo esc_attr($instance['description_font_size']) ?>" />
      <small>  <?php _e('px',$julia_plugin_name) ?>  </small> 
    </p>
    <p class="one_fourth_last">
      <label for="<?php echo $this->get_field_id('description_letter_space') ?>">  <?php _e('Description Letter Space',$julia_plugin_name) ?>  </label>
      <input type="text" class="small-text" id="<?php echo $this->get_field_id('description_letter_space') ?>" name="<?php echo $this->get_field_name('description_letter_space') ?>" value="<?php echo esc_attr($instance['description_letter_space']) ?>" />
      <small>  <?php _e('px',$julia_plugin_name) ?>  </small> 
    </p>
  </div>
  <div class="input-elements-wrapper"> 
    <p class="one_fourth">
      <label for="<?php echo $this->get_field_id('description_font_style') ?>"> <?php _e('Description Font Style',$julia_plugin_name) ?></label>
      <select id="<?php echo $this->get_field_id('description_font_style') ?>" name="<?php echo $this->get_field_name('description_font_style') ?>">
        <option value="normal" <?php selected('normal', $instance['description_font_style']) ?>> <?php esc_html_e('Normal', $julia_plugin_name) ?>   </option>
        <option value="italic" <?php selected('italic', $instance['description_font_style']) ?>>  <?php esc_html_e('Italic',$julia_plugin_name) ?></option>
      </select>
    </p>
    <p class="one_fourth">
      <label for="<?php echo $this->get_field_id('description_font_weight') ?>"> <?php _e('Description Font Weight',$julia_plugin_name) ?></label>
        <select id="<?php echo $this->get_field_id('description_font_weight') ?>" name="<?php echo $this->get_field_name('description_font_weight') ?>">
          <option value="normal" <?php selected('normal', $instance['description_font_weight']) ?>> <?php esc_html_e('Normal', $julia_plugin_name) ?>   </option>
          <option value="bold" <?php selected('bold', $instance['description_font_weight']) ?>>  <?php esc_html_e('Bold',$julia_plugin_name) ?></option>
        </select>
    </p>
    <p class="one_fourth">
      <label for="<?php echo $this->get_field_id('description_color') ?>">  <?php _e('Description Color',$julia_plugin_name) ?>  </label>
      <input type="text"  class="widefat iconbox_color_pickr" id="<?php echo $this->get_field_id('description_color') ?>" name="<?php echo $this->get_field_name('description_color') ?>" value="<?php echo esc_attr($instance['description_color']) ?>" />
    </p>
  </div>
  <div class="input-elements-wrapper fields_bottom_border">  
    <p class="one_fourth">
      <label for="<?php echo $this->get_field_id('readmore_text') ?>">  <?php _e('Readmore Button Text',$julia_plugin_name) ?>  </label>
      <input type="text" class="widefat" id="<?php echo $this->get_field_id('readmore_text') ?>" name="<?php echo $this->get_field_name('readmore_text') ?>" value="<?php echo esc_attr($instance['readmore_text']) ?>" />
    </p>
    <p class="one_fourth">
      <label for="<?php echo $this->get_field_id('readmore_link_color') ?>">  <?php _e('Readmore Button Link Color',$julia_plugin_name) ?>  </label>
      <input type="text" class="widefat iconbox_color_pickr" id="<?php echo $this->get_field_id('readmore_link_color') ?>" name="<?php echo $this->get_field_name('readmore_link_color') ?>" value="<?php echo esc_attr($instance['readmore_link_color']) ?>" />
    </p>
    <p class="one_fourth">
      <label for="<?php echo $this->get_field_id('reamore_link_hover_color') ?>">  <?php _e('Readmore Button Link Hover Color',$julia_plugin_name) ?>  </label>
      <input type="text" class="widefat iconbox_color_pickr" id="<?php echo $this->get_field_id('reamore_link_hover_color') ?>" name="<?php echo $this->get_field_name('reamore_link_hover_color') ?>" value="<?php echo esc_attr($instance['reamore_link_hover_color']) ?>" />
    </p>
    <p class="one_fourth_last">
      <label for="<?php echo $this->get_field_id('readmore_font_size') ?>">  <?php _e('Readmore Button Font Size',$julia_plugin_name) ?>  </label>
      <input type="text" class="small-text" id="<?php echo $this->get_field_id('readmore_font_size') ?>" name="<?php echo $this->get_field_name('readmore_font_size') ?>" value="<?php echo esc_attr($instance['readmore_font_size']) ?>" />
      <small>  <?php _e('px',$julia_plugin_name) ?>  </small> 
    </p>
    <p class="one_fourth" style="clear:both;">
      <label for="<?php echo $this->get_field_id('readmore_letter_space') ?>">  <?php _e('Readmore Button Letter Space',$julia_plugin_name) ?>  </label>
      <input type="text" class="small-text " id="<?php echo $this->get_field_id('readmore_letter_space') ?>" name="<?php echo $this->get_field_name('readmore_letter_space') ?>" value="<?php echo esc_attr($instance['readmore_letter_space']) ?>" />
      <small>  <?php _e('px',$julia_plugin_name) ?>  </small> 
    </p>
    <p class="one_fourth">
      <label for="<?php echo $this->get_field_id('link') ?>">  <?php _e('Link',$julia_plugin_name) ?>  </label>
      <input type="text" class="widefat" id="<?php echo $this->get_field_id('link') ?>" name="<?php echo $this->get_field_name('link') ?>" value="<?php echo esc_attr($instance['link']) ?>" />
      <small>  <?php _e('Ex:http://www.google.com',$julia_plugin_name) ?>  </small> </p>
    </p>
    <p class="one_fourth">
      <label for="<?php echo $this->get_field_id('new_window') ?>">  <?php _e('Open in new window',$julia_plugin_name) ?>  </label>
      <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("new_window"); ?>" name="<?php echo $this->get_field_name("new_window"); ?>"<?php checked( (bool) $instance["new_window"], true ); ?> />
    </p>
  </div>
  <div class="input-elements-wrapper"> 
    <p class="">
      <label for="<?php echo $this->get_field_id('animation_names') ?>">  <?php _e('Select Animation Effect',$julia_plugin_name) ?>  </label>
      <?php animation_effects($this->get_field_name('animation_names'), $instance['animation_names'] ); ?>
    </p>
  </div>
  <?php
  }
}
julia_kaya_register_widgets('iconbox', __FILE__);
?>