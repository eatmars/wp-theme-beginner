<?php 
class Julia_Portfolio_Widget extends WP_Widget{
	public function __construct(){
		global $julia_plugin_name;
		parent::__construct('kaya-portfolio',
			__('Julia - Portfolio (Deprecated)',$julia_plugin_name),
			array(
				'description' =>__('Use this widget to add recent news',$julia_plugin_name))
			);	
	}
	function widget( $args, $instance){
		 global $post, $julia_plugin_name, $wp_query, $paged;
		$instance = wp_parse_args($instance, array(
			'portfolio_widget_category' => '',
			'filter_tab_bg_color' => '#e5e5e5',
			'filter_tab_text_color' => '#333333',
			'filter_tab_active_bg_color' => '#ff3333',
			'filter_tab_active_text_color' => '#ffffff',
			'filter_tab_align' => 'center',
			'filter_tab_padding_top_bottom' => '3',
			'filter_tab_padding_left_right' => '15',
			'filter_tab_border_radius' => '2',
			'filter_tab_border_color' => '',
			'filter_tab_border_active_color' => '#ffffff',
			'kaya_portfolio_filter' => 'false',
			'filter_tabs_margin_bottom' => '60',
			'select_pf_columns' => '4',
			'pf_img_width' => '480',
			'pf_img_height' => '550',
			'pf_display_orderby' => '',
			'pf_display_order' => 'desc',
			'pf_title_font_size' => '18',
			'pf_title_letter_space' => '0',
			'pf_title_color' => '#333333',
			'pf_content_bg_color' => '#ffffff',
			'pf_button_name' => 'Read More',
			'pf_button_color' => '#ffffff',
			'pf_button_bg_color' => '#ff3333',
			'pf_button_border_color' => '#ff3333',
			'pf_button_hover_bg' => '#c19f51',
			'pf_button_hover_text' => '#ffffff',
			'pf_button_hover_border_color' => '#ffffff',
			'pf_button_font_size' => '15',
			'pf_button_letter_space' => '0',
			'portfolio_limit'=>'12',
			'disable_pagination'=>'',
			'pf_description_color' => '#686868',
			'pf_description_letter_space' => '0',
			'pf_description_font_size' => '15',
			'pf_img_vertical_title_color' => '#333333',
			'pf_img_vertical_title_size' => '18',
			'vertical_title_font_style' => 'italic',
			'vertical_title_font_weight' => 'normal',
			'pf_title_font_weight' => 'normal',
			'pf_title_font_style' => 'normal',
			'pf_description_font_weight' => 'normal',
			'pf_description_font_style' => 'normal',
			'pf_img_vertical_title_letter_sapce' => '0',
			'pf_img_border_color' => '#ffffff',
			'animation_names' => '',
			'pf_loadmore_text' => 'LOAD MORE',
			'pf_loadmore_bg_color' => '#ff3333',
			'pf_loadmore_text_color' => '#fff',
			'pf_loadmore_hover_bg_color' => '#ffffff',
			'pf_loadmore_hover_text_color' => '#ff3333',
			'pf_gray_scale_mode' => '',
			'change_filter_tab_all_text' => esc_html__('ALL', $julia_plugin_name),
			'pf_enable_masonry_gallery' => '',
			'disable_add_remove_button'  => '',
		));
		echo $args['before_widget']; 
		$rand=rand(1,500); ?>
			<style type="text/css">
	      <?php if( $instance['kaya_portfolio_filter'] == 'true'){ ?>
	        .filter-<?php echo $rand; ?> a:hover, .filter-<?php echo $rand; ?> .active{
	          background-color: <?php echo $instance['filter_tab_active_bg_color']; ?>!important;
	          color: <?php echo $instance['filter_tab_active_text_color']; ?>!important;
	          border-color:<?php echo $instance['filter_tab_border_active_color']; ?>!important;
	        }
	      <?php } ?>
	      .portfolio_content_wrapper_<?php echo $rand; ?> .mata_data_info_wrapper{
	      		background-color: <?php echo $instance['pf_content_bg_color']; ?>!important;
	         	color: <?php echo $instance['pf_description_color']; ?>!important;	
	      }
	      .portfolio_content_wrapper_<?php echo $rand; ?> .mata_data_info_wrapper span{
	         	color: <?php echo $instance['pf_description_color']; ?>!important;	
	      }
    </style>
		<?php
		switch ($instance['filter_tab_align']) {
			case 'center':
				$align_style = 'display:table; margin:0px auto!important;';
				break;
			case 'left':
				$align_style = 'display:block; float:left;';
				break;
			case 'right':
				$align_style = 'display:block; float:right;';
				break;	
			default:
				$align_style = 'display:table; margin:0px auto!important;';
				break;
		}
		$pf_animation = ( trim( $instance['animation_names'] ) )  ? 'wow '. $instance['animation_names'] : ''; 
		$default_img_url = constant(strtoupper($julia_plugin_name).'_PLUGIN_URL').'images/default_images/portfolio.jpg'; 
		$pf_gray_scale_mode = ( $instance['pf_gray_scale_mode'] == 'on' ) ? 'gray_scale_img' : '';
		echo '<div class="portfolio_content_wrapper '.$pf_animation.' portfolio_content_wrapper_'.$rand.'">';
			if ($instance['kaya_portfolio_filter'] == 'true'){ // open filter settings
				$change_all_text = $instance['change_filter_tab_all_text'] ? $instance['change_filter_tab_all_text'] :  esc_html__('ALL', $julia_plugin_name);
			      $filter_border_color = $instance['filter_tab_border_color'] ? 'border:1px solid '.$instance['filter_tab_border_color'].';' : '';
			        echo '<div class="filter_portfolio">';
			          echo '<div class="filter filter-'.$rand.'" id="filter" data-active="'.$instance['filter_tab_active_bg_color'].'" data-text="'.$instance['filter_tab_active_text_color'].'" >';
			            echo '<ul style="'.$align_style.'">';
			              echo '<li class="all" ><a class="active" href="#" style="padding:'.$instance['filter_tab_padding_top_bottom'].'px '.$instance['filter_tab_padding_left_right'].'px; color:'.$instance['filter_tab_text_color'].'; background:'.$instance['filter_tab_bg_color'].'; border-radius:'.$instance['filter_tab_border_radius'].'px; '.$filter_border_color.'" data-filter="*">'.$change_all_text.'</a>';
			              echo '</li>';
			              $category = trim( $instance['portfolio_widget_category']);
			                if( $category ){
			                  $pf_categories = @explode(',', $category);
			                  for($i=0;$i<count($pf_categories);$i++){
			                    $terms[] = get_term_by('id', $pf_categories[$i], 'portfolio_category');
			                  } } else {
			                    $terms = get_terms('portfolio_category');
			                }
			              foreach($terms as $term) {
			                echo '<li  class="cat-'.$term->term_id .'" >';
			                echo '<a href="" style="padding:'.$instance['filter_tab_padding_top_bottom'].'px '.$instance['filter_tab_padding_left_right'].'px; color:'.$instance['filter_tab_text_color'].'; background:'.$instance['filter_tab_bg_color'].'; border-radius:'.$instance['filter_tab_border_radius'].'px; '.$filter_border_color.'" data-filter=".cat-' . $term->term_id . '">' . $term->name . ' </a>';
				                echo '</li>';
			              }
			            echo '</ul>';
			          echo '</div>';
			        echo '</div>';
			       } // end filter 	
			       if(function_exists('kta_classes')){
			       		$classes = kta_classes('portfolio_columns'.$instance['select_pf_columns'].' portfolio_img_grid_columns kta-talent-content-wrapper');
			       }else{
			       		$classes = 'class="portfolio_columns'.$instance['select_pf_columns'].' portfolio_img_grid_columns"';
			       }
	       			echo '<div '.$classes.'>';
				echo '<ul class="isotope-container grid pf_extra_width clearfix">';
				global $wp_query, $post;
					$border = $instance['pf_button_border_color'] ? 'border:1px solid '.$instance['pf_button_border_color'].';' : '';
					$array_val = ( !empty( $instance['portfolio_widget_category'] )) ? explode(',',  $instance['portfolio_widget_category']) : '';
					 if ( get_query_var('paged') ) { $paged = get_query_var('paged'); }
				    elseif ( get_query_var('page') ) { $paged = get_query_var('page'); }
				    else { $paged = 1; }
					if( $array_val ) {
						$args = array( 'paged' => $paged, 'post_type' => 'portfolio', 'orderby' => $instance['pf_display_orderby'], 'posts_per_page' =>$instance['portfolio_limit'],'order' => $instance['pf_display_order'],  'tax_query' => array('relation' => 'AND', array( 'taxonomy' => 'portfolio_category',   'field' => 'id', 'terms' => $array_val  ), ));
					}else{
						$args = array('paged' => $paged, 'post_type' => 'portfolio',  'taxonomy' => 'portfolio_category','term' => $instance['portfolio_widget_category'], 'orderby' => $instance['pf_display_orderby'], 'posts_per_page' => $instance['portfolio_limit'],'order' => $instance['pf_display_order']);
					}
					query_posts($args);
					if( have_posts() ) : while( have_posts() ) : the_post();
						$id = get_the_ID();
						$selected = '';
						if(isset($_SESSION['shortlist'])) {
							if ( in_array($id, $_SESSION['shortlist']) ) {
								$selected = 'item_selected';
							}
						}
						$img_url = wp_get_attachment_url( get_post_thumbnail_id() );
						$pf_cats = get_the_terms(get_the_ID(), 'portfolio_category');
						$terms_name = array();
						 $terms_id = array();
						if( is_array($pf_cats) ){
							foreach ($pf_cats as $pf_cat) {
								$terms_name[] = $pf_cat->name;
								$terms_id[] = 'cat-'.$pf_cat->term_id;
							}
						}else{
							$terms_name[] = 'uncategory';
						}
						echo '<li class="item '.$selected.' isotope-item all '.implode(' ', $terms_id).'" id="'.get_the_ID().'">';
							do_action('kta_shortlist_icons'); // Shortlist icons ( +/- )			   	
							echo '<div class="pf_image_wrapper kta-image-details-wrapper '.$pf_gray_scale_mode.'" style="border-color:'.$instance['pf_img_border_color'].';">';
								if( !empty($img_url) ){
									//echo '<span class="pf_title_wrapper" style="background-color:'.$instance['pf_img_border_color'].'; color:'.$instance['pf_img_vertical_title_color'].'; font-size:'.$instance['pf_img_vertical_title_size'].'px; letter-spacing:'.$instance['pf_img_vertical_title_letter_sapce'].'px; font-weight:'.$instance['vertical_title_font_weight'].'; font-style:'.$instance['vertical_title_font_style'].';">'.get_the_title().'</span>';
									echo '<a href="'.get_the_permalink().'">';
									 if( $instance['pf_enable_masonry_gallery'] == 'on'){
											echo '<a href="'.get_the_permalink().'"><img  src="'.kaya_image_resize( $img_url, $instance['pf_img_width'],$instance['pf_img_height'],'t' ).'"  srcset="'.wp_get_attachment_image_srcset( get_post_thumbnail_id(), 'large' ).'" sizes="(max-width: 500px) 100vw, 500px"   alt="'.get_the_title().'" width="'.$instance['pf_img_width'].'" height="'.$instance['pf_img_height'].'" ></a>';
										}else{
											echo '<img  src="'.kaya_image_resize( $img_url, $instance['pf_img_width'],$instance['pf_img_height'],'t' ).'"  alt="'.get_the_title().'" width="'.$instance['pf_img_width'].'" height="'.$instance['pf_img_height'].'" >';
										}
									echo '</a>';


								}else{
									if (is_multisite()){
										$image_url = $default_img_url;
									}else{	                
										$image_url = kaya_image_resize( $default_img_url, $instance['pf_img_width'],$instance['pf_img_height'],'t' );
									}
									
									echo '<a class="lazyload" href="'.get_the_permalink().'"><img src="'.$image_url.'" class="" alt="'.get_the_title().'" width="'.$instance['pf_img_width'].'" height="'.$instance['pf_img_height'].'" ></a>';
								}
								// Talent Information
								if( function_exists('kta_talent_details') ){ 
									kta_talent_details(get_the_ID(), $set_card=FALSE, $model_details=TRUE);
								}
								echo '<h4 style="background-color:'.$instance['pf_img_border_color'].'; color:'.$instance['pf_img_vertical_title_color'].'; font-size:'.$instance['pf_img_vertical_title_size'].'px; letter-spacing:'.$instance['pf_img_vertical_title_letter_sapce'].'px; font-weight:'.$instance['vertical_title_font_weight'].'; font-style:'.$instance['vertical_title_font_style'].';">'.get_the_title().'</h4>';
							echo '</div>';
								
							echo '</li>';
					endwhile;
					endif;
				echo '</ul>';
				if(function_exists('julia_kaya_pagination')){
			    	echo julia_kaya_pagination();
			  	}
			     wp_reset_query();
				echo '</div>';
			echo '</div>';
		echo '</div>'; //after widget;	
	}
	function form($instance){
		global $julia_plugin_name;
		 $portfolio_terms=  get_terms('portfolio_category','');
	    if( $portfolio_terms ){
	      foreach ($portfolio_terms as $portfolio_term) { 
	        $pf_cat_ids[] = $portfolio_term->term_id;
	         $pf_cats_name[] = $portfolio_term->name.' - '.$portfolio_term->term_id;
	      }
	    }else{ $pf_cats_name[] = ''; $pf_cat_ids[] =''; }
		$instance = wp_parse_args($instance, array(
			'portfolio_widget_category' => '',
			'filter_tab_bg_color' => '#e5e5e5',
			'filter_tab_text_color' => '#333333',
			'filter_tab_active_bg_color' => '#ff3333',
			'filter_tab_active_text_color' => '#ffffff',
			'filter_tab_align' => 'center',
			'filter_tab_padding_top_bottom' => '3',
			'filter_tab_padding_left_right' => '15',
			'filter_tab_border_radius' => '2',
			'filter_tab_border_color' => '',
			'filter_tab_border_active_color' => '#ffffff',
			'kaya_portfolio_filter' => 'false',
			'filter_tabs_margin_bottom' => '60',
			'select_pf_columns' => '4',
			'pf_img_width' => '480',
			'pf_img_height' => '550',
			'pf_display_orderby' => '',
			'pf_display_order' => 'desc',
			'pf_title_font_size' => '18',
			'pf_title_letter_space' => '0',
			'pf_title_color' => '#333333',
			'pf_content_bg_color' => '#ffffff',
			'pf_button_name' => 'Read More',
			'pf_button_color' => '#ffffff',
			'pf_button_bg_color' => '#ff3333',
			'pf_button_border_color' => '#ff3333',
			'pf_button_hover_bg' => '#c19f51',
			'pf_button_hover_text' => '#ffffff',
			'pf_button_hover_border_color' => '#ffffff',
			'pf_button_font_size' => '15',
			'pf_button_letter_space' => '0',
			'portfolio_limit'=>'12',
			'disable_pagination'=>'',
			'pf_description_color' => '#686868',
			'pf_description_letter_space' => '0',
			'pf_description_font_size' => '15',
			'pf_img_vertical_title_color' => '#333333',
			'pf_img_vertical_title_size' => '18',
			'vertical_title_font_style' => 'italic',
			'vertical_title_font_weight' => 'normal',
			'pf_title_font_weight' => 'normal',
			'pf_title_font_style' => 'normal',
			'pf_description_font_weight' => 'normal',
			'pf_description_font_style' => 'normal',
			'pf_img_vertical_title_letter_sapce' => '0',
			'pf_img_border_color' => '#ffffff',
			'animation_names' => '',
			'pf_loadmore_text' => 'LOAD MORE',
			'pf_loadmore_bg_color' => '#ff3333',
			'pf_loadmore_text_color' => '#fff',
			'pf_loadmore_hover_bg_color' => '#ffffff',
			'pf_loadmore_hover_text_color' => '#ff3333',
			'pf_gray_scale_mode' => '',
			'change_filter_tab_all_text' => esc_html__('ALL', $julia_plugin_name),
			'pf_enable_masonry_gallery' => '',
			'disable_add_remove_button' => '',
		)); ?>
	    <script type="text/javascript">
	      (function($) {
	      "use strict";
	      $(function() {
			/* Filter tabs show / Hide */
			$("#<?php echo $this->get_field_id('kaya_portfolio_filter') ?>").change(function () {
				$(".<?php echo $this->get_field_id('filter_tab_bg_color'); ?>").hide();
				var selectlayout = $("#<?php echo $this->get_field_id('kaya_portfolio_filter') ?> option:selected").val(); 
				switch(selectlayout)
				{
				case 'true':
					$(".<?php echo $this->get_field_id('filter_tab_bg_color'); ?>").show();
				break;      
				}
			}).change();
			$('.portfolio_color_pickr').each(function(){ // Color pickr
				$(this).wpColorPicker();
			});
	      });
	    })(jQuery);
	  </script>
		<div class="input-elements-wrapper">
			<p>
				<label for="<?php echo $this->get_field_id('portfolio_widget_category') ?>"> <?php _e('Enter Portfolio Category IDs : ',$julia_plugin_name) ?> </label>
				<input type="text" name="<?php echo $this->get_field_name('portfolio_widget_category') ?>" id="<?php echo $this->get_field_id('portfolio_widget_category') ?>" class="widefat" value="<?php echo $instance['portfolio_widget_category'] ?>" />
				<em><strong style="color:green;"><?php _e('Available Categories and IDs : ',$julia_plugin_name); ?> </strong> <?php echo implode(', ', $pf_cats_name); ?></em><br />
				<stong><?php _e('Note:',$julia_plugin_name); ?></strong><?php _e('Separate IDs with commas only',$julia_plugin_name); ?>
			</p>
		</div>
		<!-- Filter Tabs -->
		<div class="input-elements-wrapper">
			 <p class="one_fourth">
			 <label for="<?php echo $this->get_field_id('kaya_portfolio_filter') ?>">  <?php _e('Portfolio Filter Tabs',$julia_plugin_name)?>  </label>
			  <select id="<?php echo $this->get_field_id('kaya_portfolio_filter') ?>" name="<?php echo $this->get_field_name('kaya_portfolio_filter') ?>">
			    <option value="false" <?php selected('false', $instance['kaya_portfolio_filter']) ?>>    <?php esc_html_e('False', $julia_plugin_name) ?>   </option>
			    <option value="true" <?php selected('true', $instance['kaya_portfolio_filter']) ?>>    <?php esc_html_e('True', $julia_plugin_name) ?>    </option>
			  </select>
			</p>
			<div class="<?php echo $this->get_field_id('filter_tab_bg_color'); ?>">
				<p class="one_fourth" id="<?php echo $this->get_field_id('filter_tab_bg_color'); ?>">
				  <label for="<?php echo $this->get_field_id('filter_tab_bg_color'); ?>"><?php _e('Filter Tab BG Color',$julia_plugin_name) ?></label>
				  <input type="text" name="<?php echo $this->get_field_name('filter_tab_bg_color') ?>" id="<?php echo $this->get_field_id('filter_tab_bg_color') ?>" class="widefat portfolio_color_pickr" value="<?php echo $instance['filter_tab_bg_color'] ?>" />
				</p>
				<p class="one_fourth" id="<?php echo $this->get_field_id('filter_tab_text_color'); ?>">
				  <label for="<?php echo $this->get_field_id('filter_tab_text_color'); ?>"><?php _e('Filter Tab Text Color',$julia_plugin_name) ?></label>
				  <input type="text" name="<?php echo $this->get_field_name('filter_tab_text_color') ?>" id="<?php echo $this->get_field_id('filter_tab_text_color') ?>" class="portfolio_color_pickr" value="<?php echo $instance['filter_tab_text_color'] ?>" />
				</p>
				<p class="one_fourth_last" id="<?php echo $this->get_field_id('filter_tab_border_color'); ?>">
				  <label for="<?php echo $this->get_field_id('filter_tab_border_color'); ?>"><?php _e('Filter Tab Border Color',$julia_plugin_name) ?></label>
				  <input type="text" name="<?php echo $this->get_field_name('filter_tab_border_color') ?>" id="<?php echo $this->get_field_id('filter_tab_border_color') ?>" class="portfolio_color_pickr" value="<?php echo $instance['filter_tab_border_color'] ?>" />
				</p>
				<p class="one_fourth" style="clear:both;" id="<?php echo $this->get_field_id('filter_tab_border_active_color'); ?>">
				    <label for="<?php echo $this->get_field_id('filter_tab_border_active_color'); ?>"><?php _e('Filter Tab Active Border Color',$julia_plugin_name) ?></label>
				    <input type="text" name="<?php echo $this->get_field_name('filter_tab_border_active_color') ?>" id="<?php echo $this->get_field_id('filter_tab_border_active_color') ?>" class="portfolio_color_pickr" value="<?php echo $instance['filter_tab_border_active_color'] ?>" />
				 </p>
				<p class="one_fourth" id="<?php echo $this->get_field_id('filter_tab_border_radius'); ?>">
				  <label for="<?php echo $this->get_field_id('filter_tab_border_radius'); ?>"><?php _e('Filter Tab Border Radius',$julia_plugin_name) ?></label>
				  <input type="text" name="<?php echo $this->get_field_name('filter_tab_border_radius') ?>" id="<?php echo $this->get_field_id('filter_tab_border_radius') ?>" class="small-text" value="<?php echo $instance['filter_tab_border_radius'] ?>" />
				  <small><?php _e('px',$julia_plugin_name) ?></small>
				</p>
				<p class="one_fourth" id="<?php echo $this->get_field_id('filter_tab_active_bg_color'); ?>">
				  <label for="<?php echo $this->get_field_id('filter_tab_active_bg_color'); ?>"><?php _e('Filter Tab Acive BG Color',$julia_plugin_name) ?></label>
				  <input type="text" name="<?php echo $this->get_field_name('filter_tab_active_bg_color') ?>" id="<?php echo $this->get_field_id('filter_tab_active_bg_color') ?>" class="portfolio_color_pickr" value="<?php echo $instance['filter_tab_active_bg_color'] ?>" />
				</p>
				<p class="one_fourth_last" id="<?php echo $this->get_field_id('filter_tab_active_text_color'); ?>">
				  <label for="<?php echo $this->get_field_id('filter_tab_active_text_color'); ?>"><?php _e('Filter Tab Active Text Color',$julia_plugin_name) ?></label>
				  <input type="text" name="<?php echo $this->get_field_name('filter_tab_active_text_color') ?>" id="<?php echo $this->get_field_id('filter_tab_active_text_color') ?>" class="portfolio_color_pickr" value="<?php echo $instance['filter_tab_active_text_color'] ?>" />
				</p>
				<p class="one_fourth" style="clear:both;" id="<?php echo $this->get_field_id('filter_tab_padding_top_bottom'); ?>">
				  <label for="<?php echo $this->get_field_id('filter_tab_padding_top_bottom'); ?>"><?php _e('Filter Tab Padding Top & Bottom',$julia_plugin_name) ?></label>
				  <input type="text" name="<?php echo $this->get_field_name('filter_tab_padding_top_bottom') ?>" id="<?php echo $this->get_field_id('filter_tab_padding_top_bottom') ?>" class="small-text" value="<?php echo $instance['filter_tab_padding_top_bottom'] ?>" />
				  <small><?php _e('px',$julia_plugin_name) ?></small>
				</p>
				<p class="one_fourth" id="<?php echo $this->get_field_id('filter_tab_padding_left_right'); ?>">
				  <label for="<?php echo $this->get_field_id('filter_tab_padding_left_right'); ?>"><?php _e('Filter Tab Padding Left & Right',$julia_plugin_name) ?></label>
				  <input type="text" name="<?php echo $this->get_field_name('filter_tab_padding_left_right') ?>" id="<?php echo $this->get_field_id('filter_tab_padding_left_right') ?>" class="small-text" value="<?php echo $instance['filter_tab_padding_left_right'] ?>" />
				  <small><?php _e('px',$julia_plugin_name) ?></small>
				</p>
				<p class="one_fourth" id="<?php echo $this->get_field_id('change_filter_tab_all_text'); ?>">
				  <label for="<?php echo $this->get_field_id('change_filter_tab_all_text'); ?>"><?php _e('Change Filter Tabs "ALL" Text',$julia_plugin_name) ?></label>
				  <input type="text" name="<?php echo $this->get_field_name('change_filter_tab_all_text') ?>" id="<?php echo $this->get_field_id('change_filter_tab_all_text') ?>" class="widefat" value="<?php echo $instance['change_filter_tab_all_text'] ?>" />
				</p>
				</div> 
			</div>
		<!-- END -->	
		<div class="input-elements-wrapper">
			<p class="one_fourth">
		        <label for="<?php echo $this->get_field_id('select_pf_columns') ?>"> <?php _e('Select Columns',$julia_plugin_name) ?></label>
		        <select id="<?php echo $this->get_field_id('select_pf_columns') ?>" name="<?php echo $this->get_field_name('select_pf_columns') ?>">
		        	<option value="8" <?php selected('8', $instance['select_pf_columns']) ?>> <?php esc_html_e('Column8', $julia_plugin_name) ?>   </option>
		        	<option value="7" <?php selected('7', $instance['select_pf_columns']) ?>> <?php esc_html_e('Column7', $julia_plugin_name) ?>   </option>
		        	<option value="6" <?php selected('6', $instance['select_pf_columns']) ?>> <?php esc_html_e('Column6', $julia_plugin_name) ?>   </option>
			       	<option value="5" <?php selected('5', $instance['select_pf_columns']) ?>> <?php esc_html_e('Column5', $julia_plugin_name) ?>   </option>
			        <option value="4" <?php selected('4', $instance['select_pf_columns']) ?>> <?php esc_html_e('Column4', $julia_plugin_name) ?>   </option>
			        <option value="3" <?php selected('3', $instance['select_pf_columns']) ?>>  <?php esc_html_e('Column3', $julia_plugin_name) ?></option>
			        <option value="2" <?php selected('2', $instance['select_pf_columns']) ?>>  <?php esc_html_e('Column2', $julia_plugin_name) ?></option>
			        <option value="1" <?php selected('1', $instance['select_pf_columns']) ?>>  <?php esc_html_e('Column1', $julia_plugin_name) ?></option>
		        </select>
	      	</p>
	      	<p class="one_fourth">
				<label for="<?php echo $this->get_field_id('pf_display_orderby') ?>"> <?php _e('Orderby',$julia_plugin_name) ?> </label>
				<select id="<?php echo $this->get_field_id('pf_display_orderby') ?>" name="<?php echo $this->get_field_name('pf_display_orderby') ?>">
					<option value="date" <?php selected('date', $instance['pf_display_orderby']) ?>>  <?php esc_html_e('Date',$julia_plugin_name) ?>  </option>
					<option value="menu_order" <?php selected('menu_order', $instance['pf_display_orderby']) ?>><?php esc_html_e('Menu Order', '') ?> </option>
					<option value="title" <?php selected('title', $instance['pf_display_orderby']) ?>>  <?php esc_html_e('Title', $julia_plugin_name) ?>  </option>
					<option value="rand" <?php selected('rand', $instance['pf_display_orderby']) ?>>   <?php esc_html_e('Random', $julia_plugin_name) ?>  </option>
					<option value="author" <?php selected('author', $instance['pf_display_orderby']) ?>>  <?php esc_html_e('Author', $julia_plugin_name) ?>  </option>
				</select>
			</p>
			<p class="one_fourth">
				<label for="<?php echo $this->get_field_id('pf_display_order') ?>"> <?php _e('Order',$julia_plugin_name) ?> </label>
				<select id="<?php echo $this->get_field_id('pf_display_order') ?>" name="<?php echo $this->get_field_name('pf_display_order') ?>">
					<option value="DESC" <?php selected('DESC', $instance['pf_display_order']) ?>>   <?php esc_html_e('Descending', $julia_plugin_name) ?>  </option>
					<option value="ASC" <?php selected('ASC', $instance['pf_display_order']) ?>>  <?php esc_html_e('Ascending', $julia_plugin_name) ?>   </option>
				</select>
			</p>
			<p class="one_fourth_last">
				<label for="<?php echo $this->get_field_id('pf_img_width') ?>">  <?php _e('Image Width & Height',$julia_plugin_name)?>  </label>
				<input type="text" class="small-text" id="<?php echo $this->get_field_id('pf_img_width') ?>" value="<?php echo esc_attr($instance['pf_img_width']) ?>" name="<?php echo $this->get_field_name('pf_img_width') ?>" />X
				<input type="text" class="small-text" id="<?php echo $this->get_field_id('pf_img_height') ?>" value="<?php echo esc_attr($instance['pf_img_height']) ?>" name="<?php echo $this->get_field_name('pf_img_height') ?>" />
				<small><?php _e('px',$julia_plugin_name); ?></small>
			</p>
		</div>
		<div class="input-elements-wrapper">
			<p class="one_fourth <?php echo $this->get_field_id('pf_img_border_color'); ?>">
				<label for="<?php echo $this->get_field_id('pf_img_border_color'); ?>"><?php _e('Vertical Title BG Color',$julia_plugin_name) ?></label>
				<input type="text" name="<?php echo $this->get_field_name('pf_img_border_color') ?>" id="<?php echo $this->get_field_id('pf_img_border_color') ?>" class="portfolio_color_pickr" value="<?php echo $instance['pf_img_border_color'] ?>" />
			</p>
			<p class="one_fourth">
				<label for="<?php echo $this->get_field_id('pf_img_vertical_title_size') ?>">  <?php _e('Image Vertical Title Font Size',$julia_plugin_name) ?>  </label>
				<input type="text" class="small-text" id="<?php echo $this->get_field_id('pf_img_vertical_title_size') ?>" value="<?php echo esc_attr($instance['pf_img_vertical_title_size']) ?>" name="<?php echo $this->get_field_name('pf_img_vertical_title_size') ?>" />
				<small><?php _e('px',$julia_plugin_name); ?></small>
			</p>
			<p class="one_fourth">
				<label for="<?php echo $this->get_field_id('vertical_title_font_weight') ?>"> <?php _e('Vertical Title Font Weight',$julia_plugin_name) ?></label>
				<select id="<?php echo $this->get_field_id('vertical_title_font_weight') ?>" name="<?php echo $this->get_field_name('vertical_title_font_weight') ?>">
					<option value="normal" <?php selected('normal', $instance['vertical_title_font_weight']) ?>> <?php esc_html_e('Normal', $julia_plugin_name) ?>   </option>
					<option value="bold" <?php selected('bold', $instance['vertical_title_font_weight']) ?>>  <?php esc_html_e('Bold',$julia_plugin_name) ?></option>
				</select>
			</p>
			<p class="one_fourth_last">
				<label for="<?php echo $this->get_field_id('vertical_title_font_style') ?>"> <?php _e('Vertical Title Font Style',$julia_plugin_name) ?></label>
				<select id="<?php echo $this->get_field_id('vertical_title_font_style') ?>" name="<?php echo $this->get_field_name('vertical_title_font_style') ?>">
					<option value="normal" <?php selected('normal', $instance['vertical_title_font_style']) ?>> <?php esc_html_e('Normal', $julia_plugin_name) ?>   </option>
					<option value="italic" <?php selected('italic', $instance['vertical_title_font_style']) ?>>  <?php esc_html_e('Italic', $julia_plugin_name) ?></option>
				</select>
			</p>
			<p class="one_fourth" style="clear:both;">
				<label for="<?php echo $this->get_field_id('pf_img_vertical_title_letter_sapce') ?>"> <?php _e('Image Vertical Title Letter Size',$julia_plugin_name) ?></label>
				<input type="text" class="small-text" id="<?php echo $this->get_field_id('pf_img_vertical_title_letter_sapce') ?>" value="<?php echo esc_attr($instance['pf_img_vertical_title_letter_sapce']) ?>" name="<?php echo $this->get_field_name('pf_img_vertical_title_letter_sapce') ?>" />
				<small><?php _e('px',$julia_plugin_name); ?></small>
			</p>
			<p class="one_fourth <?php echo $this->get_field_id('pf_img_vertical_title_color'); ?>">
				<label for="<?php echo $this->get_field_id('pf_img_vertical_title_color'); ?>"><?php _e('Image Vertical Title Color',$julia_plugin_name) ?></label>
				<input type="text" name="<?php echo $this->get_field_name('pf_img_vertical_title_color') ?>" id="<?php echo $this->get_field_id('pf_img_vertical_title_color') ?>" class="portfolio_color_pickr" value="<?php echo $instance['pf_img_vertical_title_color'] ?>" />
			</p>
		</div>
		<div class="input-elements-wrapper <?php echo $this->get_field_id('pf_content_bg_color') ?>">
			<p class="one_fourth">
				<label for="<?php echo $this->get_field_id('pf_content_bg_color') ?>">  <?php _e('Model Details Background Color',$julia_plugin_name) ?>  </label>
				<input type="text" class="portfolio_color_pickr" id="<?php echo $this->get_field_id('pf_content_bg_color') ?>" value="<?php echo esc_attr($instance['pf_content_bg_color']) ?>" name="<?php echo $this->get_field_name('pf_content_bg_color') ?>" />
			</p>	
			<p class="one_fourth <?php echo $this->get_field_id('pf_description_color'); ?>">
				<label for="<?php echo $this->get_field_id('pf_description_color'); ?>"><?php _e('Model details Color',$julia_plugin_name) ?></label>
				<input type="text" name="<?php echo $this->get_field_name('pf_description_color') ?>" id="<?php echo $this->get_field_id('pf_description_color') ?>" class="portfolio_color_pickr" value="<?php echo esc_attr($instance['pf_description_color']) ?>" />
			</p>
			<p class="one_fourth">
				<label for="<?php echo $this->get_field_id('pf_description_letter_space') ?>">  <?php _e('Model details Font Letter Space',$julia_plugin_name) ?>  </label>
				<input type="text" class="small-text" id="<?php echo $this->get_field_id('pf_description_letter_space') ?>" value="<?php echo esc_attr($instance['pf_description_letter_space']) ?>" name="<?php echo $this->get_field_name('pf_description_letter_space') ?>" />
				<small><?php _e('px',$julia_plugin_name); ?></small>
			</p>
			
		</div>
		<div class="input-elements-wrapper">
			<p class="one_fourth">
			  <label for="<?php echo $this->get_field_id('pf_gray_scale_mode') ?>">  <?php _e('Enable Gray Scale Images',$julia_plugin_name)?>  </label>
			  <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("pf_gray_scale_mode"); ?>" name="<?php echo $this->get_field_name("pf_gray_scale_mode"); ?>"<?php checked( (bool) $instance["pf_gray_scale_mode"], true ); ?> />
			</p>
			<p class="one_fourth">
			  <label for="<?php echo $this->get_field_id('pf_enable_masonry_gallery') ?>">  <?php _e('Enable Masonry Gallery ',$julia_plugin_name)?>  </label>
			  <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("pf_enable_masonry_gallery"); ?>" name="<?php echo $this->get_field_name("pf_enable_masonry_gallery"); ?>"<?php checked( (bool) $instance["pf_enable_masonry_gallery"], true ); ?> />
			</p>
			<p class="one_fourth">
			  <label for="<?php echo $this->get_field_id('disable_add_remove_button') ?>">  <?php _e('Disable Shortlist Button',$julia_plugin_name)?>  </label>
			  <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("disable_add_remove_button"); ?>" name="<?php echo $this->get_field_name("disable_add_remove_button"); ?>"<?php checked( (bool) $instance["disable_add_remove_button"], true ); ?> />
			</p>
			</div>
		<div class="input-elements-wrapper">
			<p class="one_fourth">
				<label for="<?php echo $this->get_field_id('portfolio_limit') ?>"> <?php _e('Display Number of Images',$julia_plugin_name) ?>  </label>
				<input type="text" class="small-text" id="<?php echo $this->get_field_id('portfolio_limit') ?>" value="<?php echo esc_attr($instance['portfolio_limit']) ?>" name="<?php echo $this->get_field_name('portfolio_limit') ?>" />
			</p>		
		</div>
		<div class="input-elements-wrapper">
			<p>
				<label for="<?php echo $this->get_field_id('animation_names') ?>">  <?php _e('Select Animation Effect',$julia_plugin_name) ?>  </label>
				<?php animation_effects($this->get_field_name('animation_names'), $instance['animation_names'] ); ?>
			<p>
		</div>
	<?php }
}
julia_kaya_register_widgets('portfolio', __FILE__);
?>