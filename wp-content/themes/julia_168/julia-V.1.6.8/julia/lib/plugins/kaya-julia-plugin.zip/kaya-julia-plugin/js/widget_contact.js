jQuery(function() {
//----------------------------------------------------
// Contact Form 
//----------------------------------------------------
 jQuery('#main input#contact_submit').on("click",function(e) { 
		    e.preventDefault();
		var name = jQuery('input#name').val();
		var email = jQuery('input#email').val();
		var message = jQuery('textarea#message').val();
		var pattern = new RegExp(/^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/);
		var subject = jQuery('input#subject').val();
		var siteemail = jQuery('input#siteemail').val();
		var hasError = false;
		 if(name=='')
		 {
			 jQuery('[name="name"]').addClass('vaidate_error');
			 hasError = true;
		 }else{
			 jQuery('[name="name"]').removeClass('vaidate_error');
			 }
			 
		if(email=='')
		 {
			 jQuery('[name="email"]').addClass('vaidate_error');
			 hasError = true;
		 }else{
			if (!pattern.test(email)) {
				jQuery('[name="email"]').addClass('vaidate_error');
				 hasError = true;
			 }else{
				 jQuery('[name="email"]').removeClass('vaidate_error');
				 }
			 }

		if(message=="")
			 {
				 jQuery('[name="message"]').addClass('vaidate_error');
				 hasError = true;
			 }else{
				 jQuery('[name="message"]').removeClass('vaidate_error');
			}
		if(subject=="")
			 {
				 jQuery('[name="subject"]').addClass('vaidate_error');
				 hasError = true;
			 }else{
				 jQuery('[name="subject"]').removeClass('vaidate_error');
				 }
		 var captcha_id = jQuery('#contact-form').data('captcha-id');
		  if( captcha_id ){
		    var recaptcha_data = grecaptcha.getResponse();
		    if( recaptcha_data == '' ){
		      jQuery('#contact_form_recaptcha').show().css('height','50px;');
		      return false;
		    }else{
		      jQuery('#contact_form_recaptcha').hide();
		    }
		  }	 
        if(hasError) { return; }
		else {	
			jQuery('#contact_submit').css('cursor','not-allowed').attr('disabled', 'disabled');
				jQuery.ajax({
		            type: 'post',
		           	 url: kaya_ajax_url.ajaxurl,
		           	 data: {
				        action: 'julia_kaya_contact_email',
				        'name': name,
				        'email' : email,
				        'subject' : subject,
				        'message':message,
				        'siteemail':siteemail,
				      },
		            //data:  'action='+julia_kaya_contact_email+'&name=' + name + '&email=' + email +'&subject='+ subject +'&message=' + message +'&siteemail='+ siteemail,
		            success: function(data) {
		            	jQuery('#contact_submit').css('cursor','pointer').removeAttr('disabled');
		                jQuery('div#contact_response').html(data).css('display', 'block');	
		                jQuery('#contact_form_recaptcha').hide();
		               	jQuery('#contact-form')[0].reset();
		                if( captcha_id ){
				            grecaptcha.reset();
				          }
		   
		         }
		     }); // end ajax
		}
    });
});
// Date format
jQuery('#application-form').each(function(){
   jQuery(this).find('#startdate').datepicker({
       dateFormat : 'dd-mm-yy'
    });
});