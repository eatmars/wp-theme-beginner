(function($) {
  "use strict";
	$(function() {
// Rwmb Select Option hide if empty
	$('.rwmb-select').each(function(){
		 $(this).find('option:empty').remove();
	});
	// End		
// Portfolio Slider Data
$('#kaya_page_title_disable').change(function(){
	$('.kaya_custom_title').hide();
	$('.select_page_title_option').hide();
	$('.page_title_bar_styles').hide();
	var slider_data = $('#kaya_page_title_disable').is(':checked');
	if( slider_data != true ){
		$('.kaya_custom_title').show();
		$('.page_title_bar_styles').show();
		$('.select_page_title_option').show();
	}
}).change();
//Meta Page Optons
$("#select_page_options").change(function() {
	var select_options = $("#select_page_options option:selected").val();
	$(".post_slide_pattern_disable").hide();
	// POst Slider 
	$(".kaya_post_category").hide();
	$(".kaya_post_slider_interval").hide();
	$(".kaya_slider_type").hide();
	$(".select_slider_style").hide();
	$(".slider_nav_options").hide();
	$(".post_slide_buttons_color").hide();
	$(".post_slide_buttons_active_color").hide();
	$(".post_slider_height").hide();
	$(".Kaya_post_slide_animation_type").hide();
	$(".Kaya_post_slider_auto_play").hide();
	$(".post_slide_images_order_by").hide();
	$(".post_slide_images_order").hide();
	$(".enable_fluid_slider").hide();
	$(".slider_overlap_menu").hide();
	$(".enable_slider_window_height").hide();
	$(".customslider_type").hide();
	$(".slider_pattern_img").hide();
	$(".post_slider_desc_width").hide();
	$(".Kaya_post_slider_columns").hide();
	$('.post_slider_disable_screen_height').hide();
	$('.post_slider_width').hide();
	$(".post_slider_enable_auto_width").hide();
	$(".page_middle_content").hide();
	$(".post_slide_title_color").hide();
	$(".slide_content_bg_color").hide();
	$(".post_slide_title_outer_bg_color").hide();
	$(".post_slide_gray_scale").hide();
	$(".disable_title_on_hover").hide();
	$(".kaya_columns_slider_images").hide();
	$(".kaya_columns_images").hide();
	$(".post_slide_desc_color").hide();
	// Video
	$(".video_bg_id").hide();
	$(".video_bg_webm").hide();
	$(".video_bg_mp4").hide();
	$(".video_bg_ogg").hide();
	$(".video_bg_description").hide();
	$(".video_bg_height").hide();
	$(".video_bg_color").hide();
	$(".bg_video_opcaity").hide();
	$(".enable_video_screen_height").hide();
	$(".select_video_bg_type").hide();
	switch(select_options){
		case 'page_slider_setion' :
			$(".post_slide_pattern_disable").show();
			$(".kaya_post_category").show();
			$(".kaya_slider_type").show();
			$(".select_slider_style").show();
			$(".slider_nav_options").show();
			$(".post_slide_buttons_color").show();
			$(".post_slide_buttons_active_color").show();
			$(".post_slider_height").show();
			$(".Kaya_post_slide_animation_type").show();
			$(".Kaya_post_slider_auto_play").show();
			$(".post_slide_images_order_by").show();
			$(".post_slide_images_order").show();
			$(".enable_fluid_slider").show();
			$(".slider_overlap_menu").show();
			$(".enable_slider_window_height").show();
			$(".customslider_type").show();
			$(".slider_pattern_img").show();
			$(".post_slider_desc_width").show();
			$(".kaya_post_slider_interval").show();
			$(".Kaya_post_slider_columns").show();
			page_slider_options();
			page_slider_auto_width_options();
			break;
		case 'video_bg':
			$(".video_bg_id").show();
			$(".select_video_bg_type").show();
			$(".video_bg_description").show();
			$(".video_bg_height").show();
			$(".bg_video_opcaity").show();
			$(".video_bg_color").show();
			$(".page_middle_content").show();
			$(".page_footer_container").show();
			$(".enable_video_screen_height").show();
			$('.slider_over_lap_menu').show();
			bg_video_option();
			break;	
	}	

}).change();

// Meta BOxes
function page_slider_options(){
	$("#kaya_slider_type").change(function () {	
	var selectlayout = $("#kaya_slider_type option:selected").val();
		$(".post_slide_pattern_disable").hide();
		$(".kaya_post_category").hide();
		$(".select_slider_style").hide();
		$(".slider_nav_options").hide();
		$(".post_slide_buttons_color").hide();
		$(".post_slide_buttons_active_color").hide();
		$(".post_slider_height").hide();
		$(".Kaya_post_slide_animation_type").hide();
		$(".Kaya_post_slider_auto_play").hide();
		$(".post_slide_images_order_by").hide();
		$(".post_slide_images_order").hide();
		$(".enable_fluid_slider").hide();
		$(".slider_overlap_menu").hide();
		$(".enable_slider_window_height").hide();
		$(".customslider_type").hide();
		$(".slider_pattern_img").hide();
		$(".post_slider_desc_width").hide();
		$(".kaya_post_slider_interval").hide();
		$(".post_slider_enable_auto_width").hide();
		$(".page_middle_content").hide();
		$(".post_slide_title_color").hide();
		$(".slide_content_bg_color").hide();
		$(".post_slide_title_outer_bg_color").hide();
		$(".post_slide_gray_scale").hide();
		$(".disable_title_on_hover").hide();
		$('.post_slider_disable_screen_height').hide();
		$('.Kaya_post_slider_columns').hide();
		$(".kaya_columns_slider_images").hide();
			$(".kaya_columns_images").hide();
		$(".post_slide_desc_color").hide();
		switch(selectlayout)
		{
			case 'customslider':
				$(".customslider_type").show();	
				break;
			case 'kaya_post_slider':
				$(".kaya_post_category").show();
				$(".post_slide_pattern_disable").show();
				$(".select_slider_style").show();
				$(".slider_nav_options").show();
				$(".post_slide_buttons_color").show();
				$(".post_slide_buttons_active_color").show();
				$(".Kaya_post_slide_animation_type").show();
				$(".Kaya_post_slider_auto_play").show();
				$(".post_slide_images_order_by").show();
				$(".post_slide_images_order").show();
				$(".enable_fluid_slider").show();
				$(".slider_overlap_menu").show();
				$(".enable_slider_window_height").show();
				$(".slider_pattern_img").show();
				$(".post_slider_desc_width").show();
				$(".kaya_post_slider_interval").show();
					$(".kaya_columns_images").show();
				break;	
			case 'columns_post_slider':
				$(".kaya_columns_slider_images").show();
				$(".select_slider_style").show();
				$(".slider_nav_options").show();
				$(".post_slide_buttons_color").show();
				$(".post_slide_buttons_active_color").show();
				$(".post_slider_height").show();
				$(".Kaya_post_slider_auto_play").show();
				$(".enable_slider_window_height").show();
				$(".Kaya_post_slider_columns").show();
				$(".post_slider_enable_auto_width").show();
				$(".page_middle_content").show();
				$(".post_slide_title_color").show();
				$(".slide_content_bg_color").show();
				$(".post_slide_title_outer_bg_color").show();
				$(".post_slide_gray_scale").show();
				$(".disable_title_on_hover").show();
				$(".post_slide_desc_color").show();
				break;			
		}
}).change();
}
//Slider Options
function page_slider_auto_width_options(){
	$("#post_slider_enable_auto_width").change(function () {
		$('.post_slider_disable_screen_height').show();
		$('.post_slider_width').show();
		$('.Kaya_post_slider_columns').show();
		$('.post_slider_height').show();
		julia_kaya_slider_height();
		var slide_auto_width = $("#post_slider_enable_auto_width").is(':checked');
		if( slide_auto_width ){
			$('.post_slider_disable_screen_height').hide();
			$('.post_slider_width').hide();
			$('.Kaya_post_slider_columns').hide();
			$('.post_slider_height').hide();
			//julia_kaya_slider_height();
		}else{

		}
	}).change();
}
function julia_kaya_slider_height(){
	$('.post_slider_disable_screen_height input').change(function(){
		$('.post_slider_height').hide();
		var slider_height = $('.post_slider_disable_screen_height input').is(':checked');
		if( slider_height ){
			$('.post_slider_height').show();
		}
	}).change();
}
// Page title Options
function select_page_title_option(){
	$('#select_page_title_option').change(function(){
		$('.kaya_custom_title').hide();
		$('.kaya_custom_title_description').hide();
		var title_option = $('#select_page_title_option option:selected').val();
		switch( title_option ){
			case 'default_page_title':
				$('.kaya_custom_title').hide();
				$('.kaya_custom_title_description').hide();
				break;
			case 'custom_page_title':
				$('.kaya_custom_title').show();
				$('.kaya_custom_title_description').show();
				break;
			case 'default':
				break;		
		}
	}).change();
}
select_page_title_option();
function bg_video_option(){
	$('#select_video_bg_type').change(function(){
		var option_value = $("#select_video_bg_type option:selected").val();
		//$(".video_bg_id").hide();
		$(".video_bg_webm").hide();
		$(".video_bg_mp4").hide();
		$(".video_bg_ogg").hide();
		switch(option_value){
			case 'youtube_video':
				//$(".video_bg_id").show();
				break;
			case 'video_webm':
				$(".video_bg_webm").show();
				$(".video_bg_mp4").show();
				$(".video_bg_ogg").show();
				break;	
			case 'default':
				break;		
		}

	}).change();
}
// portfolio single page on change
$('select#list_images').change(function(){
	$('#gallery_with_space').hide();
	var list_images_val = $('#list_images option:selected').val();
	switch(list_images_val){
		case 'isotope_gallery':
			$('#gallery_with_space').show();
			break;
		case 'grid_gallery':
			$('#gallery_with_space').show();
			break;	
		default:
		 	break;	
	}	
}).change();
// Page title bar image
function page_title_bar_styles(){
	$('#page_title_bar_styles').change(function(){
		$('.page_title_bar_bg_image').hide();
		$('.page_title_bg_img_repeat').hide();
		$('.page_title_bar_bg_color').hide();
		$('.page_title_bar_settings').hide();
		$('.page_title_bar_desc_color').hide();
		$('.page_title_bar_title_color').hide();
		var title_option = $('#page_title_bar_styles option:selected').val();
		switch( title_option ){
			case 'page_custom_styles':
				page_title_bar_settings();
				$('.page_title_bar_settings').show();
				$('.page_title_bar_desc_color').show();
				$('.page_title_bar_title_color').show();
				break;
			case 'theme_customizer':
				
				break;
			case 'default':
				break;		
		}
	}).change();
}//End
page_title_bar_styles();
function page_title_bar_settings(){
	$('#page_title_bar_settings').change(function(){
		$('.page_title_bar_bg_image').hide();
		$('.page_title_bar_bg_color').hide();
		$('.page_title_bg_img_repeat').hide();
		var title_option = $('#page_title_bar_settings option:selected').val();
		switch( title_option ){
			case 'page_titlebar_bg_img':
				$('.page_title_bar_bg_image').show();
				$('.page_title_bg_img_repeat').show();
				break;
			case 'page_titlebar_bg_color':
				$('.page_title_bar_bg_color').show();
				break;
			case 'default':
				break;		
		}
	}).change();
}//End
// Portfolio Tab-1
$('#pf_gallery_tab1_images').change(function(){
	$('#pf_tab1_images_columns').parent().parent().hide();
	var pf_tab1_columns = $('#pf_gallery_tab1_images').is(':checked');
	if( pf_tab1_columns == true ){
		$('#pf_tab1_images_columns').parent().parent().show();
	}
}).change();
// Portfolio Tab-2
$('#pf_gallery_tab2_images').change(function(){
	$('#pf_tab2_images_columns').parent().parent().hide();
	var pf_tab1_columns = $('#pf_gallery_tab2_images').is(':checked');
	if( pf_tab1_columns == true ){
		$('#pf_tab2_images_columns').parent().parent().show();
	}
}).change();
// Portfolio Tab-3
$('#pf_gallery_tab3_images').change(function(){
	$('#pf_tab3_images_columns').parent().parent().hide();
	var pf_tab1_columns = $('#pf_gallery_tab3_images').is(':checked');
	if( pf_tab1_columns == true ){
		$('#pf_tab3_images_columns').parent().parent().show();
	}
}).change();
// Portfolio Tab-4
$('#pf_gallery_tab4_images').change(function(){
	$('#pf_tab4_images_columns').parent().parent().hide();
	var pf_tab1_columns = $('#pf_gallery_tab4_images').is(':checked');
	if( pf_tab1_columns == true ){
		$('#pf_tab4_images_columns').parent().parent().show();
	}
}).change();
// Portfolio Tab-5
$('#pf_gallery_tab5_images').change(function(){
	$('#pf_tab5_images_columns').parent().parent().hide();
	var pf_tab1_columns = $('#pf_gallery_tab5_images').is(':checked');
	if( pf_tab1_columns == true ){
		$('#pf_tab5_images_columns').parent().parent().show();
	}
}).change();
//page_slider_options();
    // Display only needed post meta boxes
    var Kaya_post_options = $('#post-formats-select input'),
        kaya_meta_link = $('#kaya_link_format'),
        kaya_pf_link = $('#post-format-link'),
        kaya_meta_gallery = $('#kaya_post_format_gallery'),
        kaya_pf_gallery = $('#post-format-gallery'),
        kaya_meta_video = $('#kaya_post_format_video'),
        kaya_pf_video = $('#post-format-video'),
        kaya_meta_audio = $('#kaya_audio_format'),
        kaya_pf_audio = $('#post-format-audio'),
        kaya_meta_quote = $('#kaya_quote_format_quote'),
        kaya_pf_quote = $('#post-format-quote');

    function kaya_hide_post_formates(){
        kaya_meta_link.css('display', 'none');
        kaya_meta_gallery.css('display', 'none');
        kaya_meta_video.css('display', 'none');
        kaya_meta_audio.css('display', 'none');
        kaya_meta_quote.css('display', 'none');
    }

    kaya_hide_post_formates();

    Kaya_post_options.on('change', function(){
        var that = $(this);
        kaya_hide_post_formates();
        if(that.val() === 'link'){
            kaya_meta_link.css('display', 'block');
        }else if(that.val() === 'gallery'){
            kaya_meta_gallery.css('display', 'block');
        }else if(that.val() === 'video'){
            kaya_meta_video.css('display', 'block');
        }else if(that.val() === 'audio'){
            kaya_meta_audio.css('display', 'block');
        }else if(that.val() === 'quote'){
            kaya_meta_quote.css('display', 'block');
        }
    });

    if(kaya_pf_link.is(':checked')) kaya_meta_link.css('display', 'block');
    if(kaya_pf_gallery.is(':checked')) kaya_meta_gallery.css('display', 'block');
    if(kaya_pf_video.is(':checked')) kaya_meta_video.css('display', 'block');
    if(kaya_pf_audio.is(':checked')) kaya_meta_audio.css('display', 'block');
    if(kaya_pf_quote.is(':checked')) kaya_meta_quote.css('display', 'block');
});
})(jQuery);