<?php
if( !function_exists('gilda_kaya_shortlist_start_session') ){
    function gilda_kaya_shortlist_start_session() {
        if(!session_id()) {
            session_start();
        }
    }
    add_action('init', 'gilda_kaya_shortlist_start_session', 1);
}
if( !function_exists('kaya_explode_data') ){
  function kaya_explode_data($explode_string){
     $explode_string = trim(nl2br($explode_string));
     $explode_string = str_replace('<br />', ",", trim($explode_string));
     $explode_string =  preg_replace( "/\r|\n/", "", trim($explode_string) );
     return trim($explode_string);
  }
} 
if( !function_exists('kaya_content_dsiplay_words') ){
  function kaya_content_dsiplay_words($limit) {
    //$content = explode(' ', get_the_content(), $limit);
    $content = wp_trim_words( get_the_content(), $limit, '' );
    return $content;
  }
}
if( !function_exists('kaya_short_content') ){
  function kaya_short_content($count){
    $excerpt = get_the_content();
    $excerpt = strip_tags($excerpt);
    $excerpt = substr($excerpt, 0, $count);
    $excerpt = $excerpt.'';
    return $excerpt;
  }
}
if( !function_exists('kaya_explode_data') ){
  function kaya_explode_data($explode_string){
     $explode_string = nl2br($explode_string);
     $explode_string = str_replace('<br />', ",", $explode_string);
     return $explode_string;
  }
} 
if( !function_exists('kaya_widget_admin_color') ){
  function kaya_widget_admin_color(){ ?>
      <style type="text/css">
          .elelments_group {
              background-color: #f6f6f6;
              border: 1px solid #eee;
               margin-bottom: 30px;
              padding: 10px 20px;
          }
          p{
            line-height: 2;
          }
      </style>
  <?php }
  add_action('admin_head','kaya_widget_admin_color');
}
if( !function_exists('kaya_image_resize') ){
    function kaya_image_resize($url, $width, $height=0, $align='') {
      return mr_image_resize($url, $width, $height, true, $align, false);
    }
}
if( !function_exists('julia_kaya_register_widgets') ){
  function julia_kaya_register_widgets($widget_name, $widget_path, $class = false){
        global $kaya_register_widgets, $kaya_widgets_class, $julia_plugin_name;
        $kaya_register_widgets[$widget_name] = realpath( $widget_path );
        $widget_class_names = explode('_', str_replace('-', '_', ucfirst($widget_name)));
        $widget_class_names = array_map('ucfirst', $widget_class_names);
        $widget_class_name = implode('_',  $widget_class_names);    
        if ( empty( $class ) ) {
          $class = ucfirst($julia_plugin_name).'_' . str_replace( ' ', '', ucwords( str_replace('-', ' ', $widget_class_name) ) ) . '_Widget';
        }
        $kaya_widgets_class[] = $class;
  }
}
if( !function_exists('julia_kaya_widgets_initilize') ){
  function julia_kaya_widgets_initilize(){
        global $kaya_widgets_class;
        foreach ($kaya_widgets_class as $widget_class) {
          register_widget($widget_class);
        }
      }
  add_action('widgets_init', 'julia_kaya_widgets_initilize');
}
if( !function_exists('julia_kaya_builder_init') ){
  function julia_kaya_builder_init( $widgets ) {
        global $kaya_widgets_class;
        foreach ($kaya_widgets_class as $widget_class) {
          $widgets[$widget_class]['groups'] = array( 'julia_widgets' );
        }        
        return $widgets;
      }
  add_filter( 'siteorigin_panels_widgets', 'julia_kaya_builder_init');
}
if( !function_exists('julia_add_row_style_fields') ){
  function julia_add_row_style_fields($fields) {
    global $julia_plugin_name;
    $fields['parallax'] = array(
      'name'        => __('Background Image Fixed', $julia_plugin_name),
      'type'        => 'checkbox',
      'group'       => 'design',
      'description' => __('If enabled, the background image will have a parallax effect.', 'siteorigin-panels'),
      'priority'    => 8,
    );
    return $fields;
  }
  add_filter( 'siteorigin_panels_row_style_fields', 'julia_add_row_style_fields' );
}
if( !function_exists('julia_add_row_style_attributes') ){
  function julia_add_row_style_attributes( $attributes, $args ) {
      if( !empty( $args['parallax'] ) ) {
          array_push($attributes['class'], 'parallax');
      }
      return $attributes;
  }
  add_filter('siteorigin_panels_row_style_attributes', 'julia_add_row_style_attributes', 10, 2);
}
if( !function_exists('julia_add_new_widget_tab') ){
  function julia_add_new_widget_tab($tabs) {
    global $julia_plugin_name;
      $tabs[] = array(
          'title' => __('Julia Widgets', $julia_plugin_name),
          'filter' => array(
           'groups' => array('julia_widgets')
          )
      );
      return $tabs;
  }
  add_filter('siteorigin_panels_widget_dialog_tabs', 'julia_add_new_widget_tab', 20);
}
// Age Calculator
if( !function_exists('julia_kaya_dob_cal') ){
  function julia_kaya_dob_cal($date, $date_format){
    if( $date_format == 'y_d_m' ){
      list($year,$day,$month) = explode("-",$date);
    }elseif ($date_format == 'm_d_y') {
      list($month,$day,$year) = explode("-",$date);
    }elseif ($date_format == 'd_m_y') {
      @list($day,$month,$year) = explode("-",$date);
    }else{
      @list($year,$month,$day) = explode("-",$date);
    }     
    $year_diff  = date("Y") - $year;
    $month_diff = date("m") - $month;
    $day_diff   = date("d") - $day;
    if ($day_diff < 0 || $month_diff < 0) $year_diff--;
    return $year_diff;
  }
}
/*-------------------------------------
 Shortlist Disable Section 
-------------------------------------*/
if(!function_exists('julia_kaya_shortlist_disable')){
  function julia_kaya_shortlist_disable(){
    $shortlist_disable_data = array();
    $shortlist_disable_data[0] = get_theme_mod('disable_shortlist_settings') ? get_theme_mod('disable_shortlist_settings') : '0';
    $shortlist_disable_data[1] = get_theme_mod('enable_shortlist_settings_login_users') ? ( ( is_user_logged_in() && ( get_theme_mod('enable_shortlist_settings_login_users') == '1' ) ) ? '0' : '1' ) : '0';
    return $shortlist_disable_data;
  }
}
/*-------------------------------------
 Admin Remove Model Tabs
-------------------------------------*/
function julia_kaya_admin_model_tabs(){
  $disable_admin_models_tabs = get_option('admin_options_data');
  $model_tabs_settings[0] = $disable_admin_models_tabs['tab1_text_change'] ? $disable_admin_models_tabs['tab1_text_change'] : 'PORTFOLIO';
  $model_tabs_settings[1] =  $disable_admin_models_tabs['tab2_text_change'] ?  $disable_admin_models_tabs['tab2_text_change'] : 'POLAROID';
  $model_tabs_settings[2] =  $disable_admin_models_tabs['tab3_text_change'] ?  $disable_admin_models_tabs['tab3_text_change'] : 'TAB3 TEXT';
  $model_tabs_settings[3] = $disable_admin_models_tabs['tab4_text_change'] ?  $disable_admin_models_tabs['tab4_text_change'] : 'TAB4 TEXT';
  $model_tabs_settings[4] =  $disable_admin_models_tabs['tab5_text_change'] ?  $disable_admin_models_tabs['tab5_text_change'] : 'TAB5 TEXT';
  $model_tabs_settings[5] =  $disable_admin_models_tabs['video_tab_text_change'] ?  $disable_admin_models_tabs['video_tab_text_change'] : 'VIDEOS';
  $model_tabs_settings[6] =  $disable_admin_models_tabs['biography_tab_text_change'] ?  $disable_admin_models_tabs['biography_tab_text_change'] : 'BIOGRAPHY';
  $model_tabs_settings[7] =  $disable_admin_models_tabs['compard_tab_text_change'] ? $disable_admin_models_tabs['compard_tab_text_change'] : 'COMPCARD';
  $model_tabs_settings[8] =  isset(  $disable_admin_models_tabs['disable_tab1'] ) ? $disable_admin_models_tabs['disable_tab1'] : '0';
  $model_tabs_settings[9] = isset( $disable_admin_models_tabs['disable_tab2'] ) ? $disable_admin_models_tabs['disable_tab2'] : '0';
  $model_tabs_settings[10] = isset( $disable_admin_models_tabs['disable_tab3'] ) ? $disable_admin_models_tabs['disable_tab3'] : '0';
  $model_tabs_settings[11] = isset( $disable_admin_models_tabs['disable_tab4'] ) ? $disable_admin_models_tabs['disable_tab4'] : '0';
  $model_tabs_settings[12] = isset( $disable_admin_models_tabs['disable_tab5'] ) ? $disable_admin_models_tabs['disable_tab5'] : '0';
  $model_tabs_settings[13] = isset(  $disable_admin_models_tabs['disable_videos_tab'] )  ? $disable_admin_models_tabs['disable_videos_tab'] : '0';
  $model_tabs_settings[14] =  isset( $disable_admin_models_tabs['disable_compcard_tab'] )  ? $disable_admin_models_tabs['disable_compcard_tab'] : '0';
  $model_tabs_settings[15] =  isset( $disable_admin_models_tabs['disable_biography_tab'] )  ? $disable_admin_models_tabs['disable_biography_tab'] : '0';
  return $model_tabs_settings;
}

function julia_kaya_contact_email(){
  $owner_email_id = trim( $_POST['siteemail']);
  $name = trim($_POST['name']);
  $email = $_POST['email'];
  $message = $_POST['message'];
  $subject = $_POST['subject'];
  $site_owners_email =trim($owner_email_id); 
  $error = '';
  if ($name=="") {
    $error['name'] = "Please enter your name";  
  }
  if (!preg_match('/^[a-z0-9&\'\.\-_\+]+@[a-z0-9\-]+\.([a-z0-9\-]+\.)*+[a-z]{2}/is', $email)) {
    $error['email'] = "Please enter a valid email address"; 
  }
  if ($message== "") {
    $error['message'] = "Please leave a comment.";
  }
  if( $subject == "" ) {
    $error['subject'] = 'Enter Subject';
  }
  if (!$error) {
    $headers = "From: ".$name." <".$email.">\r\n"
    ."Reply-To: ".$email."\r\n"
    ."X-Mailer: PHP/" . phpversion();
    $mail = wp_mail($site_owners_email, $subject, $message,$headers);
    if( $mail ){
      echo "<div class='success'>" . $name . " We've received your Email. We'll be in touch with you as soon as possible!";
      echo '</div>';
    }else{
      echo "<div class='success'>" . $name . ". Sending Fail </div>";
    }    
  } # end if no error
  else {
    $response ="";
    echo $response;
    echo "<div class='success'>" . $name . ". Sending Fail </div>";
  } # end if there was an error sending
  die();
}
add_action( 'wp_ajax_nopriv_julia_kaya_contact_email', 'julia_kaya_contact_email' );
add_action( 'wp_ajax_julia_kaya_contact_email', 'julia_kaya_contact_email' );
?>