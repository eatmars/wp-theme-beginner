<?php
class Julia_Image_Box_Widget extends WP_Widget
  {
   function __construct()
   {
    global $julia_plugin_name;
     parent::__construct( 'kaya-image-with-title',
      __('Julia - Image Box',$julia_plugin_name),
      array('description' => __('Displays image box with title and description',$julia_plugin_name) )
      );
   }
   function widget( $args, $instance ){
      global $julia_plugin_name;
      $instance = wp_parse_args($instance,array(
        'title' => __('Image Block Title',$julia_plugin_name),
        'img_border_color' => '#ffffff',
        'vertical_title_size' => '18',
        'vertical_title_font_weight' => 'normal',
        'vertical_title_font_style' => 'italic',
        'vertical_title_letter_sapce' => '0',
        'vertical_title_color' => '#333333',
        'image_uri' => '',
        'image_width' => '500',
        'image_height' => '550',
        'img_side_title_font_size' => '18',
        'img_hover_title_font_size' => '18',
        'img_hover_title_font_weight' => 'normal',
        'img_hover_title_font_style' => 'normal',
        'img_hover_title_letter_sapce' => '0',
        'description' => '',
        'img_title_border_color' => '#ffffff',
        'img_hover_bg_color' => '#ffffff',
        'img_hover_title_color' => '#333',
        'img_hover_desc_color' => '#757575',
        'img_hover_desc_font_size' => '15',
         'img_hover_desc_font_style' => 'normal',
        'img_hover_desc_font_weight' => 'normal',
        'img_hover_desc_letter_sapce' => '0',
        'animation_names' => '',
        'readmore_button_title' => '',
        'readmore_button_link' => '#',
        'new_window' => '',
        'readmore_button_font_size' => '15',
        'readmore_button_name' => 'Read More',
        'readmore_button_color' => '#ffffff',
        'readmore_button_bg_color' => '#ff3333',
        'readmore_button_border_color' => '#ff3333',
        'readmore_button_hover_bg' => '#c19f51',
        'readmore_button_link_hover_color' => '#ffffff',
        'readmore_button_hover_border_color' => '#c19f51',
        'readmore_button_letter_space' => '0',
        'upload_images_ids' => '',
      ));
      echo $args['before_widget'];
        $target_window = ( $instance['new_window'] == 'on') ? '_blank' : '_self';
        echo '<div class="image_box_wrapper image_title_wrapper image_inside_border_title">';
          echo '<span class="image_title_border" style="border-color:'.$instance['img_border_color'].'"> </span>';
          if( !empty($instance['title']) ){
            echo '<span class="image_Vertical_title" style="background-color:'.$instance['img_border_color'].'; color:'.$instance['vertical_title_color'].'; font-size:'.$instance['vertical_title_size'].'px; font-style:'.$instance['vertical_title_font_style'].'; font-weight:'.$instance['vertical_title_font_weight'].'; letter-spacing:'.$instance['vertical_title_letter_sapce'].'px;">'.$instance['title'].'</span>';
          }
          //print_r(wp_get_attachment_image_srcset($instance['image_uri']));
          if( !empty($instance['image_uri']) ){
           // echo '<img src="'.kaya_image_resize($instance['image_uri'],  $instance['image_width'],  $instance['image_height'], 't').'" srcset="'.wp_get_attachment_image_srcset( $instance['upload_images_ids'], 'medium' ).'" sizes="(max-width: 500px) 100vw, 500px" class="" alt="" width="'.$instance['image_width'].'" height="'.$instance['image_height'].'" />';
             echo '<img src="'.kaya_image_resize($instance['image_uri'],  $instance['image_width'],  $instance['image_height'], 't').'" srcset="'.kaya_image_resize($instance['image_uri'],  $instance['image_width'],  $instance['image_height'], 't').' 768w, '.kaya_image_resize($instance['image_uri'],  '480',  400, 't').' 480w, '.kaya_image_resize($instance['image_uri'],  '320',  400, 't').' 320w" sizes="(max-width: 500px) 100vw, 500px" class="" alt="" width="'.$instance['image_width'].'" height="'.$instance['image_height'].'" />';
          }else{
              $default_img_url = constant(strtoupper($julia_plugin_name).'_PLUGIN_URL').'images/default_images/portfolio.jpg';
              if (is_multisite()){
                $image_url = $default_img_url;
              }else{                  
                $image_url = kaya_image_resize( $default_img_url, $instance['image_width'],  $instance['image_height'],'t' );
              }
              echo '<img  src="'.$image_url.'" class="" alt="" width="'.$instance['image_width'].'" height="'.$instance['image_height'].'" />';
          }
          if( !empty($instance['description']) ){
            echo '<div class="image_description_wrapper" style="background-color:'.$instance['img_hover_bg_color'].';">';
            echo '<div class="title_description_wrapper">';
              echo '<h3 style="color:'.$instance['img_hover_title_color'].'; font-size:'.$instance['img_hover_title_font_size'].'px; font-style:'.$instance['img_hover_title_font_style'].'; font-weight:'.$instance['img_hover_title_font_weight'].'; letter-spacing:'.$instance['img_hover_title_letter_sapce'].'px;">'.$instance['title'].'</h3>';
              echo '<p style="color:'.$instance['img_hover_desc_color'].'; font-size:'.$instance['img_hover_desc_font_size'].'px; font-style:'.$instance['img_hover_desc_font_style'].'; font-weight:'.$instance['img_hover_desc_font_weight'].'; letter-spacing:'.$instance['img_hover_desc_letter_sapce'].'px;">'.$instance['description'].'</p>';
              if( !empty($instance['readmore_button_name']) ){
                 echo '<a href="'.$instance['readmore_button_link'].'" target="'.$target_window.'"  data-hover-bg="'.$instance['readmore_button_hover_bg'].'" data-hover-border="'.$instance['readmore_button_hover_border_color'].'" data-button-hover="'.$instance['readmore_button_link_hover_color'].'" style="color:'.$instance['readmore_button_color'].'; background-color:'.$instance['readmore_button_bg_color'].'; border:1px solid '.$instance['readmore_button_border_color'].'; font-size:'.$instance['readmore_button_font_size'].'px; letter-spacing:'.$instance['readmore_button_letter_space'].'px;" class="readmore_button">'.$instance['readmore_button_name'].' </a>';
              }
             echo '</div></div>';
           }
         echo '</div>';
      echo $args['after_widget'];
    }
    function form( $instance ){
      global $julia_plugin_name;
      $instance = wp_parse_args($instance, array(
        'title' => __('Image Block Title',$julia_plugin_name),
        'img_border_color' => '#ffffff',
        'vertical_title_size' => '18',
        'vertical_title_font_weight' => 'normal',
        'vertical_title_font_style' => 'italic',
        'vertical_title_letter_sapce' => '0',
        'vertical_title_color' => '#333333',
        'image_uri' => '',
        'image_width' => '500',
        'image_height' => '550',
        'img_side_title_font_size' => '18',
        'img_hover_title_font_size' => '18',
        'img_hover_title_font_weight' => 'normal',
        'img_hover_title_font_style' => 'normal',
        'img_hover_title_letter_sapce' => '0',
        'description' => '',
        'img_title_border_color' => '#ffffff',
        'img_hover_bg_color' => '#ffffff',
        'img_hover_title_color' => '#333',
        'img_hover_desc_color' => '#757575',
        'img_hover_desc_font_size' => '15',
         'img_hover_desc_font_style' => 'normal',
        'img_hover_desc_font_weight' => 'normal',
        'img_hover_desc_letter_sapce' => '0',
        'animation_names' => '',
        'readmore_button_title' => '',
        'readmore_button_link' => '#',
        'new_window' => '',
        'readmore_button_font_size' => '15',
        'readmore_button_name' => 'Read More',
        'readmore_button_color' => '#ffffff',
        'readmore_button_bg_color' => '#ff3333',
        'readmore_button_border_color' => '#ff3333',
        'readmore_button_hover_bg' => '#c19f51',
        'readmore_button_link_hover_color' => '#ffffff',
        'readmore_button_hover_border_color' => '#c19f51',
        'readmore_button_letter_space' => '0',
        'upload_images_ids' => '',
      ));
        ?>
       <script type='text/javascript'>
        jQuery(document).ready(function($) {
          jQuery('.image_boxes_color_pickr').each(function(){
            jQuery(this).wpColorPicker();
          });
        });
      </script>
   <div class="input-elements-wrapper">
      <p class="three_fourth">
      <?php $i = rand(1,100); ?>
        <img class="custom_media_image_<?php echo $i; ?>" src="<?php if(!empty($instance['image_uri'])){echo $instance['image_uri'];} ?>" style="margin:0;padding:0;max-width:100px;float:left;display:inline-block" />
        <input type="text" class="widefat custom_media_url_<?php echo $i; ?>" name="<?php echo $this->get_field_name('image_uri'); ?>" id="<?php echo $this->get_field_id('image_uri'); ?>" value="<?php echo $instance['image_uri']; ?>">
        <input type="button" value="<?php _e( 'Upload Image', 'julia' ); ?>" class="button custom_media_upload_<?php echo $i; ?>" id="custom_media_upload_<?php echo $i; ?>"/>
          <input type="hidden" class="widefat custom_media_upload_id_<?php echo $i; ?>" name="<?php echo $this->get_field_name('upload_images_ids'); ?>" id="<?php echo $this->get_field_id('upload_images_ids'); ?>" value="<?php echo $instance['upload_images_ids']; ?>">

        <script type="text/javascript">
          jQuery(document).ready( function(){
            jQuery('.custom_media_upload_<?php echo $i; ?>').click(function(e) {
                e.preventDefault();
                var custom_uploader = wp.media({
                    title: 'Image Box Uploading',
                    button: {
                        text: 'Upload Image'
                    },
                    multiple: false  // Set this to true to allow multiple files to be selected
                })
                .on('select', function() {
                    var attachment = custom_uploader.state().get('selection').first().toJSON();
                    jQuery('.custom_media_image_<?php echo $i; ?>').attr('src', attachment.url);
                    jQuery('.custom_media_url_<?php echo $i; ?>').val(attachment.url);
                    jQuery('.custom_media_upload_id_<?php echo $i; ?>').val(attachment.id);
                })
                .open();
            });
          });
        </script>
      </p>
      <p class="one_fourth_last">
        <label for="<?php echo $this->get_field_id('image_width') ?>"> <?php _e('Image Width & Height',$julia_plugin_name) ?> </label>
        <input type="text" class="small-text" id="<?php echo $this->get_field_id('image_width') ?>" value="<?php echo esc_attr($instance['image_width']) ?>" name="<?php echo $this->get_field_name('image_width') ?>" />X
        <input type="text" class="small-text" id="<?php echo $this->get_field_id('image_height') ?>" value="<?php echo esc_attr($instance['image_height']) ?>" name="<?php echo $this->get_field_name('image_height') ?>" />
        <small><?php _e('px',$julia_plugin_name);?></small>
      </p> 
    </div>
    <div class="input-elements-wrapper">
      <p class="one_fourth">
        <label for="<?php echo $this->get_field_id('title'); ?>"> <?php _e('Title',$julia_plugin_name); ?> </label>  
        <input type="text" id="<?php echo $this->get_field_id('title') ?>" class="widefat" value="<?php echo esc_attr($instance['title']) ?>" name="<?php echo $this->get_field_name('title') ?>" />
      </p>
      <p class="one_fourth <?php echo $this->get_field_id('img_border_color'); ?>">
        <label for="<?php echo $this->get_field_id('img_border_color'); ?>"><?php _e('Image Border & Vertical Title BG Color',$julia_plugin_name) ?></label>
        <input type="text" name="<?php echo $this->get_field_name('img_border_color') ?>" id="<?php echo $this->get_field_id('img_border_color') ?>" class="image_boxes_color_pickr" value="<?php echo $instance['img_border_color'] ?>" />
      </p>
      <p class="one_fourth">
        <label for="<?php echo $this->get_field_id('vertical_title_size') ?>">  <?php _e('Image Vertical Title Font Size',$julia_plugin_name) ?>  </label>
        <input type="text" class="small-text" id="<?php echo $this->get_field_id('vertical_title_size') ?>" value="<?php echo esc_attr($instance['vertical_title_size']) ?>" name="<?php echo $this->get_field_name('vertical_title_size') ?>" />
        <small><?php _e('px',$julia_plugin_name); ?></small>
      </p>
      <p class="one_fourth_last">
        <label for="<?php echo $this->get_field_id('vertical_title_font_weight') ?>"> <?php _e('Vertical Title Font Weight',$julia_plugin_name) ?></label>
        <select id="<?php echo $this->get_field_id('vertical_title_font_weight') ?>" name="<?php echo $this->get_field_name('vertical_title_font_weight') ?>">
          <option value="normal" <?php selected('normal', $instance['vertical_title_font_weight']) ?>> <?php esc_html_e('Normal', $julia_plugin_name) ?>   </option>
          <option value="bold" <?php selected('bold', $instance['vertical_title_font_weight']) ?>>  <?php esc_html_e('Bold',$julia_plugin_name) ?></option>
        </select>
      </p>
      <p class="one_fourth" style="clear:both;">
        <label for="<?php echo $this->get_field_id('vertical_title_font_style') ?>"> <?php _e('Vertical Title Font Style',$julia_plugin_name) ?></label>
        <select id="<?php echo $this->get_field_id('vertical_title_font_style') ?>" name="<?php echo $this->get_field_name('vertical_title_font_style') ?>">
          <option value="normal" <?php selected('normal', $instance['vertical_title_font_style']) ?>> <?php esc_html_e('Normal', $julia_plugin_name) ?>   </option>
          <option value="italic" <?php selected('italic', $instance['vertical_title_font_style']) ?>>  <?php esc_html_e('Italic', $julia_plugin_name) ?></option>
        </select>
      </p>
      <p class="one_fourth">
        <label for="<?php echo $this->get_field_id('vertical_title_letter_sapce') ?>"> <?php _e('Image Vertical Title Letter Size',$julia_plugin_name) ?></label>
        <input type="text" class="small-text" id="<?php echo $this->get_field_id('vertical_title_letter_sapce') ?>" value="<?php echo esc_attr($instance['vertical_title_letter_sapce']) ?>" name="<?php echo $this->get_field_name('vertical_title_letter_sapce') ?>" />
        <small><?php _e('px',$julia_plugin_name); ?></small>
      </p>
      <p class="one_fourth <?php echo $this->get_field_id('vertical_title_color'); ?>">
        <label for="<?php echo $this->get_field_id('vertical_title_color'); ?>"><?php _e('Image Vertical Title Color',$julia_plugin_name) ?></label>
        <input type="text" name="<?php echo $this->get_field_name('vertical_title_color') ?>" id="<?php echo $this->get_field_id('vertical_title_color') ?>" class="image_boxes_color_pickr" value="<?php echo $instance['vertical_title_color'] ?>" />
      </p>
    </div>
    <div class="input-elements-wrapper">
       <p class="one_fourth" >
        <label for="<?php echo $this->get_field_id('img_hover_bg_color') ?>"> <?php _e('Image Hover BG Color',$julia_plugin_name) ?>  </label>
        <input type="text" class="image_boxes_color_pickr" id="<?php echo $this->get_field_id('img_hover_bg_color') ?>" value="<?php echo esc_attr($instance['img_hover_bg_color']) ?>" name="<?php echo $this->get_field_name('img_hover_bg_color') ?>" />
      </p> 
      <p class="one_fourth" >
        <label for="<?php echo $this->get_field_id('img_hover_title_color') ?>"> <?php _e('Image Hover Title Color',$julia_plugin_name) ?>  </label>
        <input type="text" class="image_boxes_color_pickr" id="<?php echo $this->get_field_id('img_hover_title_color') ?>" value="<?php echo esc_attr($instance['img_hover_title_color']) ?>" name="<?php echo $this->get_field_name('img_hover_title_color') ?>" />
      </p>
       <p class="one_fourth">
        <label for="<?php echo $this->get_field_id('img_hover_title_font_size'); ?>"> <?php _e('Image Hover Title Font Size',$julia_plugin_name); ?> </label>  
        <input type="text" id="<?php echo $this->get_field_id('img_hover_title_font_size') ?>" class="small-text" value="<?php echo esc_attr($instance['img_hover_title_font_size']) ?>" name="<?php echo $this->get_field_name('img_hover_title_font_size') ?>" />
        <small><?php _e('px', $julia_plugin_name); ?></small>
      </p>
      <p class="one_fourth_last">
        <label for="<?php echo $this->get_field_id('img_hover_title_font_weight') ?>"> <?php _e('Image Hover Title Font Weight',$julia_plugin_name) ?></label>
        <select id="<?php echo $this->get_field_id('img_hover_title_font_weight') ?>" name="<?php echo $this->get_field_name('img_hover_title_font_weight') ?>">
          <option value="normal" <?php selected('normal', $instance['img_hover_title_font_weight']) ?>> <?php esc_html_e('Normal', $julia_plugin_name) ?>   </option>
          <option value="bold" <?php selected('bold', $instance['img_hover_title_font_weight']) ?>>  <?php esc_html_e('Bold',$julia_plugin_name) ?></option>
        </select>
      </p>
      <p class="one_fourth" style="clear:both;">
        <label for="<?php echo $this->get_field_id('img_hover_title_font_style') ?>"> <?php _e('Image Hover Title Font Style',$julia_plugin_name) ?></label>
        <select id="<?php echo $this->get_field_id('img_hover_title_font_style') ?>" name="<?php echo $this->get_field_name('img_hover_title_font_style') ?>">
          <option value="normal" <?php selected('normal', $instance['img_hover_title_font_style']) ?>> <?php esc_html_e('Normal', $julia_plugin_name) ?>   </option>
          <option value="italic" <?php selected('italic', $instance['img_hover_title_font_style']) ?>>  <?php esc_html_e('Italic', $julia_plugin_name) ?></option>
        </select>
      </p>
       <p class="one_fourth">
        <label for="<?php echo $this->get_field_id('img_hover_title_letter_sapce') ?>"> <?php _e('Image Hover Title Letter Size',$julia_plugin_name) ?></label>
        <input type="text" class="small-text" id="<?php echo $this->get_field_id('img_hover_title_letter_sapce') ?>" value="<?php echo esc_attr($instance['img_hover_title_letter_sapce']) ?>" name="<?php echo $this->get_field_name('img_hover_title_letter_sapce') ?>" />
        <small><?php _e('px',$julia_plugin_name); ?></small>
      </p>
    </div>
    <div class="input-elements-wrapper">
      <p class="fullwidth">
        <label for="<?php echo $this->get_field_id('description'); ?>"> <?php _e('Description',$julia_plugin_name); ?> </label>  
          <textarea cols="10" class="widefat" id="<?php echo $this->get_field_id('description') ?>" value="<?php echo esc_attr($instance['description']) ?>" name="<?php echo $this->get_field_name('description') ?>" ><?php echo esc_attr($instance['description']) ?></textarea>
      </p>    
      <p class="one_fourth">
        <label for="<?php echo $this->get_field_id('img_hover_desc_color') ?>"> <?php _e('Image Hover Description Color',$julia_plugin_name) ?>  </label>
        <input type="text" class="image_boxes_color_pickr" id="<?php echo $this->get_field_id('img_hover_desc_color') ?>" value="<?php echo esc_attr($instance['img_hover_desc_color']) ?>" name="<?php echo $this->get_field_name('img_hover_desc_color') ?>" />
      </p>  
       <p class="one_fourth">
        <label for="<?php echo $this->get_field_id('img_hover_desc_font_size'); ?>"> <?php _e('Image Hover Description Font Size',$julia_plugin_name); ?> </label>  
        <input type="text" id="<?php echo $this->get_field_id('img_hover_desc_font_size') ?>" class="small-text" value="<?php echo esc_attr($instance['img_hover_desc_font_size']) ?>" name="<?php echo $this->get_field_name('img_hover_desc_font_size') ?>" />
        <small><?php _e('px', $julia_plugin_name); ?></small>
      </p>
        <p class="one_fourth">
        <label for="<?php echo $this->get_field_id('img_hover_desc_font_weight') ?>"> <?php _e('Image Hover Description Font Weight',$julia_plugin_name) ?></label>
        <select id="<?php echo $this->get_field_id('img_hover_desc_font_weight') ?>" name="<?php echo $this->get_field_name('img_hover_desc_font_weight') ?>">
          <option value="normal" <?php selected('normal', $instance['img_hover_desc_font_weight']) ?>> <?php esc_html_e('Normal', $julia_plugin_name) ?>   </option>
          <option value="bold" <?php selected('bold', $instance['img_hover_desc_font_weight']) ?>>  <?php esc_html_e('Bold',$julia_plugin_name) ?></option>
        </select>
      </p>
      <p class="one_fourth_last" >
        <label for="<?php echo $this->get_field_id('img_hover_desc_font_style') ?>"> <?php _e('Image Hover Description Font Style',$julia_plugin_name) ?></label>
        <select id="<?php echo $this->get_field_id('img_hover_desc_font_style') ?>" name="<?php echo $this->get_field_name('img_hover_desc_font_style') ?>">
          <option value="normal" <?php selected('normal', $instance['img_hover_desc_font_style']) ?>> <?php esc_html_e('Normal', $julia_plugin_name) ?>   </option>
          <option value="italic" <?php selected('italic', $instance['img_hover_desc_font_style']) ?>>  <?php esc_html_e('Italic', $julia_plugin_name) ?></option>
        </select>
      </p>
       <p class="one_fourth" style="clear:both;">
        <label for="<?php echo $this->get_field_id('img_hover_desc_letter_sapce') ?>"> <?php _e('Image Hover Description Letter Size',$julia_plugin_name) ?></label>
        <input type="text" class="small-text" id="<?php echo $this->get_field_id('img_hover_desc_letter_sapce') ?>" value="<?php echo esc_attr($instance['img_hover_desc_letter_sapce']) ?>" name="<?php echo $this->get_field_name('img_hover_desc_letter_sapce') ?>" />
        <small><?php _e('px',$julia_plugin_name); ?></small>
      </p>

    </div>
       <div class="input-elements-wrapper <?php echo $this->get_field_id('readmore_button_name') ?>">
      <p class="one_fourth">
        <label for="<?php echo $this->get_field_id('readmore_button_name') ?>">  <?php _e('Read More Button Name',$julia_plugin_name) ?>  </label>
        <input type="text" class="" id="<?php echo $this->get_field_id('readmore_button_name') ?>" value="<?php echo esc_attr($instance['readmore_button_name']) ?>" name="<?php echo $this->get_field_name('readmore_button_name') ?>" />
        </p>
      <p class="one_fourth">
        <label for="<?php echo $this->get_field_id('readmore_button_color') ?>">  <?php _e('Button Text Color',$julia_plugin_name) ?>  </label>
        <input type="text" class="image_boxes_color_pickr" id="<?php echo $this->get_field_id('readmore_button_color') ?>" value="<?php echo esc_attr($instance['readmore_button_color']) ?>" name="<?php echo $this->get_field_name('readmore_button_color') ?>" />
      </p>
      <p class="one_fourth">
        <label for="<?php echo $this->get_field_id('readmore_button_bg_color') ?>">  <?php _e('Button Background Color',$julia_plugin_name) ?>  </label>
        <input type="text" class="image_boxes_color_pickr" id="<?php echo $this->get_field_id('readmore_button_bg_color') ?>" value="<?php echo esc_attr($instance['readmore_button_bg_color']) ?>" name="<?php echo $this->get_field_name('readmore_button_bg_color') ?>" />
      </p>
      <p class="one_fourth_last">
        <label for="<?php echo $this->get_field_id('readmore_button_border_color') ?>">  <?php _e('Button Border Color',$julia_plugin_name) ?>  </label>
        <input type="text" class="image_boxes_color_pickr" id="<?php echo $this->get_field_id('readmore_button_border_color') ?>" value="<?php echo esc_attr($instance['readmore_button_border_color']) ?>" name="<?php echo $this->get_field_name('readmore_button_border_color') ?>" />
      </p>
      <p class="one_fourth" style="clear:both;">
        <label for="<?php echo $this->get_field_id('readmore_button_link_hover_color'); ?>"><?php _e('Button Hover Text Color',$julia_plugin_name) ?></label>
        <input type="text" name="<?php echo $this->get_field_name('readmore_button_link_hover_color') ?>" id="<?php echo $this->get_field_id('readmore_button_link_hover_color') ?>" class="image_boxes_color_pickr" value="<?php echo esc_attr($instance['readmore_button_link_hover_color']) ?>" />
      </p>
      <p class="one_fourth">
        <label for="<?php echo $this->get_field_id('readmore_button_hover_bg'); ?>"><?php _e('Button Hover Background Color',$julia_plugin_name) ?></label>
        <input type="text" name="<?php echo $this->get_field_name('readmore_button_hover_bg') ?>" id="<?php echo $this->get_field_id('readmore_button_hover_bg') ?>" class="image_boxes_color_pickr" value="<?php echo esc_attr($instance['readmore_button_hover_bg']) ?>" />
      </p>
      <p class="one_fourth">
        <label for="<?php echo $this->get_field_id('readmore_button_hover_border_color') ?>">  <?php _e('Button Hover Border Color',$julia_plugin_name) ?>  </label>
        <input type="text" class="image_boxes_color_pickr" id="<?php echo $this->get_field_id('readmore_button_hover_border_color') ?>" value="<?php echo esc_attr($instance['readmore_button_hover_border_color']) ?>" name="<?php echo $this->get_field_name('readmore_button_hover_border_color') ?>" />
      </p>
      <p class="one_fourth_last">
        <label for="<?php echo $this->get_field_id('readmore_button_font_size'); ?>"><?php _e('Button Font Size',$julia_plugin_name) ?></label>
        <input type="text" name="<?php echo $this->get_field_name('readmore_button_font_size') ?>" id="<?php echo $this->get_field_id('readmore_button_font_size') ?>" class="small-text" value="<?php echo esc_attr($instance['readmore_button_font_size']) ?>" />
      </p>
      <p class="one_fourth" style="clear:both;">
        <label for="<?php echo $this->get_field_id('readmore_button_letter_space'); ?>"><?php _e('Button Letter Space',$julia_plugin_name) ?></label>
        <input type="text" name="<?php echo $this->get_field_name('readmore_button_letter_space') ?>" id="<?php echo $this->get_field_id('readmore_button_letter_space') ?>" class="small-text" value="<?php echo esc_attr($instance['readmore_button_letter_space']) ?>" />
        <small><?php _e('px',$julia_plugin_name); ?></small>
      </p>
      <p class="one_fourth">
        <label for="<?php echo $this->get_field_id('readmore_button_link') ?>"> <?php _e('Button Link',$julia_plugin_name) ?></label>
        <input type="text" class="widefat" id="<?php echo $this->get_field_id('readmore_button_link') ?>" value="<?php echo esc_attr($instance['readmore_button_link']) ?>" name="<?php echo $this->get_field_name('readmore_button_link') ?>" />
      </p>
       <p class="one_fourth" >
        <label for="<?php echo $this->get_field_id('new_window') ?>">  <?php _e('Open in new window',$julia_plugin_name) ?>  </label>
        <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("new_window"); ?>" name="<?php echo $this->get_field_name("new_window"); ?>"<?php checked( (bool) $instance["new_window"], true ); ?> />
      </p>
    </div>
      <p class="fullwidth" style="clear:both;">
       <label for="<?php echo $this->get_field_id('animation_names') ?>">  <?php _e('Select Animation Effect',$julia_plugin_name) ?>  </label>
        <?php animation_effects($this->get_field_name('animation_names'), $instance['animation_names'] ); ?>
      </p> 
    <?php }
}
julia_kaya_register_widgets('image-box', __FILE__);
 ?>