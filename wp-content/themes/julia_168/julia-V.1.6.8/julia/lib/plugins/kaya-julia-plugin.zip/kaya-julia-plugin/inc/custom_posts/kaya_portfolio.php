<?php
if( !function_exists('portfolio_register') ){
global $pf_slug_name, $pf_slug_name_nws, $post, $pf_slug_text;
//$pf_slug_name = get_theme_mod('pf_slug_name') ? trim(get_theme_mod('pf_slug_name')) :'Portfolio';
$pf_slug_text = get_theme_mod('pf_slug_name') ? trim(get_theme_mod('pf_slug_name')) :'Model';
$pf_category_slug_name = get_theme_mod('pf_category_slug_name') ? trim(get_theme_mod('pf_category_slug_name')) :'Portfolio-category';
$pf_slug_name = !empty($pf_slug_text) ? $pf_slug_text : 'Model';
$pf_slug_name_nws = preg_replace('/\s/', '', $pf_slug_name);

function portfolio_register() {
	global $pf_slug_name, $pf_slug_name_nws, $julia_plugin_name, $pf_slug_text;
	//echo $string = preg_replace("/\s+/"," ",html_entity_decode($pf_slug_name));
	$labels = array(

		'name'				=> trim(ucwords($pf_slug_name)),
		'singular_name'		=> trim(ucwords($pf_slug_name)),
		'add_new'			=> __('Add New ', $julia_plugin_name).ucwords($pf_slug_name),
		'add_new_item'		=> __('Add New', $julia_plugin_name).ucwords($pf_slug_name),
		'edit_item'		=> __('Edit ', $julia_plugin_name, $julia_plugin_name).ucwords($pf_slug_name),
		'new_item'		=> __('New Post Item ', $julia_plugin_name, $julia_plugin_name),
		'view_item'		=> __('View Post Item ', $julia_plugin_name, $julia_plugin_name),
		'search_items'	=> __('Search ', $julia_plugin_name) . ucwords($pf_slug_name) . __(' Items', $julia_plugin_name,$julia_plugin_name),
		'not_found'		=> __('Nothing found', $julia_plugin_name, $julia_plugin_name),
		'not_found_in_trash'	=> __('not_found_in_trash', $julia_plugin_name),
		'parent_item_colon'	=> ''
	);
 
	$args = array(
		'labels'			=> $labels,
		'public'			=> true,
		'exclude_from_search'=> false,
		'show_ui'			=> true,
		'capability_type'	=> 'post',
		'hierarchical'		=> false,
		'rewrite' => array( 'slug' => strtolower($pf_slug_name_nws), 
		'with_front' => true ),
		'query_var'			=> false,	
		'menu_icon'			=> 'dashicons-portfolio',  		
		'supports'			=> array('title', 'editor', '', 'thumbnail', 'comments', 'page-attributes')
	); 
	register_post_type( 'portfolio' , $args );
	//register_taxonomy_for_object_type('post_tag', 'portfolio');
}
	
add_action('init', 'portfolio_register');

// register two taxonomies to go with the post type
function pf_register_taxonomy() {
	global $pf_slug_name, $pf_slug_name_nws, $post;
// set up labels
$labels = array(
	'name' => ucwords($pf_slug_name).' '.__('Categories','julia'),
	'singular_name' =>  ucwords($pf_slug_name) .__('Categories','julia'),
	'search_items' => 'Search '.ucwords($pf_slug_name).__('Categories','julia'),
	'all_items' => 'All '.ucwords($pf_slug_name).__('Categories','julia'),
	'edit_item' => 'Edit '.ucwords($pf_slug_name).''.ucwords($pf_slug_name).__('Category','julia'),
	'update_item' => 'Update '.ucwords($pf_slug_name).__('Category','julia'),
	'add_new_item' => 'Add New '.ucwords($pf_slug_name).__('Category','julia'),
	'new_item_name' => 'New '.ucwords($pf_slug_name).__('Category','julia'),
	'menu_name' => ucwords($pf_slug_name).__('Category','julia')
);
// register taxonomy
$pf_category_slug_name = get_theme_mod('pf_category_slug_name') ? trim(get_theme_mod('pf_category_slug_name')) :'Portfolio-category';
register_taxonomy( 'portfolio_category', 'portfolio', array(
	'hierarchical' => true,
	'labels' => $labels,
	'query_var' => true,
	'show_admin_column' => true,
	'rewrite'           =>  array('slug' => strtolower($pf_category_slug_name), 'with_front' => false),
));
}
add_action( 'init', 'pf_register_taxonomy' );
function my_columns($columns) {
	global $pf_slug_name, $pf_slug_name_nws, $julia_plugin_name, $pf_slug_text;
	$pf_disable_unique_id = get_theme_mod('pf_disable_unique_id') ? get_theme_mod('pf_disable_unique_id') : '0';
	//$columns['portfolio_category'] = __('Category','julia');
	if( $pf_disable_unique_id != '1' ){
    	$columns['pf_model_id'] =  ucwords($pf_slug_name).' '.__('ID','julia'); // Model ID
	}
	if ( is_super_admin() ) {
		$columns['pf_email_id'] =__('Email ID','julia');
		$columns['pf_phone_number'] = __('Phone Number','julia');
	}
	$columns['thumbnail'] =  __('Post Image','julia');
    return $columns;
}
function julia_kaya_admin_details( $admin_menu ){
	$custom_pf_options = get_option('pf_custom_options');
	$prefix = 'pf_model_';
	for ($i=0; $i < count($custom_pf_options['pf_meta_label_name'])-1; $i++) {
		if( ( !empty($custom_pf_options['pf_meta_label_name'][$i]) ) &&  ( $custom_pf_options['pf_meta_label_name'][$i] != 'Array') &&  ( $custom_pf_options['pf_meta_label_name'][$i] != '') &&  ( !is_array($custom_pf_options['pf_meta_label_name'][$i]) )){
				$options_data_id = $prefix.str_replace(array(' ', ',','-', '/', '___'), '_', trim(strtolower($custom_pf_options['pf_meta_label_uid'][$i])));
				if( ($custom_pf_options['pf_meta_field_name'][$i] == 'emailid') && ( $admin_menu == 'emailid' ) ){
					return '<a href="mailto:'.get_post_meta(get_the_ID(), $options_data_id , true).'" >'.get_post_meta(get_the_ID(), $options_data_id , true).'</a>';
				}elseif( ($custom_pf_options['pf_meta_field_name'][$i] == 'phone_number') && ( $admin_menu == 'phone_number' ) ){
					return get_post_meta(get_the_ID(), $options_data_id , true);	
				}else{

				}
		}
	}
}
function manage_portfolio_columns($name) {
    global $post, $wp_query;
    switch ($name) {
	 case 'portfolio_category':
               $terms = get_the_terms($post->ID, 'portfolio_category');
        //If the terms array contains items... (dupe of core)
        if ( !empty($terms) ) {
            //Loop through terms
            foreach ( $terms as $term ){
                //Add tax name & link to an array
                $post_terms[] = esc_html(sanitize_term_field('name', $term->name, $term->term_id, '', 'edit'));
            }
            //Spit out the array as CSV
            echo implode( ', ', $post_terms );
        } else {
            //Text to show if no terms attached for post & tax
            echo '<em>No terms</em>';
        }
				break;
		case 'pf_model_id':          
				echo get_post_meta(get_the_id(),'pf_unique_id',true) ? get_post_meta(get_the_id(),'pf_unique_id',true) : '';
				break;
		case 'pf_email_id': 		
			//Page options
			echo julia_kaya_admin_details('emailid');
			// End
			break;
		case 'pf_phone_number': 		
			//Page options
			echo julia_kaya_admin_details('phone_number');
			// End
			break;			
        case 'thumbnail':          
				echo the_post_thumbnail(array(100,100));
				break;
       
    }
}
add_action('manage_posts_custom_column', 'manage_portfolio_columns', 10, 2);
add_filter('manage_edit-portfolio_columns', 'my_columns');
// Change Default thumbnial Label Name
if( !function_exists('kaya_portfolio_featured_image_label') ){ 
	add_action('do_meta_boxes', 'kaya_portfolio_featured_image_label');  
	function kaya_portfolio_featured_image_label()  
	{  
		global $julia_plugin_name, $pf_slug_name, $pf_slug_name_nws, $julia_plugin_name;
	    remove_meta_box( 'postimagediv', 'portfolio', 'side' );  
	    add_meta_box('postimagediv', ucfirst($pf_slug_name).' '.__('Image', $julia_plugin_name), 'post_thumbnail_meta_box', 'portfolio', 'side', 'low');  
	}
}
// Title Place holder name Change
	if( !function_exists('kaya_pf_model_title') ){ 
		function kaya_pf_model_title( $title ){
			global $julia_plugin_name, $pf_slug_name;
			$screen = get_current_screen();
			if ( 'portfolio' == $screen->post_type ){
				$title = __('Enter',$julia_plugin_name).' '.ucfirst($pf_slug_name).' '.__('Name', $julia_plugin_name);
			}
			return $title;
			}
	add_filter( 'enter_title_here', 'kaya_pf_model_title' );
}
	/*----------------------------------------------
	//Search Admin Post Custom Search
	----------------------------------------------*/
	if ( isset($_GET['post_type']) ){
	    add_filter('posts_join', 'julia_kaya_admin_post_search_join' );
	    function julia_kaya_admin_post_search_join ($join){
	        global $pagenow, $wpdb;
	        if ( is_admin() && $pagenow=='edit.php' && $_GET['post_type']=='portfolio' && isset($_GET['s']) != '') {    
	            $join .='LEFT JOIN '.$wpdb->postmeta. ' ON '. $wpdb->posts . '.ID = ' . $wpdb->postmeta . '.post_id ';
	        }
	        return $join;
	    }

	    add_filter( 'posts_where', 'julia_kaya_admin_post_search_where' );
	    function julia_kaya_admin_post_search_where( $where ){
	        global $pagenow, $wpdb;
	        if ( is_admin() && $pagenow=='edit.php' && $_GET['post_type']=='portfolio' && isset($_GET['s']) != '') {
	            $where = preg_replace(
	           "/\(\s*".$wpdb->posts.".post_title\s+LIKE\s*(\'[^\']+\')\s*\)/",
	           "(".$wpdb->posts.".post_title LIKE $1) OR (".$wpdb->postmeta.".meta_value LIKE $1)", $where );
	        }
	        return $where;
	    }
	    function julia_kaya_admin_post_search_distinct( $where ){
	        global $pagenow, $wpdb;
	        if ( is_admin() && $pagenow=='edit.php' && $_GET['post_type']=='portfolio' && isset($_GET['s']) != '') {
	            return "DISTINCT";
	        }
	        return $where;
	    }
	    add_filter( 'posts_distinct', 'julia_kaya_admin_post_search_distinct' );
	}
}
?>