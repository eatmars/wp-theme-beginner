<?php 
class Julia_Demo_Import
{
    function __construct() {
        if ( ! is_admin() ) {
            return;
        }
        add_action('admin_menu', array(&$this, 'kaya_admin_option_page'),30);
    }
    /**
     * Importing XML Demo content
     */
    function kaya_admin_option_page(){
       // add_menu_page('Options', ucfirst('julia').' '.__('Options','julia'), 'manage_options', 'kaya_theme_options', array(&$this, 'import_xml_content'), '', 62);
        add_submenu_page('kaya_theme_options', 'Import1', __('One Click Demo', 'julia'), 'manage_options', 'one_click_import', array(&$this,'import_xml_content'));
        remove_submenu_page( 'kaya_theme_options', 'kaya_theme_options' );
    }
    function import_xml_content(){
        echo '<h3>'.__('Choose Your','julia').' ' .ucfirst('julia'). ' '.__('Demo Content','julia').'</h3>';
         echo '<div class="kaya_demo_note"><strong style="color:red;">'. __('Note','julia').' : </strong> '.__(' Before importing demo content make sure that you have installed and activated " '. ucfirst('julia').' " theme required plugins').'</div>';
        ?>
        <div id="import_xml_content_wrapper">            
            <div class="content_loading_wrapper">
                <img class="content_loading" style="display:none" src="<?php echo get_template_directory_uri(); ?>/images/ajax-loader.GIF" class="" /><div class="import_message"> </div>
            </div>
         <span class="clear"> </span>
            <label>
               <input type="radio" name="demo_content" id="julia" value="julia" checked />
                <img src="<?php echo get_template_directory_uri() ?>/images/demo_xml_images/julia.jpg">
            </label>
            <span class="clear"> </span>
            <input type="button" class="xml_demo_import button button-primary button-large" value="<?php _e('Import Content','julia'); ?>" />
        <?php
            echo '<div class="clear"> </div>';
            echo '</div>';
            $css ='';
            $css .='.content_loading_wrapper {
                    margin-top: 30px;
                }
            .content_loading_wrapper img {
                float: left;
                margin-right: 15px;
            }
            label > input{ 
              visibility: hidden;
              position: absolute;
            }
            #import_xml_content_wrapper label {
               float: left;
                margin-bottom: 30px;
                margin-right: 1.5%;
                overflow: hidden;
                text-align: center;
                width: 23.5%;
            }
            .xml_demo_import {
                float: left;
                margin-bottom: 30px !important;
               margin-right: 1.5% !important;
            }
            .kaya_demo_note {
                border: 1px solid #e5e5e5;
                margin-bottom: 30px;
                padding: 15px;
            }
            .import_message{
                margin-top: 30px;
                margin-bottom: 30px;
            }
            .import_message .updated{
                margin-left:0; 
            }
            #import_xml_content_wrapper label img {
                background: none repeat scroll 0 0 #f5f5f5;
                border: 1px solid #dfdfdf;
                display: block;
                margin-right: 16px;
                overflow: hidden;
                padding: 6px;
                width: 95%;
            }
            label > input:checked + img {
                border: 1px solid #2ea2cc!important;
            }';
            $css = preg_replace( '/\s+/', ' ', $css );
            $output = "<style type=\"text/css\">\n" . $css . "\n</style>";
            echo $output;  ?>     
        <script>
            (function($) {
            "use strict";
                 $("input[type='button']").click(function(){
                     var $import_options = $("input[name='demo_content']:checked").val();
                     if( $import_options == undefined){
                        alert('Please Choose Your Demo Content');
                        return;
                     }
                    //alert($import_options);
                    var $import_true = confirm('are you sure to import dummy content ? it will overwrite the existing data');
                    if($import_true == false) return;
                    $('.import_message').html(' Data is being imported please be patient, while the awesomeness is being created :)  ');
                    $('.content_loading').show();
                     $('.xml_demo_import').attr('disabled','disable');
                    $('html, body').animate({scrollTop: $("body").offset().top}, 400);
                    var data = {
                        action: 'demo_xml_content_import',
                        xml: $import_options,     
                    };
                    $.post(ajaxurl, data, function(response) {
                         $('.import_message').html('<div class="import_message_success">'+ response +'</div>');
                        $('.content_loading').hide();
                        $('.xml_demo_import').removeAttr('disabled');
                    });
                });
            })(jQuery);
        </script>
        <?php 
    }
}
$globel_options = new Julia_Demo_Import();
add_action( 'wp_ajax_demo_xml_content_import', 'demo_xml_content_import' );
function demo_xml_content_import() 
{ 
    
   // WP_Filesystem();
    global $wp_filesystem, $wpdb,$julia_plugin_name;

    if ( !defined('WP_LOAD_IMPORTERS') ) define('WP_LOAD_IMPORTERS', true);    
    // Load Importer API
    require_once ABSPATH . 'wp-admin/includes/import.php';
    if ( ! class_exists( 'WP_Importer' ) ) {
        $class_wp_importer = ABSPATH . 'wp-admin/includes/class-wp-importer.php';
        if ( file_exists( $class_wp_importer ) )
        {
            require $class_wp_importer;
        }
    }

    if ( ! class_exists( 'WP_Import' ) ) {
        $class_wp_importer = constant(strtoupper($julia_plugin_name).'_PLUGIN_DIR').'inc/admin/importer/wordpress-importer.php';
        require dirname( __FILE__ ) . '/wordpress-importer.php';
    }
     if( $_POST['xml'] ){
        $files = $_POST['xml'];
    }else{
        // $files = 'globel1';
    }
    $import_filepath =  constant(strtoupper($julia_plugin_name).'_PLUGIN_DIR').'inc/admin/kaya-xml-files/'.$files.'.xml';     
    $wp_import = new WP_Import();
    set_time_limit(0);
    $wp_import->fetch_attachments = false;
    $wp_import->import($import_filepath);
    // Customizer options 
    $file_name = $files.'.json'; // Get the name of file
    $options_import = $files.'_options.json'; // Get the name of file
    if( $file_name ){
        $file_extention = explode('.', $file_name); // Get extension of file
        $file_ext = end($file_extention);
        if (($file_ext == "json")) {
            $customizer_content = constant(strtoupper($julia_plugin_name).'_PLUGIN_DIR').'inc/admin/kaya-xml-files/'.$file_name;
            $model_options_data = constant(strtoupper($julia_plugin_name).'_PLUGIN_DIR').'inc/admin/kaya-xml-files/model_options.json';
            $kta_shortlist_options = constant(strtoupper($julia_plugin_name).'_PLUGIN_DIR').'inc/admin/kaya-xml-files/kta_shortlist_options.json';
            $kta_talents_options = constant(strtoupper($julia_plugin_name).'_PLUGIN_DIR').'inc/admin/kaya-xml-files/kta_talents_options.json';
            $widgets_data = constant(strtoupper($julia_plugin_name).'_PLUGIN_DIR').'inc/admin/kaya-xml-files/widgets_data.json';
             $sidebars = constant(strtoupper($julia_plugin_name).'_PLUGIN_DIR').'inc/admin/kaya-xml-files/sidebars.json';

            if( $model_options_data ){ // Model Options Data Read
                $model_data = file_get_contents($model_options_data);
                $model_options_array = json_decode($model_data, true);
                foreach ($model_options_array as $key => $value) {
                        update_option($key, $value);
                    }
            }
            // Importing Sidebars
            if( $sidebars ){
                $sidebars_data = file_get_contents( $sidebars );
                $sidebars_data= json_decode($sidebars_data );
                $sbg_sidebars = array();
                foreach ($sidebars_data as $key => $opt_val) {
                    $sbg_sidebars[$key] = $opt_val;
                    update_option( 'sbg_sidebars', $sbg_sidebars );
                }
            }
            // Widegts Info
            $data = file_get_contents( $widgets_data );
            $data = json_decode($data );
            julia_import_widgets($data);

            // Importing Sliders
            if (class_exists('SmartSlider3')) {
                SmartSlider3::import(get_template_directory()."/smartslider-demo-content/slider-demo1.ss3");
                SmartSlider3::import(get_template_directory()."/smartslider-demo-content/slider-demo2.ss3");
                SmartSlider3::import(get_template_directory()."/smartslider-demo-content/slider-demo3.ss3");
                SmartSlider3::import(get_template_directory()."/smartslider-demo-content/slider-demo4.ss3");
                SmartSlider3::import(get_template_directory()."/smartslider-demo-content/slider-demo5.ss3");
                SmartSlider3::import(get_template_directory()."/smartslider-demo-content/slider-demo6.ss3");
                SmartSlider3::import(get_template_directory()."/smartslider-demo-content/slider-demo7.ss3");
                SmartSlider3::import(get_template_directory()."/smartslider-demo-content/slider-demo8.ss3");
            }


            // Importing Shortlist list Data 
            if( $kta_shortlist_options ){
                $shortlist_data = file_get_contents( $kta_shortlist_options );
                $shortlist_data= json_decode($shortlist_data );
                $kta_shortlist = array();
                foreach ($shortlist_data as $key => $opt_val) {
                    $kta_shortlist[$key] = $opt_val;
                    update_option( 'kta_shortlist', $kta_shortlist );
                }
            }
            // Importing Talent Options Data 
            if( $kta_talents_options ){
                  $kta_talents_opt_data = file_get_contents( $kta_talents_options );
                 $kta_talents_opt_data= json_decode($kta_talents_opt_data );
                 $kta_options = array();
                 foreach ($kta_talents_opt_data as $key => $opt_val) {
                    $kta_options[$key] = $opt_val;
                    update_option( 'kta_options', $kta_options );
                 }
            }
            // Importing Customizer Data
            if( $customizer_content ){
                $encode_options = file_get_contents($customizer_content);
                $options = json_decode($encode_options, true);
                foreach ($options as $key => $value) {
                    set_theme_mod($key, $value);
                }
                $encode_model_options = file_get_contents($model_options_data);
                $model_options = json_decode($encode_model_options, true);
                    foreach ($model_options as $key => $value) {
                        update_option($key, $value);
                    } 
                // Updating Menus    
                $locations = array();
                if(isset($options['nav_menu_locations'])){
                    if (is_array($options['nav_menu_locations'])) {
                           foreach ($options['nav_menu_locations'] as $menu_name => $menu_id) {
                            $locations[$menu_name] = $menu_id;
                            set_theme_mod( 'nav_menu_locations', $locations);
                        }
                    } 
                }
                // Updating Front Page                 
                $front_page = !empty( $options['front_page_name'] ) ?  $options['front_page_name'] : '2';
                $page_title = get_the_title( $front_page );
                $front_page_name = get_page_by_title( $page_title );
                if( $front_page_name == 'Sample Page' ){ }
                else{
                    update_option( 'page_on_front', $front_page_name->ID );
                    update_option( 'show_on_front', 'page' );
                }
                echo "<div class='updated'><p>".__('Data Imported successfully','julia')."</p></div>";
            }else{
             echo "<div class='error'><p>".__('Error occured while loading / File not found','julia')."</p></div>";
            }
            }
        }else{
             echo "<div class='error'><p>".__('Error occured while loading / File not found','julia')."</p></div>";
        }
    die(); // this is required to return a proper result
}

// Widgets Importing Demo Content 
function julia_available_widgets() {
        global $wp_registered_widget_controls;
        $widget_controls = $wp_registered_widget_controls;
        $available_widgets = array();
        foreach ( $widget_controls as $widget ) {
            if ( ! empty( $widget['id_base'] ) && ! isset( $available_widgets[$widget['id_base']] ) ) { // no dupes
                $available_widgets[$widget['id_base']]['id_base'] = $widget['id_base'];
                $available_widgets[$widget['id_base']]['name'] = $widget['name'];
            }
        }
        return apply_filters( 'julia_available_widgets', $available_widgets );
    }
    
function julia_import_widgets( $data ) {
    global $wp_registered_sidebars;
    if ( empty( $data ) ) {
        wp_die(
            esc_html__( 'Widgets data not found', 'julia' ),
            '',
            array( 'back_link' => true )
        );
    }
    $data = apply_filters( 'theme_import_widget_data', $data );
    $available_widgets = julia_available_widgets();
    $widget_instances = array();
    foreach ( $available_widgets as $widget_data ) {
        $widget_instances[$widget_data['id_base']] = get_option( 'widget_' . $widget_data['id_base'] );
    }
    $results = array();
    foreach ( $data as $sidebar_id => $widgets ) {
        if ( 'wp_inactive_widgets' == $sidebar_id ) {
            continue;
        }
        if ( isset( $wp_registered_sidebars[$sidebar_id] ) ) {
            $sidebar_available = true;
            $use_sidebar_id = $sidebar_id;
            $sidebar_message_type = 'success';
            $sidebar_message = '';
        } else {
            $sidebar_available = false;
            $use_sidebar_id = 'wp_inactive_widgets';
            $sidebar_message_type = 'error';
            $sidebar_message = esc_html__( 'Sidebar data does not exist', 'julia' );
        }
        $results[$sidebar_id]['name'] = ! empty( $wp_registered_sidebars[$sidebar_id]['name'] ) ? $wp_registered_sidebars[$sidebar_id]['name'] : $sidebar_id; 
        $results[$sidebar_id]['message_type'] = $sidebar_message_type;
        $results[$sidebar_id]['message'] = $sidebar_message;
        $results[$sidebar_id]['widgets'] = array();
        foreach ( $widgets as $widget_instance_id => $widget ) {
            $fail = false;
            $id_base = preg_replace( '/-[0-9]+$/', '', $widget_instance_id );
            $instance_id_number = str_replace( $id_base . '-', '', $widget_instance_id );
            if ( ! $fail && ! isset( $available_widgets[$id_base] ) ) {
                $fail = true;
                $widget_message_type = 'error';
                $widget_message = esc_html__( 'Error, While importing sidebar data', 'julia' );
            }
            $widget = apply_filters( 'widget_import_widget_settings', $widget );
            if ( ! $fail && isset( $widget_instances[$id_base] ) ) {
                $sidebars_widgets = get_option( 'sidebars_widgets' );
                $sidebar_widgets = isset( $sidebars_widgets[$use_sidebar_id] ) ? $sidebars_widgets[$use_sidebar_id] : array(); 
                $single_widget_instances = ! empty( $widget_instances[$id_base] ) ? $widget_instances[$id_base] : array();
                foreach ( $single_widget_instances as $check_id => $check_widget ) {
                    if ( in_array( "$id_base-$check_id", $sidebar_widgets ) && (array) $widget == $check_widget ) {
                        $fail = true;
                        $widget_message_type = 'warning';
                        $widget_message = esc_html__( 'Widgets data already exist.', 'julia' );
                        break;
                    }
                }
            }
            // Widgts data exist
            if ( ! $fail ) {
                $single_widget_instances = get_option( 'widget_' . $id_base ); // all instances for that widget ID base, get fresh every time
                $single_widget_instances = ! empty( $single_widget_instances ) ? $single_widget_instances : array( '_multiwidget' => 1 ); // start fresh if have to
                $single_widget_instances[] = (array) $widget;
                    end( $single_widget_instances );
                    $new_instance_id_number = key( $single_widget_instances );
                    if ( '0' === strval( $new_instance_id_number ) ) {
                        $new_instance_id_number = 1;
                        $single_widget_instances[$new_instance_id_number] = $single_widget_instances[0];
                        unset( $single_widget_instances[0] );
                    }
                    if ( isset( $single_widget_instances['_multiwidget'] ) ) {
                        $multiwidget = $single_widget_instances['_multiwidget'];
                        unset( $single_widget_instances['_multiwidget'] );
                        $single_widget_instances['_multiwidget'] = $multiwidget;
                    }
                update_option( 'widget_' . $id_base, $single_widget_instances );
                $sidebars_widgets = get_option( 'sidebars_widgets' );
                $new_instance_id = $id_base . '-' . $new_instance_id_number;
                $sidebars_widgets[$use_sidebar_id][] = $new_instance_id;
                update_option( 'sidebars_widgets', $sidebars_widgets );
                if ( $sidebar_available ) {
                    $widget_message_type = 'success';
                    $widget_message = esc_html__( 'Widgets data imported successfully', 'julia' );
                } else {
                    $widget_message_type = 'warning';
                    $widget_message = esc_html__( 'Imported to Inactive', 'julia' );
                }
            }
            $results[$sidebar_id]['widgets'][$widget_instance_id]['name'] = isset( $available_widgets[$id_base]['name'] ) ? $available_widgets[$id_base]['name'] : $id_base;
            $results[$sidebar_id]['widgets'][$widget_instance_id]['title'] = ! empty( $widget->title ) ? $widget->title : esc_html__( 'No Title', 'julia' ); 
            $results[$sidebar_id]['widgets'][$widget_instance_id]['message_type'] = $widget_message_type;
            $results[$sidebar_id]['widgets'][$widget_instance_id]['message'] = $widget_message;
        }
    }
    return $results;
}
?>